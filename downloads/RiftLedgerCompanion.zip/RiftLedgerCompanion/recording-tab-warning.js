export function createRecordingTabWarning({root,send,refresh,showError}) {
  root.innerHTML=`<div class="recording-tab-heading"><span aria-hidden="true">▣</span><strong>This tab isn’t being recorded</strong></div>
    <p id="recording-tab-description"></p><p id="recording-tab-hint" hidden></p>
    <div class="recording-tab-actions"><button id="recording-tab-switch" type="button">Switch to this tab</button><button id="recording-tab-focus" type="button">Go to recorded tab ↗</button></div>`;
  const $=s=>root.querySelector(s);
  let status=null,busy=false;
  function render(next){
    status=next;
    const context=next?.tabContext,active=next?.active;
    root.hidden=!(context?.otherTab&&['auto','match'].includes(active?.kind));
    if(root.hidden)return;
    const waiting=active.kind==='auto'&&['waiting','reconnecting'].includes(active.phase);
    $('#recording-tab-description').textContent=waiting
      ?'Auto-record is armed in another RiftAtlas tab. Switch it here to record games on this tab.'
      :'Video is being recorded in another RiftAtlas tab. Switching saves that footage, then starts recording here.';
    $('#recording-tab-hint').hidden=!!context.canSwitch;
    $('#recording-tab-hint').textContent=active.stopping?'The other tab is saving. Wait for it to finish.':context.hint||'Enable game capture on a playable RiftAtlas page to switch here.';
    $('#recording-tab-switch').disabled=busy||!context.canSwitch;
    $('#recording-tab-focus').disabled=busy;
    $('#recording-tab-switch').textContent=busy==='video-switch-tab'?'Saving & switching…':'Switch to this tab';
  }
  async function act(type){
    if(busy||root.hidden)return;
    const context=status.tabContext,sessionKey=status.sessionKey;
    if(type==='video-switch-tab'&&!context.canSwitch)return;
    busy=type;showError(null);render(status);
    try{await send({type,sessionKey,fromTabId:context.recordedTabId,targetTabId:context.currentTabId});}
    catch(error){showError(error);}
    finally{busy=false;render(status);await refresh();}
  }
  $('#recording-tab-switch').onclick=()=>act('video-switch-tab');
  $('#recording-tab-focus').onclick=()=>act('video-focus-tab');
  return {render};
}
