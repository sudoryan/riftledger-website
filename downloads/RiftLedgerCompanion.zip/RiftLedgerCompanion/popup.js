import {createRecordingTabWarning} from './recording-tab-warning.js';
import {createMatchVideoLinks} from './match-video-links.js';
import {videoBanner} from './video-notice.js';
import {fillReviewForm,rawReviewFields,reviewValues,reviewStamp,validReviewDraft} from './review-form.js';
const $=s=>document.querySelector(s);
let status=null, pending=false, connected=false, eligible=false, loading=false, currentMatch=null;
const send=async message=>{
  const response=await chrome.runtime.sendMessage(message);
  if(!response?.ok)throw Error(response?.error||'The extension is unavailable. Reopen it after updating.');
  return response.result;
};
const showError=error=>{$('#error').hidden=!error;$('#error').textContent=error?.message||'';};
const links=createMatchVideoLinks({root:$('#match-videos'),send,showError});
const tabWarning=createRecordingTabWarning({root:$('#recording-tab-warning'),send,showError,refresh:pollVideo});
const time=seconds=>{const n=Math.max(0,Math.floor(seconds||0));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;};
function renderVideo(){
  const active=status?.active, other=status?.tabContext?.otherTab;
  const capturing=active?.kind==='match'||active?.kind==='auto'&&active.phase==='recording';
  const waiting=active?.kind==='auto'&&active.phase==='waiting';
  $('#recording').dataset.kind=capturing?'active':active?'waiting':'idle';
  $('#recording-title').textContent=other?'Recording in another tab':active?.stopping?'Saving your video…':active?.kind==='clip'?'Preparing your clip':capturing?`Recording · ${time(active.elapsed)}`:waiting?'Ready for your next game':active?.phase==='reconnecting'?'Reconnecting to RiftAtlas':'Record your next game';
  const quality=status?.quality==='2160p'?'4K':status?.quality||'1080p';
  $('#recording-detail').textContent=other?'Switch tabs using the controls above.':active?.kind==='clip'?`${Math.round((active.progress||0)*100)}% complete · You can close this popup.`:waiting?'Auto-record is on. Each game saves separately.':active?.phase==='reconnecting'?'Auto-record will resume when the game is ready.':capturing?`${quality} · ${status?.requestedFrameRate||30} fps target${active.microphone?.enabled?' · Mic on':''}`:connected?'Record each game automatically in this tab.':'Open RiftAtlas to start recording.';
  $('#record').hidden=!!active;$('#record').disabled=pending||!eligible||!status;
  $('#stop').hidden=!active||!!other;$('#stop').disabled=pending||!!active?.stopping;$('#stop').textContent=active?.kind==='clip'?'Cancel clip':waiting?'End auto-record':'Stop & save';
  $('#highlight').hidden=!capturing||!!other;$('#highlight').disabled=pending||!!active?.stopping;
  const banner=videoBanner(status||{});
  $('#notice').hidden=!!active||!!banner.hidden;$('#notice').dataset.kind=banner.kind;
  $('#notice-text').textContent=banner.text;
  tabWarning.render(status||{});
}
async function pollVideo(){
  try{status=await send({type:'video-status'});renderVideo();}
  catch(error){showError(error);}
  if(currentMatch)void links.load(currentMatch.id);
}
async function load(){
  if(loading)return;loading=true;
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    let response,timer;
    try{response=await Promise.race([chrome.tabs.sendMessage(tab?.id,{type:'capture-status'}),new Promise(resolve=>{timer=setTimeout(()=>resolve(null),2000);})]);}catch{}finally{clearTimeout(timer);}
    const summary=await send({type:'popup',id:response?.result?.match?.id});
    connected=!!(response?.ok&&response.version===2&&response.result);
    const capture=connected?response.result:null;
    eligible=connected&&['recording','waiting','saved','review'].includes(capture.kind);
    $('#tracking-text').textContent=capture?.kind==='recording'?'Match stats are saving automatically':connected&&['excluded','blocked','error'].includes(capture?.kind)?capture.title:connected?'Match tracking is ready':'Match tracking starts when you play on RiftAtlas';
    $('#tracking').dataset.live=String(capture?.kind==='recording');
    currentMatch=summary.current||summary.recent;
    $('#match').hidden=!currentMatch;$('#empty').hidden=!!currentMatch;
    if(currentMatch){
      const r=currentMatch;
      $('#match-label').textContent=capture?.kind==='recording'&&capture?.match?.id===r.id?'CURRENT MATCH':'LATEST MATCH';
      $('#outcome').textContent=capture?.kind==='recording'&&capture?.match?.id===r.id?`Turn ${r.lastTurn??'—'}`:({win:'Victory',loss:'Defeat',draw:'Draw'})[r.outcome]||'To review';
      for(const [i,side] of ['self','opponent'].entries()){
        $(`#${side}-name`).textContent=r.names?.[i]||'Player';$(`#${side}-legend`).textContent=r.legends?.[i]||'Legend not recorded';$(`#${side}-score`).textContent=r.scores?.[i]??'—';
      }
      $('#review').textContent=r.reviewed?'Review game':'Finalize match';
      $('#review').disabled=reviewBusy;
      $('#share').href=`companion.html#share=${encodeURIComponent(r.id)}`;$('#share').hidden=!r.reviewed;
      void links.load(r.id);
    }else links.cancel();
    renderVideo();
  }catch(error){showError(error);}finally{loading=false;}
}
async function action(fn){
  if(pending)return;pending=true;showError(null);renderVideo();
  try{await fn();}catch(error){showError(error);}finally{pending=false;await pollVideo();}
}
$('#record').onclick=()=>action(async()=>{
  if(!eligible||status?.active)return;
  if(!await chrome.permissions.request({permissions:['tabCapture']}))throw Error('Allow tab recording to start a video session.');
  await send({type:'video-auto',audio:status?.audio!==false});
});
$('#stop').onclick=()=>action(()=>send({type:'video-stop'}));
$('#highlight').onclick=()=>action(async()=>{await send({type:'video-highlight'});$('#feedback').textContent='Highlight marked';$('#feedback').hidden=false;});
$('#dismiss').onclick=()=>action(()=>send({type:'video-dismiss-notice',notice:status?.notice}));
let removedMatchID=null;
let editing=null,editingStamp='',originalDate='',reviewBusy=false,draftQueue=Promise.resolve(),draftRevision=0,draftFailed=false;
const form=$('#review-form');
function reviewError(message=''){$('#review-error').textContent=message;$('#review-error').hidden=!message;}
function setReviewBusy(value){
  reviewBusy=value;
  for(const control of $('#review-panel').querySelectorAll('input,select,button'))control.disabled=value;
  $('#review').disabled=value;
}
function showReview(visible){
  $('#review-panel').hidden=!visible;document.body.classList.toggle('reviewing',visible);
}
async function openReview(id,draft){
  if(reviewBusy)return;
  setReviewBusy(true);showError(null);
  try{
    const state=await send({type:'read'}),r=state.records.find(r=>r.id===id&&!r.deleted&&!r.groupedBy);
    if(!r)throw Error('This game is no longer available. Open match history to find it.');
    if(draft===undefined)draft=await send({type:'review-draft-read'});
    if(!validReviewDraft(draft)||draft.id!==id)draft=null;
    draftFailed=false;editing=r;editingStamp=draft?.stamp||reviewStamp(r);draftRevision++;
    reviewError();$('#draft-status').textContent=draft?'Unfinished review restored.':'';
    $('#review-title').textContent=r.reviewed?'Review game':'Finalize match';
    $('#series-link').hidden=!r.games;form.hidden=!!r.games;
    $('#series-link').href=`companion.html#review=${encodeURIComponent(r.id)}`;
    showReview(true);
    if(r.games)return;
    fillReviewForm(form,r);originalDate=form.querySelector('[name="date"]').value;
    fillReviewForm(form,r,draft?.values,state.records);
    for(const [i,side] of ['self','opponent'].entries()){
      $(`#review-${side}-name`).textContent=r.names[i];$(`#review-${side}-legend`).textContent=r.legends[i]||'Legend missing';
    }
    $('#match-details').open=![...form.querySelectorAll('[name$="-name"],[name$="-legend"]')].every(input=>input.value.trim());
    $('#finish-confirmation').hidden=r.reviewed||r.outcome!=='unknown';
    $('#game-finished').checked=false;$('#game-finished').required=!$('#finish-confirmation').hidden;
    if(draft&&editingStamp!==reviewStamp(r))reviewError('This game changed since your draft. Reload saved values before confirming.');
  }catch(error){showError(error);}finally{setReviewBusy(false);}
}
function rememberDraft(){
  if(!editing||editing.games||reviewBusy)return;
  const revision=++draftRevision,draft={id:editing.id,stamp:editingStamp,values:rawReviewFields(form)};
  $('#draft-status').textContent='Saving draft…';
  draftQueue=draftQueue.then(()=>send({type:'review-draft',draft})).then(()=>{
    if(revision===draftRevision){draftFailed=false;$('#draft-status').textContent='Draft saved';reviewError();}
  }).catch(error=>{if(revision===draftRevision){draftFailed=true;$('#draft-status').textContent='';reviewError(`Draft not saved: ${error.message}`);}});
}
$('#review').onclick=()=>currentMatch&&openReview(currentMatch.id);
$('#review-back').onclick=async()=>{
  if(reviewBusy)return;
  setReviewBusy(true);await draftQueue;if(!draftFailed)showReview(false);setReviewBusy(false);void load();
};
$('#reload-review').onclick=async()=>{
  if(reviewBusy||!editing)return;
  const id=editing.id;setReviewBusy(true);
  try{await draftQueue;await send({type:'review-draft-clear',id});setReviewBusy(false);await openReview(id,null);}
  catch(error){reviewError(error.message);}finally{setReviewBusy(false);}
};
form.addEventListener('input',rememberDraft);form.addEventListener('change',rememberDraft);
// Reveal any invalid optional detail before Chrome tries to focus it.
form.addEventListener('invalid',event=>{if($('#match-details').contains(event.target))$('#match-details').open=true;},true);
form.onsubmit=async event=>{
  event.preventDefault();if(reviewBusy||!editing)return;
  if(form.reportValidity&&!form.reportValidity())return;
  const id=editing.id,values=reviewValues(form),finished=$('#game-finished').checked;
  if(form.querySelector('[name="date"]').value===originalDate)values.date=editing.date;
  setReviewBusy(true);reviewError();$('#confirm-review').textContent='Saving…';
  try{
    await draftQueue;
    await send({type:'review',id,values,expectedReview:editingStamp,finished});
    draftRevision++;editing=null;showReview(false);await load();
    $('#saved-result').textContent='Match confirmed';$('#saved-result').hidden=false;
  }catch(error){reviewError(error.message);}finally{setReviewBusy(false);$('#confirm-review').textContent='Confirm result';}
};
$('#remove-match').onclick=async()=>{
  if(reviewBusy||!editing)return;
  const id=editing.id;setReviewBusy(true);reviewError();
  try{
    await draftQueue;
    await send({type:'delete',id,expectedReview:editingStamp});
    draftRevision++;editing=null;removedMatchID=id;showReview(false);
    $('#saved-result').hidden=true;$('#match-removal-notice').hidden=false;await load();
  }catch(error){reviewError(error.message);}finally{setReviewBusy(false);}
};
$('#undo-match').onclick=async()=>{
  if(reviewBusy||!removedMatchID)return;
  setReviewBusy(true);$('#undo-match').disabled=true;
  try{await send({type:'restore',id:removedMatchID});removedMatchID=null;$('#match-removal-notice').hidden=true;await load();}
  catch(error){showError(error);}finally{setReviewBusy(false);$('#undo-match').disabled=false;}
};
async function initialize(){
  await load();
  try{const draft=await send({type:'review-draft-read'});if(validReviewDraft(draft)&&!editing)await openReview(draft.id,draft);}
  catch(error){showError(error);}
}
initialize();pollVideo();setInterval(load,5000);setInterval(pollVideo,2000);
