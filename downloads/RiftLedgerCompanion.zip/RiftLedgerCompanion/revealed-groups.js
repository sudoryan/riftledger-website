// Presentation groups retain every underlying card-instance ID.
(() => {
  const nameKey = name => name.normalize('NFC').trim().toLowerCase();
  function groups(cards) {
    const result = new Map(), order = new Map();
    for (const card of cards || []) {
      const name=nameKey(card.name),key = JSON.stringify([name, card.status]);
      if(!order.has(name))order.set(name,order.size);
      if (!result.has(key)) result.set(key, {key, name:card.name, status:card.status, cards:[]});
      result.get(key).cards.push(card);
    }
    return [...result.values()].sort((a,b)=>order.get(nameKey(a.name))-order.get(nameKey(b.name))).map(group => ({...group, count:group.cards.length,
      stamp:JSON.stringify(group.cards.map(c=>[c.id,c.zone||'',c.manual===true,c.editID||'']))}));
  }
  globalThis.RiftLedgerRevealGroups = {groups, nameKey};
})();
