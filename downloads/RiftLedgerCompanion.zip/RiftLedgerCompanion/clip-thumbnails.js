// Decode a few local preview frames in a separate muted element. Never seeks
// or pauses the visible player; stale source/window requests are cancelled.
export function createClipThumbnails(root) {
  const doc=root.ownerDocument;let cancel=()=>{};
  return {
    clear(){cancel();cancel=()=>{};root.replaceChildren();},
    async load(src,start,end){
      cancel();root.replaceChildren();
      if(!src||end<=start)return;
      const canvas=doc.createElement('canvas');if(typeof canvas.getContext!=='function')return;
      canvas.width=160;canvas.height=90;const ctx=canvas.getContext('2d');if(!ctx)return;
      const video=doc.createElement('video');video.muted=true;video.playsInline=true;video.preload='auto';
      let cancelled=false,abortWait=()=>{};
      const clean=()=>{video.pause();video.removeAttribute('src');video.load();};
      cancel=()=>{cancelled=true;abortWait();clean();};
      const wait=name=>new Promise((resolve,reject)=>{
        const clear=()=>{clearTimeout(timer);video.removeEventListener(name,ok);video.removeEventListener('error',bad);abortWait=()=>{};};
        const ok=()=>{clear();resolve();},bad=()=>{clear();reject(Error('Preview frames unavailable'));};
        const timer=setTimeout(bad,4000);abortWait=bad;video.addEventListener(name,ok,{once:true});video.addEventListener('error',bad,{once:true});
      });
      try{
        const ready=wait('loadeddata');video.src=src;video.load();await ready;
        for(let i=0;i<8&&!cancelled;i++){
          const at=Math.max(0,Math.min(video.duration-.05,start+(end-start)*(i+.5)/8));
          if(Math.abs(video.currentTime-at)>.02){const seeked=wait('seeked');video.currentTime=at;await seeked;}
          if(cancelled)break;
          ctx.drawImage(video,0,0,160,90);const img=doc.createElement('img');img.alt='';img.draggable=false;img.src=canvas.toDataURL('image/jpeg',.65);root.append(img);
        }
      }catch{/* The timeline and controls work even when preview decoding fails. */}
      finally{if(!cancelled)clean();}
    }
  };
}
