import {cleanObservation,updateReveals,editReveals,cleanLayout} from './revealed-model.js';
const preferenceKey='revealedCardHelper',prefix='revealedCards:';
export function createRevealController(api) {
  const session=api.storage.session;
  const fallback=new Map();
  const read=async key=>session?(await session.get(key))[key]:fallback.get(key);
  const write=async(key,value)=>session?session.set({[key]:value}):fallback.set(key,value);
  const remove=async key=>session?session.remove(key):fallback.delete(key);
  api.tabs.onRemoved?.addListener(id=>{void remove(prefix+id);});
  const prefs=async()=>{const p=(await api.storage.local.get(preferenceKey))[preferenceKey];return {enabled:p?.enabled===true,layout:cleanLayout(p?.layout)};};
  return async (m,sender) => {
    const own=sender.id===api.runtime.id;
    const page=own && Number.isInteger(sender.tab?.id) && (sender.frameId===0 || sender.frameId==null) &&
      (!sender.documentLifecycle || sender.documentLifecycle==='active') && sender.url?.startsWith('https://play.riftatlas.com/');
    const settings=own && sender.url?.split(/[?#]/)[0]===api.runtime.getURL('companion.html');
    if(!page&&!settings)throw Error('Open Rift Ledger settings or a RiftAtlas game.');
    const p=await prefs();
    if(m.type==='reveal-settings-get')return p;
    if(m.type==='reveal-settings-set') {
      if(!settings || typeof m.enabled!=='boolean')throw Error('Change this in Rift Ledger settings.');
      p.enabled=m.enabled;await api.storage.local.set({[preferenceKey]:p});
      if(!p.enabled){
        if(session){const all=await session.get(null);await session.remove(Object.keys(all).filter(k=>k.startsWith(prefix)));}
        fallback.clear();
      }
      const tabs=await api.tabs.query({});
      await Promise.allSettled(tabs.map(t=>api.tabs.sendMessage(t.id,{type:'reveal-refresh'})));
      return p;
    }
    if(!page)throw Error('Card notes are only available in their game tab.');
    if(m.type==='reveal-layout') {
      p.layout=cleanLayout(m.layout);await api.storage.local.set({[preferenceKey]:p});return p;
    }
    if(!p.enabled)return {...p,state:null};
    const key=prefix+sender.tab.id,previous=await read(key);
    let state;
    if(m.type==='reveal-observe')state=updateReveals(previous,cleanObservation(m.observation));
    else if(m.type==='reveal-edit')state=editReveals(previous,m);
    else throw Error('Unknown revealed-card request.');
    if(JSON.stringify(previous)!==JSON.stringify(state))await write(key,state);
    return {...p,state};
  };
}
