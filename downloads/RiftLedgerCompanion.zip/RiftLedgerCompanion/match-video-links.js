import {videoTime} from './video-model.js';

export function createMatchVideoLinks({root,send,showError}) {
  let target=null,generation=0,stamp='';
  function clear(){root.hidden=true;root.replaceChildren();stamp='';}
  function cancel(){++generation;target=null;clear();}
  async function load(id){
    const request=++generation;
    if(target!==id){target=id;clear();}
    if(!id)return;
    try{
      const recordings=await send({type:'video-match-recordings',id});
      if(request!==generation)return;
      if(!recordings?.length){clear();return;}
      const next=JSON.stringify(recordings);
      if(next===stamp)return;
      stamp=next;root.replaceChildren();root.hidden=false;
      for(const record of recordings){
        const button=root.ownerDocument.createElement('button');button.type='button';button.className='match-video-link';
        const label=root.ownerDocument.createElement('span'),detail=root.ownerDocument.createElement('small');
        label.textContent=`Watch match video${record.game?` · Game ${record.game}`:''}${record.part?` · Part ${record.part}`:''} ↗`;
        detail.textContent=`${videoTime(record.duration)}${record.partial?' · Partial recording':''}`;
        button.append(label,detail);button.onclick=async()=>{
          if(button.disabled)return;button.disabled=true;
          try{showError(null);await send({type:'video-open-page',id:record.id,at:0});}
          catch(error){showError(error);if(target===id)await load(id);}
          finally{button.disabled=false;}
        };
        root.append(button);
      }
    }catch{if(request===generation)clear();}
  }
  return {load,cancel};
}
