import {ACTIVE_VIDEO_STATES} from './video-model.js';
import {webmHeader} from './webm-header.js';
import {fixWebmDuration} from './vendor/webm-duration.js';
const request = r => new Promise((resolve, reject) => { r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); });
const finished = t => new Promise((resolve, reject) => { t.oncomplete = resolve; t.onabort = () => reject(t.error?.name==='QuotaExceededError'?Error('Chrome ran out of storage. Saved footage is kept; free disk space or download and delete older videos.'):t.error || Error('Video storage transaction failed.')); t.onerror = () => {}; });
export class VideoStore {
  constructor(name = 'rift-ledger-videos') { this.name = name; }
  async open() {
    if (!this.connection) this.connection = new Promise((resolve, reject) => {
      const r = indexedDB.open(this.name, 1);
      r.onupgradeneeded = () => {
        r.result.createObjectStore('videos', {keyPath:'id'});
        r.result.createObjectStore('chunks', {keyPath:['id','index']}).createIndex('video', 'id');
      };
      r.onsuccess = () => { r.result.onversionchange = () => { r.result.close(); this.connection = null; }; resolve(r.result); };
      r.onerror = () => reject(r.error);
    });
    return this.connection;
  }
  async list() { const db = await this.open(); return (await request(db.transaction('videos').objectStore('videos').getAll())).sort((a,b) => b.createdAt - a.createdAt); }
  async get(id) { const db = await this.open(); return request(db.transaction('videos').objectStore('videos').get(id)); }
  async create(video) {
    const db = await this.open(), tx = db.transaction('videos','readwrite'), done = finished(tx);
    tx.objectStore('videos').add({...video,bytes:0,chunks:0}); await done;
  }
  async patch(id, patch) {
    const db = await this.open(), tx = db.transaction('videos','readwrite'), done = finished(tx), store = tx.objectStore('videos');
    const current = await request(store.get(id));
    if (current) { const {id:ignored,bytes,chunks,...safe} = patch; store.put({...current,...safe}); }
    await done; return !!current;
  }
  async append(id, blob, cap, duration) {
    if (!blob.size) return;
    const db = await this.open(), tx = db.transaction(['videos','chunks'],'readwrite'), done = finished(tx), store = tx.objectStore('videos');
    const all = await request(store.getAll()), video = all.find(v => v.id === id);
    if (!video || !ACTIVE_VIDEO_STATES.includes(video.status)) { tx.abort(); await done.catch(()=>{}); throw Error('This video is no longer recording.'); }
    if (all.reduce((sum,v)=>sum+v.bytes,0) + blob.size > cap) { tx.abort(); await done.catch(()=>{}); throw Error('Video storage limit reached. Saved footage is kept; delete a video or raise the limit.'); }
    tx.objectStore('chunks').add({id,index:video.chunks,blob});
    store.put({...video,bytes:video.bytes+blob.size,chunks:video.chunks+1,duration}); await done;
  }
  async blob(id) {
    const db = await this.open(), tx = db.transaction(['videos','chunks']);
    const [video, chunks] = await Promise.all([request(tx.objectStore('videos').get(id)),request(tx.objectStore('chunks').index('video').getAll(id))]);
    if (!video || !chunks.length) throw Error('There is no saved footage for this video.');
    chunks.sort((a,b)=>a.index-b.index);
    // A large first frame may arrive in a later chunk than the metadata. Read a
    // bounded prefix across chunk boundaries; never parse or copy the full match.
    const raw=new Blob(chunks.map(c=>c.blob),{type:video.mimeType || 'video/webm'});
    if(raw.type.startsWith('video/mp4'))return raw;
    const header=webmHeader(new Uint8Array(await raw.slice(0,256*1024).arrayBuffer()));
    const prefix=header?await fixWebmDuration(new Blob([header.prefix]),video.duration*1000,{logger:false}):null;
    return prefix?new Blob([prefix,raw.slice(header.offset)],{type:raw.type}):raw;
  }
  async remove(id) { return this.removeMany([id]); }
  async removeMany(ids) {
    if(!Array.isArray(ids)||!ids.length||ids.some(id=>typeof id!=='string'||!id||id.length>200))throw Error('Select videos to delete.');
    const unique=[...new Set(ids)];
    const db=await this.open(),tx=db.transaction(['videos','chunks'],'readwrite'),done=finished(tx),store=tx.objectStore('videos');
    const videos=(await Promise.all(unique.map(id=>request(store.get(id))))).filter(Boolean);
    // Validate the whole selection in the same transaction as deletion. An
    // active row aborts the batch; no earlier selected files disappear first.
    if(videos.some(v=>ACTIVE_VIDEO_STATES.includes(v.status))){tx.abort();await done.catch(()=>{});throw Error('Stop recording before deleting this video. No selected videos were deleted.');}
    for(const id of unique){
      store.delete(id);
      const r=tx.objectStore('chunks').index('video').openKeyCursor(id);
      r.onsuccess=()=>{const cursor=r.result;if(cursor){tx.objectStore('chunks').delete(cursor.primaryKey);cursor.continue();}};
    }
    await done;
    return {count:videos.length,bytes:videos.reduce((sum,v)=>sum+(v.bytes||0),0)};
  }
  async recover() {
    const db = await this.open(), tx = db.transaction('videos','readwrite'), done = finished(tx), store = tx.objectStore('videos');
    const all = await request(store.getAll());
    for (const v of all) if (ACTIVE_VIDEO_STATES.includes(v.status)) store.put({...v,status:'interrupted',reason:'Recording was interrupted. Only footage saved before the interruption is available.'});
    await done;
  }
}
