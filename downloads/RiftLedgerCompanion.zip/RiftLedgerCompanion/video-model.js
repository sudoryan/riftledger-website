export const VIDEO_QUALITIES = [
  {id:'720p', label:'720p · Smaller files', width:1280, height:720, fps:30, bitrate:2_500_000},
  {id:'1080p', label:'1080p · Full HD', width:1920, height:1080, fps:30, bitrate:6_000_000},
  {id:'1440p', label:'1440p · Extra detail', width:2560, height:1440, fps:30, bitrate:10_000_000},
  {id:'2160p', label:'4K · 2160p', width:3840, height:2160, fps:30, bitrate:20_000_000}
];
export const DEFAULT_VIDEO_QUALITY = '1080p';
export const VIDEO_FRAME_RATES = [30, 60];
export const videoFrameRate = value => value===60 ? 60 : 30;
export function videoQuality(id,requestedFrameRate) {
  const quality=VIDEO_QUALITIES.find(q=>q.id===id)||VIDEO_QUALITIES[1],fps=videoFrameRate(requestedFrameRate);
  return {...quality,fps,bitrate:quality.bitrate*fps/30};
}
export function captureConstraints(id,requestedFrameRate) {
  const q=videoQuality(id,requestedFrameRate);
  return {maxWidth:q.width,maxHeight:q.height,maxFrameRate:q.fps};
}
// Older videos have no preset metadata; clips choose a bitrate for the decoded
// source size. Never resize or claim that an old recording gained resolution.
export function clipQuality(source,width,height) {
  return VIDEO_QUALITIES.find(q=>q.id===source.quality)?.id
    || (VIDEO_QUALITIES.find(q=>width<=q.width&&height<=q.height)||VIDEO_QUALITIES.at(-1)).id;
}
// New clips inherit the requested rate, never the current recording preference.
// Older footage without rate metadata was recorded with the 30 fps cap.
export function clipFrameRate(source) {
  return VIDEO_FRAME_RATES.includes(source.requestedFrameRate) ? source.requestedFrameRate : source.frameRate>45 ? 60 : 30;
}
export function videoResolution(record) {
  if(!(record.width>0&&record.height>0))return '';
  const rate=VIDEO_FRAME_RATES.includes(record.requestedFrameRate)?`${record.requestedFrameRate} fps target`:record.frameRate>0?`${Math.round(record.frameRate)} fps source`:'';
  return `${record.width} × ${record.height}${rate?` · ${rate}`:''}`;
}
export const VIDEO_LIMITS = [250, 500, 1000, 2000, 5000, 10000, 20000, 50000];
export const DEFAULT_VIDEO_LIMIT = 500;
export const MAX_RECORD_SECONDS = 7200;
export const ACTIVE_VIDEO_STATES = ['recording', 'processing'];
export const limitBytes = mb => (VIDEO_LIMITS.includes(Number(mb)) ? Number(mb) : DEFAULT_VIDEO_LIMIT) * 1024 * 1024;
export function videoTime(seconds = 0) {
  const n = Math.max(0, Math.floor(seconds));
  return n >= 3600 ? `${Math.floor(n / 3600)}:${String(Math.floor(n / 60) % 60).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}` : `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`;
}
// Keep the existing limits' MB accounting so upgrades never shrink a saved cap.
export const videoLimitLabel = mb => mb >= 1000 ? `${mb / 1000} GB` : `${mb} MB`;
export const videoExtension = mimeType => mimeType?.startsWith('video/mp4') ? 'mp4' : 'webm';
// Match IDs, not names/dates, connect footage to a result. Grouped series retain
// their child IDs; several recordings can belong to a game after a refresh.
export function matchRecordings(videos, match) {
  if(!match?.id||match.deleted||match.groupedBy)return [];
  const ids=match.children?.length?match.children:[match.id];
  return ids.flatMap((id,gameIndex)=>{
    const parts=videos.filter(v=>v.kind==='match'&&v.matchID===id&&v.bytes>0&&['ready','interrupted'].includes(v.status))
      .sort((a,b)=>a.createdAt-b.createdAt||a.id.localeCompare(b.id));
    return parts.map((v,i)=>({id:v.id,duration:v.duration,partial:v.status==='interrupted',
      game:match.children?.length?gameIndex+1:null,part:parts.length>1?i+1:null}));
  });
}
export function videoSize(bytes) {
  const mb=Math.max(0,bytes)/1024/1024;
  return mb>=1000?`${(mb/1000).toFixed(1)} GB`:`${mb.toFixed(1)} MB`;
}
export function clipRange(start, end, duration) {
  start = Number(start); end = Number(end);
  if (![start, end, duration].every(Number.isFinite) || start < 0 || start >= duration || end <= start) throw Error('Choose a start and end within the video.');
  end = Math.min(end, duration);
  if (end - start > 600) throw Error('Clips can be up to 10 minutes. Download the full video for longer footage.');
  return {start, end};
}
export function highlightRange(at, duration) { return {start: Math.max(0, at - 20), end: Math.min(duration, at + 10)}; }
// Markers describe observed public UI changes, never inferred plays or hidden cards.
export function observationMarkers(previous, snapshot, at) {
  if (!snapshot || snapshot.phase !== 'in_game') return [];
  const markers = [];
  const turn = Number(snapshot.turn), player = snapshot.activePlayer;
  if (Number.isInteger(turn) && turn > 0 && [0, 1].includes(player) && (previous?.turn !== turn || previous?.activePlayer !== player)) {
    const partial = !previous || turn < previous.turn || turn > previous.turn + 1;
    markers.push({kind: 'turn', at, turn, player, label: `${partial ? 'Observed ' : ''}turn ${turn} · ${snapshot.names?.[player] || (player ? 'Opponent' : 'You')}`});
  }
  if (previous?.scores?.length === 2 && snapshot.scores?.length === 2 && snapshot.scores.some((n, i) => n !== previous.scores[i])) {
    markers.push({kind: 'score', at, label: `Score ${snapshot.scores.join(' – ')}`});
  }
  if (['win', 'loss', 'draw'].includes(snapshot.outcome) && snapshot.outcome !== previous?.outcome) {
    markers.push({kind: 'result', at, label: ({win:'Victory', loss:'Defeat', draw:'Draw'})[snapshot.outcome]});
  }
  return markers;
}
