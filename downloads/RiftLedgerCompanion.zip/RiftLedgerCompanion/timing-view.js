import {timingSummary, duration} from './turn-timing.js';
import {renderPriorityTiming} from './priority-view.js';
const node = (tag, text, cls) => { const e = document.createElement(tag); if (text != null) e.textContent = text; if (cls) e.className = cls; return e; };
export function renderTiming(container, record, {live = false, timeline = false} = {}) {
  const summary = timingSummary(record, live ? Date.now() : undefined);
  const values = summary ? {total:duration(summary.total), current:duration(summary.current?.seconds)} : {};
  summary?.players.forEach((p,i) => { for (const key of ['total','count','average','shortest','longest']) values[`${i}-${key}`] = key === 'count' ? String(p[key]) : duration(p[key]); });
  record.timing?.turns.forEach((turn,i) => { values[`turn-${i}`] = duration(turn.seconds); });
  const layout = JSON.stringify([record.id,record.names,record.priorityTiming,record.reviewed,record.status,live,timeline,summary?.partial,summary?.unassigned,
    summary?.current?.number,summary?.current?.player,summary?.current?.running,record.timing?.turns.map(t=>[t.number,t.player,t.complete])]);
  const paint = () => container.querySelectorAll('[data-clock]').forEach(e => { e.textContent = values[e.dataset.clock]; });
  if (container.dataset.layout === layout) { paint(); return; }
  container.dataset.layout = layout;
  const clock = (tag, key) => { const e=node(tag,values[key]);e.dataset.clock=key;return e; };
  const wasOpen = container.querySelector('details')?.open;
  container.replaceChildren();
  const priority = node('section'); renderPriorityTiming(priority, record); container.append(priority);
  if (!summary) { container.append(node('p', 'Turn timing wasn’t recorded for this game.', 'timing-note')); return; }
  const header = node('div', null, 'timing-heading');
  header.append(node('span', 'CAPTURED MATCH TIME'), clock('strong','total'));
  container.append(header);
  if (live && summary.current) {
    const current = summary.current;
    const row = node('div', null, 'turn-clock');
    row.append(node('span', `${record.names[current.player]} · Turn ${current.number}${current.running ? '' : ' · Paused'}`), clock('b','current'));
    container.append(row);
  }
  const details = node('details', null, 'timing-details'); details.open = !!wasOpen || timeline;
  details.append(node('summary', 'Whole-turn duration'));
  const table = node('table'); const head = node('tr');
  head.append(node('th',''), ...record.names.map(name => node('th', name))); table.append(head);
  for (const [label, key] of [['Total time','total'],['Complete turns','count'],['Average','average'],['Shortest','shortest'],['Longest','longest']]) {
    const row = node('tr'); row.append(node('th',label), ...summary.players.map((p,i) => clock('td',`${i}-${key}`))); table.append(row);
  }
  details.append(table); container.append(details);
  details.append(node('p', `${summary.partial ? 'Partial capture. ' : ''}${summary.unassigned > 0 ? duration(summary.unassigned) + ' unassigned. ' : ''}Elapsed time on each player’s turns includes opponent responses. Only fully observed turns count toward average, shortest and longest.`, 'timing-note'));
  if (timeline && record.timing.turns.length) {
    const list = node('ol', null, 'turn-list');
    for (const [i,t] of record.timing.turns.entries()) {
      const row = node('li');row.append(node('span', `Turn ${t.number} · ${record.names[t.player]}${t.complete ? '' : ' · Partial'}`), clock('strong',`turn-${i}`));list.append(row);
    }
    container.append(list);
  }
}
