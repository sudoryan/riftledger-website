// Shared by the content scripts and worker. Only already-observed public card assets.
(() => {
  function cleanURL(value) {
    if (typeof value !== 'string' || value.length > 2048) return '';
    try {
      const url = new URL(value);
      if (url.protocol !== 'https:' || url.hostname !== 'assets.riftatlas-workers.com' ||
          url.port || url.username || url.password || url.hash) return '';
      if (!/^\/(?:cdn-cgi\/image\/[a-z0-9=,.-]+\/)?riftbound\/cards\/(?:original|small-v2)\/[a-z0-9_-]+\.(?:webp|png|jpe?g)$/i.test(url.pathname)) return '';
      if ([...url.searchParams].some(([key, val]) => key !== 'v' || !/^[a-z0-9_-]{1,80}$/i.test(val))) return '';
      return url.href;
    } catch { return ''; }
  }
  globalThis.RiftLedgerRevealArt = {cleanURL};
})();
