// Deliberately excludes footage, player names, notes, URLs and microphone IDs.
export function recordingReport({version,status,activity=[],videos=[],matches=[],now=Date.now()}) {
  const fields=(value,keys)=>Object.fromEntries(keys.filter(k=>value?.[k]!==undefined).map(k=>[k,value[k]]));
  return {
    schema:'rift-ledger-recording-report',version:1,extensionVersion:version,createdAt:now,
    current:fields(status.active,['id','kind','phase','quality','requestedFrameRate','elapsed','bytes','savedSeconds','games']),
    notice:status.notice||'',quality:status.quality,requestedFrameRate:status.requestedFrameRate,limitMB:status.limitMB,unlimitedStorage:status.unlimitedStorage===true,storageEstimate:status.storageEstimate,
    activity:activity.slice(-40).map(a=>fields(a,['at','kind','id','mode','phase','quality','requestedFrameRate','reason'])),
    videos:videos.map(v=>fields(v,['id','matchID','kind','status','createdAt','finishedAt','duration','bytes','chunks','quality','requestedFrameRate','mimeType','width','height','frameRate','reason'])),
    recentMatches:matches.filter(m=>!m.deleted&&!m.games).slice(0,20).map(m=>({id:m.id,date:m.date,videoIDs:videos.filter(v=>v.matchID===m.id&&v.kind==='match').map(v=>v.id)}))
  };
}
