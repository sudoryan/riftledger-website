import {validSnapshot, isSetupPhase} from './core.js';

export function matchSummary(r) {
  if (!r || r.deleted || r.groupedBy) return null;
  if (r.games) {
    const timing = r.games.every(g => g.timing) ? {version:1, turns:r.games.flatMap(g => g.timing.turns),
      unassignedSeconds:r.games.reduce((n,g)=>n+g.timing.unassignedSeconds,0), partial:r.games.some(g=>g.timing.partial)} : undefined;
    r = {...r, timing, priorityTiming:undefined, _timingCursor:undefined, seconds:r.games.reduce((n,g)=>n+g.seconds,0)};
  }
  const {id, names, legends, scores, date, seenAt, seconds, lastTurn, outcome, reviewed, status, partial, timing, priorityTiming, _timingCursor, opponentExperience} = r;
  return {id, names, legends, scores, date, seenAt, seconds, lastTurn, outcome, reviewed, status, partial, timing, priorityTiming, _timingCursor, opponentExperience};
}
export function captureStatus(state, s, now = Date.now()) {
  const status = (kind, title, detail, match = null) => ({kind, title, detail, match, checkedAt: now});
  if (!s) return status('waiting', 'Ready for your next game', 'Capture starts when a multiplayer game begins.');
  if (s.reason === 'practice') return status('excluded', 'Practice is not recorded', 'Solo games stay out of your match history.');
  if (s.reason === 'spectator') return status('excluded', 'Spectator view', 'Only games you play are recorded.');
  // Setup can render before the room label, player names or score controls.
  // It is safe to arm and wait here; in-game capture still requires all of them.
  if ((isSetupPhase(s.phase) || /^waiting(?:_[a-z]+)*$/.test(s.phase)) &&
      validSnapshot({...s,room:s.room == null || s.room === '' ? 'pending' : s.room})) {
    return status('waiting', 'Waiting for the game to start', 'Finish battlefield selection and mulligans. Game capture starts automatically when the board is ready.',
      s.names.every(n=>n.trim()) ? {names:s.names,legends:s.legends,scores:s.scores,lastTurn:s.turn} : null);
  }
  if (!validSnapshot(s)) return status('blocked', 'Board not recognized', 'A required board field is missing. Refresh RiftAtlas; if this persists, the reader needs an update.');
  if (!s.playable) {
    return status('blocked', 'Waiting for player controls', 'No match is being saved yet. Waiting for both players and your score controls.');
  }
  if (s.names.some(n => !n.trim())) return status('blocked', 'Waiting for player names', 'No match is being saved yet. Both player names must be visible.');
  const r = state.records.find(r => r.id === state.rooms[JSON.stringify([s.room, ...s.names])]?.id);
  if (s.phase !== 'in_game') {
    return status('blocked', 'Game phase not recognized', 'Your previous captures are safe. This board is not currently being recorded.');
  }
  if (r?.deleted) return status('excluded', 'Game removed', 'This game stays removed. Restore it from history to keep it.');
  if (r?.reviewed) return status('saved', 'Result confirmed', 'Your reviewed result is saved locally. Open the extension to send it to your phone.', matchSummary(r));
  if (!r) return status('blocked', 'Capture has not started', 'No game has been saved. Refresh RiftAtlas and check again.');
  if (r.outcome !== 'unknown') return status('review', 'Result captured', 'Saved on this browser. Review the result before sending it to your phone.', matchSummary(r));
  return status('recording', 'Recording your game', r.partial
    ? 'Scores are saving locally. Capture started partway through this game.'
    : 'Scores and legends are saving locally as you play.', matchSummary(r));
}
export function popupSummary(state, id) {
  const records = state.records.filter(r => !r.deleted && !r.groupedBy);
  return {noticeEnabled:state.noticeEnabled !== false, pending: records.filter(r => !r.reviewed).length,
    ready: records.filter(r => r.reviewed).length, recent: matchSummary(records[0]),
    current: matchSummary(records.find(r=>r.id===id))};
}
