import {clipRange,clipQuality,clipFrameRate} from './video-model.js';
// Encoding runs in the offscreen document so dismissing the popup cannot cancel it.
export async function startClip({store,engine,id,start,end,cap,onCleanup=()=>{}}) {
  if(engine.status())throw Error('Stop recording or wait for the current clip before creating another clip.');
  const source=await store.get(id);
  if(!source||['recording','processing'].includes(source.status))throw Error('Stop and save this video first.');
  const range=clipRange(start,end,source.duration);
  const blob=await store.blob(id), url=URL.createObjectURL(blob), video=document.createElement('video');
  video.muted=true;video.playsInline=true;video.preload='auto';video.src=url;document.body.append(video);
  let stream, cleaned=false, timer;
  const cleanup=()=>{if(cleaned)return;cleaned=true;clearInterval(timer);video.pause();stream?.getTracks().forEach(t=>t.stop());video.removeAttribute('src');video.load();video.remove();URL.revokeObjectURL(url);onCleanup();};
  try {
    await mediaEvent(video,'loadeddata');
    if(range.start>0){video.currentTime=range.start;await mediaEvent(video,'seeked');}
    if(typeof video.captureStream!=='function')throw Error('This browser cannot export clips. Download the full video instead.');
    stream=video.captureStream();
    // captureStream acquires tracks once playback starts on Chromium.
    await video.play();
    if(!stream.getVideoTracks().length)await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('Could not read video frames.')),5000);stream.addEventListener('addtrack',()=>{if(stream.getVideoTracks().length){clearTimeout(t);resolve();}});});
    const state=await engine.start(stream,{cap,kind:'clip',microphone:source.microphone,audio:source.audio,quality:clipQuality(source,video.videoWidth,video.videoHeight),requestedFrameRate:clipFrameRate(source),parentID:id,matchID:source.matchID,names:source.names,legends:source.legends,sourceStart:range.start,sourceEnd:range.end,maxSeconds:range.end-range.start+2});
    engine.active.done.finally(cleanup);
    video.addEventListener('ended',()=>{void engine.stop();},{once:true});
    video.addEventListener('error',()=>{void engine.stop('Could not finish reading the source video.');},{once:true});
    timer=setInterval(()=>{
      if(!engine.active||engine.active.id!==state.id){cleanup();return;}
      engine.active.progress=Math.max(0,Math.min(1,(video.currentTime-range.start)/(range.end-range.start)));
      if(video.currentTime>=range.end)void engine.stop();
    },40);
    return state;
  } catch(error){cleanup();throw error;}
}
export function mediaEvent(media,name,timeout=15000) {
  return new Promise((resolve,reject)=>{
    const clean=()=>{clearTimeout(timer);media.removeEventListener(name,ok);media.removeEventListener('error',bad);};
    const ok=()=>{clean();resolve();},bad=()=>{clean();reject(Error('This saved video could not be decoded.'));};
    const timer=setTimeout(()=>{clean();reject(Error('Timed out while loading the video.'));},timeout);
    media.addEventListener(name,ok,{once:true});media.addEventListener('error',bad,{once:true});
  });
}
