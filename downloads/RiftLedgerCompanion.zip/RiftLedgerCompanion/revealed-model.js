// Session-only notes. Card identities come from visible board surfaces, never deck state.
import './revealed-art.js';
import './revealed-groups.js';
export const REVEAL_LIMIT = 100;
const text = (v, max) => typeof v === 'string' && v.length <= max && !/[\u0000-\u001f]/.test(v) ? v.trim() : '';
function clearEdit(card) { delete card.editID; delete card.groupMark; }
function pruneUndo(state) {
  if(state.undo)state.undo=state.undo.filter(u=>state.cards.some(c=>c.id===u.id&&c.editID===u.actionID));
}
export function cleanObservation(value) {
  if (value === null) return null;
  if (!value || !Array.isArray(value.cards) || value.cards.length > 200) throw Error('Invalid revealed-card observation.');
  const room=text(value.room,80), viewer=text(value.viewer,100), opponent=text(value.opponent,100);
  if (!room || !viewer || !opponent || viewer === opponent || !['setup','game'].includes(value.phase) ||
      !Number.isInteger(value.turn) || value.turn < 0 || value.turn > 999) throw Error('Invalid game context.');
  return {room,viewer,opponent,phase:value.phase,turn:value.turn,name:text(value.name,60),cards:value.cards.map(card=>{
    const id=text(card.id,160),name=text(card.name,160);
    if (!id || !name || !['hand','base','battlefieldA','battlefieldB','trash'].includes(card.zone)) throw Error('Invalid visible card.');
    const artwork=globalThis.RiftLedgerRevealArt.cleanURL(card.artwork);
    return {id,name,zone:card.zone,...(artwork?{artwork}:{})};
  })};
}
export function updateReveals(previous, observation, makeID = () => crypto.randomUUID()) {
  if (!observation) return null;
  const key=JSON.stringify([observation.room,observation.viewer,observation.opponent]);
  // A setup transition marks a new game even when the same room and players continue.
  const reset=!previous || previous.key!==key || observation.phase==='setup' && previous.phase!=='setup' ||
    observation.turn===1 && previous.turn>1;
  const state=reset ? {key,token:makeID(),cards:[],ignored:[]} : structuredClone(previous);
  state.phase=observation.phase;state.turn=observation.turn;state.name=observation.name;
  if(observation.phase!=='game')return state;
  const cards=new Map(),ambiguous=new Set();
  for(const card of observation.cards){
    const prior=cards.get(card.id);
    if(prior&&(prior.name!==card.name||prior.zone!==card.zone))ambiguous.add(card.id);
    cards.set(card.id,card);
  }
  for(const id of ambiguous)cards.delete(id);
  for(const card of cards.values()) {
    let entry=state.cards.find(c=>c.id===card.id);
    if(!entry && card.zone==='hand' && !state.ignored.includes(card.id) && state.cards.length<REVEAL_LIMIT) {
      entry={id:card.id,name:card.name,status:'known',source:'reveal',turn:observation.turn,zone:'hand'};state.cards.push(entry);
    }
    if(!entry || entry.source==='manual')continue;
    // Keep the observed face after concealment and across refreshes. Do not guess
    // art by name, or replace it with a different face on an ambiguous instance.
    if(entry.name===card.name){
      const artwork=globalThis.RiftLedgerRevealArt.cleanURL(card.artwork);
      if(artwork)entry.artwork=artwork;
    }
    if(entry.zone!==card.zone) {
      if(['base','battlefieldA','battlefieldB'].includes(card.zone)) {
        // A grouped check means "one copy", not a specific hidden instance.
        // Reconcile it with the next visible play of a revealed copy, once.
        if(entry.status!=='played') {
          const pending=state.cards.find(c=>c.source==='reveal'&&c.status==='played'&&c.groupMark&&
            globalThis.RiftLedgerRevealGroups.nameKey(c.name)===globalThis.RiftLedgerRevealGroups.nameKey(entry.name));
          if(pending){Object.assign(pending,pending.groupMark);clearEdit(pending);}
        }
      }
      // A discard is not proof that a spell was played. Unknown/missing cards stay known.
      if(card.zone!=='trash'||entry.status!=='played'){
        entry.status=card.zone==='hand'?'known':card.zone==='trash'?'moved':'played';
        entry.manual=false;
      }
      entry.zone=card.zone;
      clearEdit(entry);
    }
  }
  pruneUndo(state);
  return state;
}
export function editReveals(state, message, makeID=()=>crypto.randomUUID()) {
  if(!state || state.phase!=='game' || state.token!==message.token)throw Error('The game changed. Try again.');
  const next=structuredClone(state);
  if(['play-one','restore-one','remove-one'].includes(message.action)) {
    const group=globalThis.RiftLedgerRevealGroups.groups(next.cards).find(g=>g.key===message.group);
    if(!group||group.stamp!==message.stamp)throw Error('The card list changed. Try again.');
    const card=group.cards[0];
    if(message.action==='remove-one')return editReveals(next,{token:state.token,action:'remove',id:card.id},makeID);
    const played=message.action==='play-one';
    if(played===(card.status==='played'))throw Error('The card list changed. Try again.');
    const before={status:card.status,manual:card.manual===true},actionID=makeID();
    clearEdit(card);card.status=played?'played':'known';card.manual=true;card.editID=actionID;
    if(played&&card.source==='reveal'&&card.zone==='hand')card.groupMark=before;
    next.undo=[...(next.undo||[]),{id:card.id,name:card.name,actionID,before}].slice(-REVEAL_LIMIT);
  } else if(message.action==='undo') {
    pruneUndo(next);const undo=next.undo?.at(-1);
    if(!undo||undo.actionID!==message.actionID)throw Error('This change can no longer be undone.');
    const card=next.cards.find(c=>c.id===undo.id);
    Object.assign(card,undo.before);clearEdit(card);next.undo.pop();
  } else if(message.action==='add') {
    const name=text(message.name,160);
    if(!name)throw Error('Enter a card name.');
    if(next.cards.length>=REVEAL_LIMIT)throw Error('The list is full. Remove a card first.');
    next.cards.push({id:`manual:${makeID()}`,name,status:'known',source:'manual',turn:state.turn});
  } else {
    const card=next.cards.find(c=>c.id===message.id);
    if(!card)throw Error('This card is no longer listed.');
    if(message.action==='remove') {
      next.cards=next.cards.filter(c=>c!==card);
      if(card.source!=='manual')next.ignored=[...next.ignored,card.id].slice(-200);
    } else if(message.action==='played' && typeof message.played==='boolean') {
      card.status=message.played?'played':'known';card.manual=true;clearEdit(card);
    } else throw Error('Unknown card action.');
  }
  pruneUndo(next);
  return next;
}
export function cleanLayout(value={}) {
  const bound=(v,lo,hi,fallback)=>Number.isFinite(v)?Math.min(hi,Math.max(lo,Math.round(v))):fallback;
  return {x:bound(value.x,0,20000,24),y:bound(value.y,0,20000,110),width:bound(value.width,210,600,250),height:bound(value.height,120,900,320),collapsed:value.collapsed===true};
}
