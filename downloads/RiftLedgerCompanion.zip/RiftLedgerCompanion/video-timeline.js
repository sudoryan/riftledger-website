import {highlightRange,videoTime} from './video-model.js';

// Use recording time, including for clips from a partially observed game.
export function timelineMarkers(record) {
  return (record.markers||[]).filter(m=>m&&Number.isFinite(m.at)&&m.at>=0&&(m.at<record.duration||m.at===record.duration&&m.kind!=='turn'))
    .map(m=>({...m})).sort((a,b)=>a.at-b.at);
}

export function timelineRange(marker,markers,duration) {
  return marker.kind==='turn'
    ?{start:marker.at,end:markers.find(m=>m.kind==='turn'&&m.at>marker.at)?.at??duration}
    :highlightRange(marker.at,duration);
}

// These are elapsed turn segments in the recording, not either player's priority
// clock. Score/highlight markers do not end a turn; the result excludes post-roll.
export function timelineTurnDuration(marker,markers,duration) {
  if(marker.kind!=='turn')return null;
  const index=markers.indexOf(marker);
  if(index<0)return null;
  const later=markers.slice(index+1);
  const next=later.find(m=>m.kind==='turn');
  // A result followed by another turn was retracted. Only use a terminal result.
  const boundary=next||later.findLast(m=>m.kind==='result');
  const end=boundary?.at??duration;
  const number=m=>Number(m.turn||String(m.label||'').match(/turn (\d+)/i)?.[1]);
  const from=number(marker),to=boundary?.kind==='turn'?number(boundary):null;
  const partial=!boundary||/^Observed /i.test(marker.label||'')||
    later.some(m=>m.kind==='gap'&&m.at<=end)||
    boundary.kind==='turn'&&(!Number.isInteger(from)||!Number.isInteger(to)||to!==from+1);
  return {seconds:Math.max(0,end-marker.at),partial};
}

export function timelineLabel(marker,names=[]) {
  const label=String(marker.label||'');
  if(marker.kind==='turn') {
    const number=marker.turn||label.match(/turn (\d+)/i)?.[1];
    const player=label.includes(' · ')?label.slice(label.indexOf(' · ')+3):names[marker.player];
    return {title:number?`Turn ${number}`:label||'Turn',subtitle:player||'',observed:/^Observed /i.test(label),icon:number||'•'};
  }
  if(marker.kind==='score')return {title:label.replace(/^Score\s+/i,'')||'Score update',subtitle:'Score updated',icon:'◇'};
  if(marker.kind==='highlight')return {title:label||'Highlight',subtitle:'Saved moment',icon:'★'};
  if(marker.kind==='result')return {title:label||'Game ended',subtitle:'Result observed',icon:'◆'};
  return {title:label||'Moment',subtitle:'',icon:'•'};
}

export function createVideoTimeline({root,onChoose}) {
  const doc=root.ownerDocument,$=s=>root.querySelector(s);
  const node=(tag,text,cls)=>{const e=doc.createElement(tag);if(text!=null)e.textContent=text;if(cls)e.className=cls;return e;};
  root.innerHTML=`<div class="timeline-heading"><h3>Turns &amp; highlights</h3><span id="video-marker-count"></span></div>
    <div class="timeline-playback"><span><span class="timeline-playhead-dot" aria-hidden="true"></span>PLAYBACK <strong id="video-timeline-time">0:00</strong><span id="video-timeline-duration"></span></span><button id="video-current-moment" type="button" title="Show the moment at the current playback position">Locate ↘</button></div>
    <div class="timeline-progress" aria-hidden="true"><span id="video-timeline-progress"></span></div>
    <div class="timeline-filters" role="group" aria-label="Timeline events"><button type="button" data-filter="all" aria-pressed="true">All</button><button type="button" data-filter="turns" aria-pressed="false">Turns</button><button type="button" data-filter="key" aria-pressed="false">Key moments</button></div>
    <p id="video-no-markers" class="video-note" role="status"></p><ol id="video-markers" aria-label="Game timeline"></ol>`;
  let markers=[],duration=0,filter='all',rows=[],time=0,activeTime=null;
  const visible=m=>filter==='all'||(filter==='turns'?m.kind==='turn':['score','highlight','result'].includes(m.kind));
  function update(at) {
    time=Number.isFinite(at)?Math.max(0,Math.min(at,duration)):0;
    $('#video-timeline-time').textContent=videoTime(time);
    $('#video-timeline-progress').style.width=`${duration>0?time/duration*100:0}%`;
    activeTime=null;
    for(const m of markers){if(m.at>time)break;activeTime=m.at;}
    for(const {marker,button,item} of rows){
      const current=marker.at===activeTime;
      button.setAttribute('aria-current',current?'true':'false');
      item.dataset.past=String(marker.at<time&&!current);
    }
    $('#video-current-moment').disabled=activeTime==null;
  }
  function applyFilter() {
    let count=0;
    for(const {marker,item} of rows){item.hidden=!visible(marker);if(!item.hidden)count++;}
    for(const button of root.querySelectorAll('[data-filter]'))button.setAttribute('aria-pressed',String(button.dataset.filter===filter));
    $('#video-marker-count').textContent=`${count}${count===markers.length?'':` / ${markers.length}`} moments`;
    $('#video-no-markers').hidden=count>0;
    $('#video-no-markers').textContent=markers.length?'No events in this filter. Try All to see the full timeline.':'No moments captured. You can still choose a clip range.';
  }
  for(const button of root.querySelectorAll('[data-filter]'))button.onclick=()=>{filter=button.dataset.filter;applyFilter();$('#video-markers').scrollTop=0;};
  $('#video-current-moment').onclick=()=>{
    if(activeTime==null)return;
    filter='all';applyFilter();
    // Scroll only this list. Playback updates never move a user's scroll position.
    const item=rows.find(row=>row.marker.at===activeTime)?.item,list=$('#video-markers');
    if(item){const r=item.getBoundingClientRect(),l=list.getBoundingClientRect();list.scrollTop+=r.top-l.top-(list.clientHeight-r.height)/2;}
  };
  function set(record,at=0) {
    duration=Math.max(0,Number(record.duration)||0);markers=timelineMarkers(record);filter='all';rows=[];
    const list=$('#video-markers');list.replaceChildren();list.scrollTop=0;
    $('#video-timeline-duration').textContent=` / ${videoTime(duration)}`;
    for(const marker of markers) {
      const kind=['turn','score','highlight','result'].includes(marker.kind)?marker.kind:'moment';
      const label=timelineLabel(marker,record.names);
      const item=node('li',null,'video-event'),button=node('button',null,`video-marker ${kind}`);
      button.type='button';button.dataset.player=String(marker.player??'');
      const icon=node('span',label.icon,'timeline-icon');icon.setAttribute('aria-hidden','true');
      const content=node('span',null,'timeline-content'),title=node('span',null,'timeline-title');
      title.append(node('strong',label.title));
      if(label.observed)title.append(node('span','Observed','timeline-observed'));
      content.append(title);if(label.subtitle)content.append(node('span',label.subtitle,'timeline-subtitle'));
      const turn=timelineTurnDuration(marker,markers,duration);
      const length=turn?`${turn.partial?'Recorded':'Turn length'} · ${videoTime(turn.seconds)}${turn.partial?' · Partial turn':''}`:'';
      if(turn){
        const detail=node('span',length,'timeline-turn-length');
        detail.title=turn.partial?'Only the observed portion of this turn is available.':'Elapsed turn time, including both players’ priority.';
        content.append(detail);
      }
      const timestamp=node('span',videoTime(marker.at),'timeline-time');
      timestamp.title='Position in the video';
      button.append(icon,content,timestamp);
      button.setAttribute('aria-label',`${videoTime(marker.at)} · ${label.observed?'Observed ':''}${label.title}${label.subtitle?` · ${label.subtitle}`:''}${length?` · ${length}`:''}`);
      button.onclick=()=>onChoose(timelineRange(marker,markers,duration));
      item.append(button);list.append(item);rows.push({marker,item,button});
    }
    applyFilter();update(at);
  }
  set({duration:0});
  return {set,update,clear:()=>set({duration:0})};
}
