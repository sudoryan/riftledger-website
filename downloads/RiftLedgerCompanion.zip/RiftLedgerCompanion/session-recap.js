import {timingSeconds} from './turn-timing.js';

export const sessionTags = ['Misplay', 'Mulligan', 'Rules question', 'Tested deck'];
export const sessionNoteLimit = 2000;
const pad = n => String(n).padStart(2, '0');
export function sessionDay(value = Date.now()) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return null;
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}
export function validSessionDay(day) {
  if (typeof day !== 'string' || !/^20\d{2}-\d{2}-\d{2}$/.test(day)) return false;
  const [year, month, date] = day.split('-').map(Number);
  return sessionDay(new Date(year, month - 1, date, 12)) === day;
}
export function shiftSessionDay(day, amount) {
  if (!validSessionDay(day)) throw Error('Choose a valid session date.');
  const [year, month, date] = day.split('-').map(Number);
  return sessionDay(new Date(year, month - 1, date + amount, 12));
}
export function cleanSessionNote(note) {
  if (!note || typeof note.text !== 'string' || note.text.length > sessionNoteLimit ||
      !Array.isArray(note.tags) || note.tags.length > sessionTags.length ||
      !note.tags.every(tag => sessionTags.includes(tag))) throw Error('Keep session notes within 2,000 characters and choose a listed tag.');
  return {text:note.text, tags:sessionTags.filter(tag => note.tags.includes(tag))};
}
function tally(records) {
  const wins = records.filter(r => r.outcome === 'win').length;
  const losses = records.filter(r => r.outcome === 'loss').length;
  const draws = records.filter(r => r.outcome === 'draw').length;
  const count = wins + losses + draws;
  return {count, wins, losses, draws, winRate:count ? Math.round(wins / count * 100) : null};
}
export function sessionRecap(records, day) {
  if (!validSessionDay(day)) throw Error('Choose a valid session date.');
  const visible = records.filter(r => !r.deleted && !r.groupedBy &&
    Number.isFinite(r.date) && sessionDay(r.date) === day);
  const matches = visible.filter(r => r.reviewed && ['win','loss','draw'].includes(r.outcome))
    .sort((a,b) => b.date - a.date || String(a.id).localeCompare(String(b.id)));
  const games = matches.flatMap(r => (r.games || [r]).map(g => ({...g, partial:(!r.games && r.partial) || g.partial})));
  let seconds = 0, timedGames = 0, partialGames = 0;
  for (const game of games) {
    // A series copies its first game's timing onto the parent. Count its children only.
    const value = game.timing ? timingSeconds(game.timing) : game.seconds;
    if (!Number.isFinite(value) || value < 0 || (!game.timing && value === 0)) continue;
    seconds += value; timedGames++;
    if (game.partial || game.timing?.partial) partialGames++;
  }
  const groups = new Map();
  for (const r of matches) {
    const legends = [0,1].map(i => r.legends?.[i]?.trim() || 'Unknown legend');
    const key = JSON.stringify(legends);
    if (!groups.has(key)) groups.set(key, {legends, records:[]});
    groups.get(key).records.push(r);
  }
  const matchups = [...groups.values()].map(g => ({legends:g.legends, ...tally(g.records)}))
    .sort((a,b) => b.count - a.count || a.legends.join().localeCompare(b.legends.join()));
  return {day, ...tally(matches), matches, matchups, games:games.length,
    pending:visible.length - matches.length, seconds, timedGames, partialGames,
    missingTime:games.length - timedGames, hasSeries:matches.some(r => !!r.games)};
}
