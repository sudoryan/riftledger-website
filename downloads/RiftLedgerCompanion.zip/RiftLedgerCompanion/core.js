import {observeTiming, interruptTiming, portableTiming} from './turn-timing.js';
import {experienceLevels, rememberExperienceReview} from './opponent-memory.js';
import {observePriorityTiming, portablePriorityTiming} from './priority-timing.js';
export {experienceLevels} from './opponent-memory.js';
export const emptyState = () => ({version: 1, records: [], rooms: {}});
const uuid = () => crypto.randomUUID();
const text = (value, limit) => typeof value === 'string' && value.trim().length <= limit;
const score = n => n === null || Number.isInteger(n) && n >= 0 && n <= 999;
export function setExperience(record, value) {
  if (!record || record.deleted || record.groupedBy) throw new Error('This game is no longer available.');
  if (!Object.hasOwn(experienceLevels, value)) throw new Error('Choose a valid opponent experience.');
  record.opponentExperience = value;
  record.opponentExperienceUpdatedAt = Date.now();
  return record;
}
export function experienceStats(records) {
  const ready = records.filter(r => r.reviewed && !r.deleted && !r.groupedBy);
  return Object.entries(experienceLevels).map(([value, label]) => {
    const matches = ready.filter(r => (r.opponentExperience || 'unrated') === value);
    const wins = matches.filter(r => r.outcome === 'win').length, draws = matches.filter(r => r.outcome === 'draw').length;
    return {value, label, played:matches.length, wins, draws, losses:matches.length-wins-draws,
      winRate:matches.length ? Math.round(wins/matches.length*100) : null};
  });
}
export function validSnapshot(s) {
  return s && text(s.room, 40) && s.room.length > 0 && text(s.phase, 40) && typeof s.playable === 'boolean' &&
    [s.names, s.legends, s.scores].every(a => Array.isArray(a) && a.length === 2) &&
    s.names.every(n => text(n, 60)) && s.legends.every(n => text(n, 160)) && s.scores.every(score) &&
    (s.turn === null || Number.isInteger(s.turn) && s.turn >= 0 && s.turn <= 999) &&
    [undefined, null, 0, 1].includes(s.activePlayer) && [null, 0, 1].includes(s.first) && ['unknown', 'win', 'loss', 'draw'].includes(s.outcome);
}
export const isSetupPhase = phase => typeof phase === 'string' && phase.length <= 40 &&
  /^(?:mulligan|battlefield|roll|initiative|setup|pregame|sideboard)(?:_[a-z]+)*$/.test(phase);
export function observe(state, s, now = Date.now(), context = {}) {
  if (!validSnapshot(s) || ['practice','spectator'].includes(s.reason) || s.names.some(n => !n.trim())) {
    if (context.session) interruptTiming(state.records, context.session);
    return state;
  }
  const key = JSON.stringify([s.room, ...s.names]);
  let room = state.rooms[key];
  let record = state.records.find(r => r.id === room?.id);
  if (s.phase !== 'in_game') {
    if (record) interruptTiming([record]);
    // Only an observed pregame phase can split a series. Lobby/disconnect is not a result.
    if (room && isSetupPhase(s.phase)) {
      room.next = true;
      if (record && !record.reviewed) record.status = 'review';
    }
    return state;
  }
  if (!s.playable) {
    if (context.session) interruptTiming(state.records, context.session);
    return state;
  }
  if (!room) room = state.rooms[key] = {id: null, next: false};
  const reset = record && s.turn === 1 && record.lastTurn > 1 && s.scores.every(n => n === 0);
  if (!record || room.next || reset) {
    if (record && !record.reviewed) { record.status = 'review'; interruptTiming([record]); }
    if (state.records.length >= 5000) throw new Error('Local history is full. Export a backup before starting a fresh extension installation.');
    record = {id: uuid(), seats: [uuid(), uuid()], date: now, seenAt: now, room: s.room,
      names: s.names, legends: s.legends, deck: '', scores: s.scores, first: s.first,
      seconds: 0, outcome: 'unknown', status: 'capturing', reviewed: false, partial: s.turn !== 1,
      lastTurn: s.turn, sourceIDs: []};
    record.sourceIDs = [record.id]; state.records.unshift(record); room.id = record.id; room.next = false;
  }
  if (!record.reviewed && !record.deleted) {
    record.names = s.names;
    record.legends = s.legends.map((n, i) => n || record.legends[i]);
    record.scores = s.scores; record.lastTurn = s.turn ?? record.lastTurn;
    record.first = record.first ?? s.first;
    observeTiming(record, s, now, context);
    observePriorityTiming(record, s, now);
    record.outcome = s.outcome; // A rewind can retract a provisional win.
    record.status = s.outcome === 'unknown' ? 'capturing' : 'review';
    record.seenAt = now;
  }
  return state;
}
export function review(record, values) {
  if (record.games) throw new Error('Ungroup the series to edit its games.');
  if (!Array.isArray(values.names) || values.names.length !== 2 || values.names.some(n => !text(n, 60) || !n.trim()) ||
      !Array.isArray(values.legends) || values.legends.length !== 2 || values.legends.some(n => !text(n, 160) || !n.trim()) ||
      !text(values.deck, 160) || !Array.isArray(values.scores) || values.scores.length !== 2 || values.scores.some(n => n === null || !score(n)) ||
      !['win', 'loss', 'draw'].includes(values.outcome) || ![null, 0, 1].includes(values.first)) throw new Error('Enter both names, legends, scores and a result.');
  const date = Number(values.date);
  if (!Number.isFinite(date) || date < Date.UTC(2020, 0, 1) || date > Date.now() + 86400000) throw new Error('Choose a valid played date.');
  const timing = portableTiming(record);
  if (values.opponentExperience !== undefined && !Object.hasOwn(experienceLevels, values.opponentExperience)) throw new Error('Choose a valid opponent experience.');
  const previous = {...record};
  Object.assign(record, values, {names: values.names.map(n => n.trim()), legends: values.legends.map(n => n.trim()), date, reviewed: true, status: 'ready'});
  rememberExperienceReview(record, previous);
  if (timing) record.timing = timing;
  return record;
}
export function group(state, ids) {
  const selected = state.records.filter(r => ids.includes(r.id)).sort((a,b) => a.date-b.date);
  if (selected.length < 2 || selected.length > 30 || selected.length !== new Set(ids).size || selected.some(r => !r.reviewed || r.groupedBy || r.deleted || r.games)) throw new Error('Select two or three reviewed games for a completed best of three.');
  const first = selected[0], wins = [0,0];
  for (const r of selected) {
    if (JSON.stringify(r.names) !== JSON.stringify(first.names) || JSON.stringify(r.legends) !== JSON.stringify(first.legends) || wins.includes(2)) throw new Error('A series must have the same players and legends, in game order, ending at two wins.');
    if (r.outcome === 'win') wins[0]++; else if (r.outcome === 'loss') wins[1]++;
  }
  if (!wins.includes(2)) throw new Error('Finish the series before grouping. Someone must win two games.');
  const grouped = {...first, id: uuid(), sourceIDs: selected.flatMap(r => r.sourceIDs), games: selected.map(game),
    outcome: wins[0] === 2 ? 'win' : 'loss', scores: wins, children: selected.map(r=>r.id)};
  // Conflicting game assessments need a fresh choice for the series.
  grouped.opponentExperience = selected.every(r => r.opponentExperience === first.opponentExperience) ? first.opponentExperience : 'unrated';
  delete grouped.opponentExperienceUpdatedAt; // Grouping is not a new assessment.
  delete grouped.priorityTiming; // Priority clocks belong to the individual games.
  selected.forEach(r => { r.groupedBy = grouped.id; }); state.records.unshift(grouped); return grouped;
}
function game(r) { return {scores: r.scores, winner: r.outcome === 'win' ? 0 : r.outcome === 'loss' ? 1 : null, draw: r.outcome === 'draw', first: r.first, seconds: r.seconds, timing: portableTiming(r), priorityTiming:portablePriorityTiming(r)}; }
export function transfer(r) {
  if (!r.reviewed || r.deleted || r.groupedBy) throw new Error('Review this result before sharing.');
  return {version: 1, id: r.id, date: r.date / 1000 - 978307200, format: 'duel', bestOfThree: !!r.games,
    sender: r.seats[0], players: r.names.map((name,i) => ({id: r.seats[i], name, legend: r.legends[i], deck: i === 0 ? r.deck : ''})),
    games: r.games || [game(r)], origin: {platform: 'riftatlas', gameIDs: r.sourceIDs}, opponentExperience:r.opponentExperience};
}
export function resultURL(record) {
  const bytes = new TextEncoder().encode(JSON.stringify((() => { const value = transfer(record); value.games = value.games.map(({timing, priorityTiming, ...game}) => game); return value; })()));
  return 'riftledger://result?data=' + btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
}
export function exportRecords(records) {
  const eligible = records.filter(r => r.reviewed && !r.deleted && !r.groupedBy);
  if (!eligible.length) throw new Error('Review at least one result to export.');
  if (eligible.length > 1000) throw new Error('Export up to 1,000 matches at a time. Select a smaller set.');
  return {schema: 'rift-ledger-results', version: 1, results: eligible.map(transfer)};
}
