import {sessionDay, validSessionDay, shiftSessionDay, sessionRecap, sessionTags, sessionNoteLimit} from './session-recap.js';
import {duration} from './turn-timing.js';

export function createRecap({root, send, openReview, showError, isVisible}) {
  const document = root.ownerDocument;
  const $ = selector => root.querySelector(selector);
  const node = (tag, text, className) => { const e=document.createElement(tag); if(text!=null)e.textContent=text; if(className)e.className=className; return e; };
  const drafts = new Map();
  let day = sessionDay(), generation = 0, recap, visibleLimit = 10;
  const recordText = r => `${r.wins}W · ${r.losses}L · ${r.draws}D`;
  const note = () => drafts.get(day);
  function renderNote() {
    const draft = note();
    $('#session-note').disabled = !draft;
    $('#session-note').value = draft?.text || '';
    $('#session-note-count').textContent = `${draft?.text.length || 0} / ${sessionNoteLimit}`;
    $('#session-note-status').textContent = !draft ? 'Loading notes…' : draft.error ? `Not saved: ${draft.error}` : draft.dirty ? 'Saving…' : 'Saved only in this browser';
    $('#session-note-status').dataset.error = String(!!draft?.error);
    $('#session-note-summary').textContent=!draft?'Loading…':draft.error?'Not saved':draft.dirty?'Saving…':draft.text||draft.tags.length?'Saved':'Add a note';
    $('#retry-session-note').hidden = !draft?.error;
    $('#session-tags').replaceChildren();
    for (const tag of sessionTags) {
      const button = node('button',tag); button.type='button'; button.disabled=!draft;
      button.setAttribute('aria-pressed',String(!!draft?.tags.includes(tag)));
      button.onclick = () => {
        draft.tags = draft.tags.includes(tag) ? draft.tags.filter(t=>t!==tag) : [...draft.tags,tag];
        saveNote(); renderNote();
      };
      $('#session-tags').append(button);
    }
  }
  async function saveNote() {
    const draft = note(), savedDay = day;
    if (!draft) return;
    const revision = ++draft.revision;
    draft.dirty=true; draft.error=null;
    const value = {text:draft.text, tags:[...draft.tags]};
    $('#session-note-count').textContent = `${draft.text.length} / ${sessionNoteLimit}`;
    $('#session-note-status').textContent = 'Saving…';
    $('#session-note-summary').textContent='Saving…';
    $('#session-note-status').dataset.error = 'false'; $('#retry-session-note').hidden=true;
    try {
      // Send immediately: closing the popup must not discard a pending debounce.
      await send({type:'session-note-save', day:savedDay, note:value});
      if (draft.revision !== revision) return;
      draft.dirty=false;
    } catch (error) {
      if (draft.revision !== revision) return;
      draft.error=error.message;
    }
    if (day === savedDay && isVisible()) {
      $('#session-note-status').textContent = draft.error ? `Not saved: ${draft.error}` : 'Saved only in this browser';
      $('#session-note-status').dataset.error = String(!!draft.error);
      $('#session-note-summary').textContent=draft.error?'Not saved':draft.text||draft.tags.length?'Saved':'Add a note';
      $('#retry-session-note').hidden = !draft.error;
    }
  }
  $('#session-note').oninput = () => { if(note()){note().text=$('#session-note').value;saveNote();} };
  $('#retry-session-note').onclick = saveNote;
  function renderResults() {
    $('#session-results').replaceChildren();
    for (const r of recap.matches.slice(0,visibleLimit)) {
      const button = node('button','','session-result'); button.dataset.id=r.id;
      const result = {win:'Victory',loss:'Defeat',draw:'Draw'}[r.outcome];
      button.dataset.outcome=r.outcome;
      const heading = node('span','','result-heading');
      heading.append(node('strong',result),node('b',r.scores.map(v=>v??'?').join(' – ')));
      button.append(heading,node('span',`vs ${r.names[1]}${r.games?' · Bo3':''}`),
        node('small',`${r.legends.join(' vs ')} · ${new Date(r.date).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}`));
      button.onclick=()=>openReview(r.id); $('#session-results').append(button);
    }
    $('#more-session-results').hidden=recap.matches.length<=visibleLimit;
  }
  $('#more-session-results').onclick=()=>{visibleLimit+=10;renderResults();};
  function render(data) {
    recap=data;
    $('#session-record').textContent=recordText(data);
    $('#session-win-rate').textContent=data.winRate==null?'—':`${data.winRate}%`;
    $('#session-match-count').textContent=String(data.count);
    $('#session-time').textContent=data.timedGames?duration(Math.round(data.seconds)):'—';
    $('#session-context').textContent=data.hasSeries
      ? `${data.games} games · Each Bo3 counts as one match. Series use the first game's date.`
      : 'Confirmed results only. Draws count toward win rate.';
    $('#session-pending').hidden=!data.pending;
    $('#session-pending').textContent=`${data.pending} ${data.pending===1?'game needs':'games need'} review. Not counted yet.`;
    const timeDetail = data.timedGames ? `${data.timedGames} of ${data.games} games timed${data.partialGames?` · ${data.partialGames} partial`:''}.` : 'No captured time for these results.';
    $('#session-time-note').textContent=`${timeDetail} Excludes time between games.`;
    $('#session-empty').hidden=data.count>0;
    $('#session-breakdown').hidden=data.count===0;
    $('#session-matchups').replaceChildren();
    for (const matchup of data.matchups) {
      const row=node('div','','session-matchup');
      const legends=node('div'); legends.append(node('strong',matchup.legends[0]),node('span',`vs ${matchup.legends[1]}`));
      const stats=node('div'); stats.append(node('b',`${matchup.winRate}%`),node('span',recordText(matchup)));
      row.append(legends,stats);$('#session-matchups').append(row);
    }
    renderResults();
  }
  async function open(nextDay=day) {
    if (!validSessionDay(nextDay) || nextDay > sessionDay()) { showError(Error('Choose today or an earlier date.')); return; }
    day=nextDay; const request=++generation, startingRevision=note()?.revision;
    visibleLimit=10;
    $('#session-date').value=day;$('#session-date').max=sessionDay();
    $('#session-next').disabled=day>=sessionDay();$('#session-today').hidden=day===sessionDay();
    $('#session-heading').textContent=day===sessionDay()?'Today’s session':day===shiftSessionDay(sessionDay(),-1)?'Yesterday’s session':'Session recap';
    $('#recap-content').hidden=true;$('#session-loading').hidden=false;$('#session-loading').textContent='Loading your session…';
    renderNote(); showError(null);
    try {
      const [state, saved] = await Promise.all([send({type:'read'}),send({type:'session-note-read',day})]);
      if (request!==generation || !isVisible()) return;
      if (!note()?.dirty && note()?.revision===startingRevision) drafts.set(day,{text:saved?.text||'',tags:saved?.tags||[],revision:0,dirty:false,error:null});
      render(sessionRecap(state.records,day)); renderNote();
      $('#recap-content').hidden=false;$('#session-loading').hidden=true;
    } catch (error) {
      if (request!==generation || !isVisible()) return;
      showError(error);$('#session-loading').textContent='Could not load this session. Try refresh.';
    }
  }
  $('#session-date').onchange=()=>open($('#session-date').value);
  $('#session-prev').onclick=()=>open(shiftSessionDay(day,-1));
  $('#session-next').onclick=()=>open(shiftSessionDay(day,1));
  $('#session-today').onclick=()=>open(sessionDay());
  return {open, cancel:()=>{generation++;}};
}
