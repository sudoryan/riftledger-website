import {prioritySummary} from './priority-timing.js';
import {duration} from './turn-timing.js';

export function renderPriorityTiming(root, record) {
  const document = root.ownerDocument;
  const node = (tag, text, cls) => {
    const e = document.createElement(tag); e.textContent = text; if (cls) e.className = cls; return e;
  };
  root.classList.add('priority-timing');
  root.replaceChildren(node('h3', 'Priority time'));
  const summary = prioritySummary(record);
  if (!summary) {
    root.append(node('p', 'Priority time was not captured for this game.', 'priority-note'));
    return;
  }
  const sides = node('div', '', 'priority-sides');
  for (const i of [0, 1]) {
    const side = node('div', '', 'priority-player'); side.dataset.player = i;
    side.append(node('span', record.names?.[i] || (i ? 'Opponent' : 'You'), 'priority-name'),
      node('strong', duration(summary.seconds[i])),
      node('span', summary.shares[i] == null ? 'No time elapsed' : `${summary.shares[i]}% of priority time`, 'priority-share'));
    sides.append(side);
  }
  root.append(sides);
  const bar = node('div', '', 'priority-split'); bar.setAttribute('aria-hidden', 'true');
  const own = node('span', ''); own.style.width = `${summary.shares[0] ?? 50}%`; bar.append(own); root.append(bar);
  root.append(node('p', 'Time with priority, including responses on the other player\'s turn.', 'priority-note'));
  const status = summary.atResult ? 'RiftAtlas clocks captured at result.'
    : !record.reviewed && record.status === 'capturing' && summary.available ? 'Latest RiftAtlas clocks.'
    : 'Last captured RiftAtlas clocks. Final totals were not captured.';
  root.append(node('p', status, 'priority-status'));
}
