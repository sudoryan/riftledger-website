import {createVideoMatchStats} from './video-match-stats.js';
import {VideoStore} from './video-store.js';
import {createVideos} from './video-view.js';
import {readVideoLocation,videoLocation} from './video-location.js';
const $=s=>document.querySelector(s);
const showError=error=>{$('#error').hidden=!error;$('#error').textContent=error?.message||'';};
const send=async message=>{
  const response=await chrome.runtime.sendMessage(message);
  if(!response?.ok)throw Error(response?.error||'The extension is unavailable. Reopen the footage page after updating.');
  return response.result;
};
let stats;
const store=new VideoStore();
const videos=createVideos({root:$('#videos-view'),send,showError,isVisible:()=>true,fullPage:true,store,
  onSelect:(record,at)=>{document.title=`${record.names?.join(' vs ')||'RiftAtlas recording'} · Rift Ledger`;history.replaceState(null,'',videoLocation(record.id,at));void stats.select(record);syncSidebar(record);},
  onBack:()=>{stats.clear();document.title='Your footage · Rift Ledger';history.replaceState(null,'',location.pathname);},
  onStatus:status=>{
    const active=status.active,banner=$('#page-job-status');banner.hidden=!active;
    banner.textContent=active?.kind==='clip'?`Preparing clip · ${Math.round((active.progress||0)*100)}%`:active?'Recording session is enabled. End it in the extension popup before creating a clip.':'';
  }});
// This extension page only reads local history. Playback never changes a result.
const aside=$('.video-aside'), moments=$('#video-marker-section');
const tabs=document.createElement('div');tabs.className='replay-tabs';
const panel=document.createElement('section');panel.id='video-match-stats';panel.setAttribute('aria-label','Match stats');
const choices=[['Match stats',panel],['Turns & highlights',moments]];
for(const [label,target] of choices){
  const button=document.createElement('button');button.type='button';button.textContent=label;
  button.setAttribute('aria-controls',target.id);button.setAttribute('aria-pressed',String(target===panel));
  button.onclick=()=>{
    for(const [,section] of choices)section.hidden=section!==target;
    for(const b of tabs.children)b.setAttribute('aria-pressed',String(b===button));
  };
  tabs.append(button);
}
aside.prepend(tabs,panel);moments.hidden=true;
function syncSidebar(record){
  const buttons=[...tabs.children];
  // Clips have no timeline; return to stats if that was the selected pane.
  buttons[1].hidden=record.kind==='clip';
  if(record.kind==='clip')buttons[0].click();
  moments.hidden=record.kind==='clip'||buttons[1].getAttribute('aria-pressed')!=='true';
}
stats=createVideoMatchStats({root:panel,loadVideo:id=>store.get(id),loadRecords:async()=>{
  const {ledger}=await chrome.storage.local.get('ledger');
  if(ledger&&ledger.version!==1)throw Error('Unsupported history version');
  return ledger?.records||[];
}});
$('#page-refresh').onclick=async()=>{try{await videos.poll();await stats.refresh();showError(null);}catch(error){showError(error);}};
const onHistoryChange=(changes,area)=>{if(area==='local'&&changes.ledger)void stats.refresh();};
chrome.storage.onChanged.addListener(onHistoryChange);
async function openLocation(){
  try{showError(null);const record=readVideoLocation(location.hash);if(record)await videos.select(record.id,{at:record.at});}
  catch(error){showError(error);}
}
// Read stored footage even if an extension update has disconnected the worker.
await videos.open().catch(showError);await openLocation();
window.addEventListener('hashchange',openLocation);
const timer=setInterval(()=>videos.poll(),2500);
window.addEventListener('pagehide',()=>{clearInterval(timer);stats.clear();chrome.storage.onChanged.removeListener(onHistoryChange);videos.close();});
