import {clipRange,videoTime} from './video-model.js';
import {createClipThumbnails} from './clip-thumbnails.js';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const tenth=n=>Math.round(n*10)/10;
export function clipTimestamp(seconds){
  const n=tenth(Math.max(0,seconds)),fraction=Math.round((n-Math.floor(n))*10);
  return videoTime(n)+(fraction?`.${fraction}`:'');
}
export function parseClipTimestamp(text){
  const value=String(text).trim();
  if(!/^\d+:\d{2}(?::\d{2})?(?:\.\d)?$/.test(value))throw Error('Use minutes:seconds, for example 8:24 or 8:24.5.');
  const parts=value.split(':').map(Number);
  if(parts.slice(1).some(n=>n>=60))throw Error('Seconds and minutes within an hour must be below 60.');
  return parts.reduce((n,p)=>n*60+p,0);
}
export function clipAround(at,length,duration){
  length=Math.min(length,duration,600);const start=tenth(clamp(at-length*2/3,0,Math.max(0,duration-length)));
  return {start,end:Math.min(duration,tenth(start+length))};
}
export function createClipEditor({root,player,onSeek,onChange}){
  root.innerHTML=`<div class="clip-heading"><div><span class="clip-kicker">MAKE A CLIP</span><h3>Keep the best part</h3></div><div class="clip-heading-actions"><strong id="clip-duration"></strong><button id="clip-exit">Done</button></div></div><div class="clip-presets"><span>Around playhead</span><button data-clip-preset="15">15s</button><button data-clip-preset="30">30s</button><button data-clip-preset="60">60s</button></div><div class="clip-timeline-tools"><span id="clip-window-label">Trim timeline</span><button id="clip-zoom">Show whole video</button></div><div id="clip-track" class="clip-track"><div id="clip-thumbnails" aria-hidden="true"></div><div class="clip-shade clip-shade-before"></div><div class="clip-shade clip-shade-after"></div><div id="clip-selection" aria-hidden="true"><span>DRAG TO MOVE</span></div><div id="clip-playhead" aria-hidden="true"></div><input id="clip-start-slider" aria-label="Clip start" type="range" min="0" max="1" step="0.1" value="0"><input id="clip-end-slider" aria-label="Clip end" type="range" min="0" max="1" step="0.1" value="1"></div><div class="clip-ruler" aria-hidden="true"><span id="clip-window-start"></span><span id="clip-window-mid"></span><span id="clip-window-end"></span></div><p class="clip-instruction">Drag the edges to trim. Click the timeline to seek.</p><div class="clip-boundaries"><div><span>START</span><strong id="clip-start-label"></strong><button id="clip-start-here">Set to playhead</button></div><div><span>END</span><strong id="clip-end-label"></strong><button id="clip-end-here">Set to playhead</button></div></div><details class="clip-precise"><summary>Enter exact times</summary><div class="video-range-fields"><label>Start time<input id="video-range-start" type="text" inputmode="decimal" placeholder="0:00" autocomplete="off"></label><label>End time<input id="video-range-end" type="text" inputmode="decimal" placeholder="0:30" autocomplete="off"></label></div></details><p id="clip-error" role="alert" hidden></p><p id="clip-busy" class="video-note" hidden></p><div class="video-buttons clip-actions"><button id="video-play-range">Preview clip</button><button id="video-make-clip">Save clip</button></div><p class="video-note">Saves a separate video. Your original stays intact. Clips can be up to 10 minutes.</p>`;
  const $=s=>root.querySelector(s),thumbs=createClipThumbnails($('#clip-thumbnails'));
  let duration=0,start=0,end=0,src=null,windowStart=0,windowEnd=0,zoomed=true,preset=30,invalid=false,drag=null,frameKey='';
  function frames(){const key=JSON.stringify([src,windowStart,windowEnd]);if(key!==frameKey){frameKey=key;void thumbs.load(src,windowStart,windowEnd);}}
  function windowForSelection(){
    const width=zoomed?Math.min(duration,Math.max(30,(end-start)*2)):duration;
    windowStart=tenth(clamp((start+end-width)/2,0,duration-width));windowEnd=Math.min(duration,tenth(windowStart+width));frames();
  }
  function error(message){invalid=!!message;$('#clip-error').textContent=message||'';$('#clip-error').hidden=!message;}
  function paint(){
    const width=windowEnd-windowStart||1,left=clamp((start-windowStart)/width*100,0,100),right=clamp((end-windowStart)/width*100,0,100);
    root.style.setProperty('--clip-start',left+'%');root.style.setProperty('--clip-end',right+'%');
    $('#clip-start-label').textContent=clipTimestamp(start);$('#clip-end-label').textContent=clipTimestamp(end);
    $('#clip-duration').textContent=`${clipTimestamp(Math.max(0,end-start))} clip`;
    for(const [id,value] of [['start',start],['end',end]]){
      const slider=$(`#clip-${id}-slider`);slider.min=String(windowStart);slider.max=String(windowEnd);slider.value=String(value);slider.disabled=duration<=0;
      slider.setAttribute('aria-valuetext',clipTimestamp(value));
      $(`#video-range-${id}`).value=clipTimestamp(value);
    }
    $('#clip-window-start').textContent=clipTimestamp(windowStart);$('#clip-window-mid').textContent=clipTimestamp((windowStart+windowEnd)/2);$('#clip-window-end').textContent=clipTimestamp(windowEnd);
    $('#clip-window-label').textContent=zoomed&&windowEnd-windowStart<duration?'Zoomed to selection':'Whole video';
    $('#clip-zoom').textContent=zoomed?'Show whole video':'Zoom to selection';$('#clip-zoom').disabled=duration<=30;
    for(const b of root.querySelectorAll('[data-clip-preset]'))b.setAttribute('aria-pressed',String(Math.abs(end-start-Number(b.dataset.clipPreset))<.05));
    updatePlayhead(player.currentTime||0);
  }
  function changed(seek){error(null);onChange();paint();if(seek!=null)onSeek(seek);}
  function setRange(range,{seek=false}={}){
    if(!duration)return;
    const gap=Math.min(.1,duration);start=clamp(Number(range.start)||0,0,duration-gap);end=clamp(Number(range.end)||start+gap,start+gap,Math.min(duration,start+600));
    windowForSelection();changed(seek?start:null);
  }
  function around(length=preset){preset=length;setRange(clipAround(player.currentTime||0,length,duration),{seek:true});}
  function moveEdge(edge,value,seek=true){
    if(!duration)return;
    if(edge==='start')start=clamp(tenth(value),Math.max(0,end-600),end-Math.min(.1,duration));
    else end=clamp(tenth(value),start+Math.min(.1,duration),Math.min(duration,start+600));
    changed(seek?(edge==='start'?start:end):null);
  }
  function updatePlayhead(time){
    const visible=time>=windowStart&&time<=windowEnd;
    $('#clip-playhead').hidden=!visible||!duration;
    root.style.setProperty('--clip-playhead',clamp((time-windowStart)/(windowEnd-windowStart||1)*100,0,100)+'%');
  }
  for(const edge of ['start','end'])$(`#clip-${edge}-slider`).oninput=event=>moveEdge(edge,Number(event.target.value));
  $('#clip-start-here').onclick=()=>{
    const at=clamp(player.currentTime||0,0,Math.max(0,duration-.1));
    setRange({start:at,end:end>at&&end-at<=600?end:Math.min(duration,at+preset)});
  };
  $('#clip-end-here').onclick=()=>{
    const at=clamp(player.currentTime||0,Math.min(.1,duration),duration);
    setRange({start:start<at&&at-start<=600?start:Math.max(0,at-preset),end:at});
  };
  for(const b of root.querySelectorAll('[data-clip-preset]'))b.onclick=()=>around(Number(b.dataset.clipPreset));
  $('#clip-zoom').onclick=()=>{zoomed=!zoomed;windowForSelection();paint();};
  for(const edge of ['start','end'])$(`#video-range-${edge}`).onchange=()=>{
    try{
      const a=parseClipTimestamp($('#video-range-start').value),b=parseClipTimestamp($('#video-range-end').value);
      if(b>duration)throw Error('The end must be within the video.');
      const range=clipRange(a,b,duration);setRange(range,{seek:true});
    }catch(e){error(e.message);}
  };
  const track=$('#clip-track');
  track.onpointerdown=event=>{
    if(event.target.tagName==='INPUT'||event.button!==0||!duration)return;
    const rect=track.getBoundingClientRect(),at=windowStart+clamp((event.clientX-rect.left)/rect.width,0,1)*(windowEnd-windowStart);
    drag={pointerId:event.pointerId,x:event.clientX,at,start,end,width:rect.width,moved:false};track.setPointerCapture(event.pointerId);event.preventDefault();
  };
  track.onpointermove=event=>{
    if(!drag||event.pointerId!==drag.pointerId)return;
    const delta=(event.clientX-drag.x)/drag.width*(windowEnd-windowStart);
    if(Math.abs(event.clientX-drag.x)>3)drag.moved=true;
    if(drag.moved&&drag.at>=drag.start&&drag.at<=drag.end){
      const length=drag.end-drag.start;start=clamp(tenth(drag.start+delta),windowStart,windowEnd-length);end=start+length;changed(start);
    }
  };
  track.onpointerup=event=>{if(!drag||event.pointerId!==drag.pointerId)return;if(!drag.moved)onSeek(clamp(drag.at,0,duration));drag=null;track.releasePointerCapture(event.pointerId);};
  track.onpointercancel=()=>{drag=null;};
  return {
    setSource({duration:seconds,src:url,at=0}){this.clear();root.hidden=!url;duration=Number.isFinite(seconds)?Math.max(0,Math.floor(seconds*10)/10||seconds):0;src=url;zoomed=true;preset=30;setRange(clipAround(at,30,duration));},
    setRange,around,updatePlayhead,
    setBusy(active){$('#clip-busy').hidden=!active;$('#clip-busy').textContent=active?.kind==='clip'?'Another clip is saving. You can keep trimming while it finishes.':'End the recording session in the extension before saving a clip. You can keep trimming.';},
    range(){if(invalid)throw Error($('#clip-error').textContent);return clipRange(start,end,duration);},
    clear(){thumbs.clear();duration=0;src=null;start=end=windowStart=windowEnd=0;drag=null;frameKey='';error(null);paint();}
  };
}
