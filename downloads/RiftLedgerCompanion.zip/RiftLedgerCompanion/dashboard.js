import {experienceLevels, experienceStats} from './core.js';
import {renderTiming} from './timing-view.js';
import {legendNames} from './legends.js';
import {fillReviewForm, reviewValues} from './review-form.js';
const $ = s => document.querySelector(s);
const selected = new Set(); let state, filter = 'review', editing, sharing;
// The demo transport exists only in the development harness, never in the packaged extension.
const send = async message => {
  const response = await (globalThis.ledgerDemo ? globalThis.ledgerDemo(message) : chrome.runtime.sendMessage(message));
  if (!response.ok) throw new Error(response.error);
  return response.result;
};
const node = (tag, text, cls) => { const e = document.createElement(tag); if(text != null)e.textContent = text; if(cls)e.className = cls; return e; };
const note = value => { $('#notice').textContent = value; };
const dateLabel = r => new Date(r.date).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
const resultName = r => ({win:'VICTORY',loss:'DEFEAT',draw:'DRAW',unknown:'UNFINISHED'})[r.outcome];
function visible() {
  const query = $('#search').value.toLowerCase();
  return state.records.filter(r => !r.groupedBy && (filter === 'trash' ? r.deleted && !r.games : !r.deleted) &&
    ($('#experience-filter').value === 'all' || (r.opponentExperience || 'unrated') === $('#experience-filter').value) &&
    (filter !== 'review' || !r.reviewed) && (filter !== 'ready' || r.reviewed) &&
    [r.names.join(' '),r.legends.join(' '),r.deck].join(' ').toLowerCase().includes(query));
}
function action(text, fn, cls) { const b=node('button',text,cls); b.type='button';b.onclick=async()=>{try{await fn();}catch(e){note(e.message);}};return b; }
function render() {
  const active=state.records.filter(r=>!r.deleted&&!r.groupedBy), ready=active.filter(r=>r.reviewed);
  $('#ready-count').textContent=ready.length; $('#review-count').textContent=active.length-ready.length;
  $('#record').textContent=`${ready.filter(r=>r.outcome==='win').length}W · ${ready.filter(r=>r.outcome==='loss').length}L · ${ready.filter(r=>r.outcome==='draw').length}D`;
  const query=$('#search').value.toLowerCase();
  $('#experience-stats').replaceChildren();
  for(const row of experienceStats(active.filter(r=>[...r.names,...r.legends,r.deck].join(' ').toLowerCase().includes(query)))) {
    const line=node('div',null,'experience-stat');
    line.append(node('strong',row.label),node('span',`${row.wins}W · ${row.losses}L · ${row.draws}D`),node('span',`${row.played} played`),node('strong',row.winRate===null?'—':`${row.winRate}%`));
    $('#experience-stats').append(line);
  }
  const rows=visible(); $('#matches').replaceChildren(); $('#empty').hidden=rows.length>0;
  if(!rows.length){ $('#empty h2').textContent=active.length?'No games in this view.':'Your next game starts here.'; }
  for(const r of rows) {
    const card=node('article',null,'match'); const check=node('input');check.type='checkbox';check.checked=selected.has(r.id);check.setAttribute('aria-label',`Select ${r.names[0]} versus ${r.names[1]} ${dateLabel(r)}`);
    check.onchange=()=>{check.checked?selected.add(r.id):selected.delete(r.id);updateSelection();};card.append(check);
    const result=node('div',null,'result-block');result.append(node('div',resultName(r),`outcome ${r.outcome}`),node('div',r.reviewed?'Ready to send':'Needs review','metadata'));card.append(result);
    const details=node('div');const title=node('div',null,'legend-line');title.append(node('strong',r.legends[0]||'Your legend'),node('span','vs'),node('strong',r.legends[1]||'Opponent legend'));
    details.append(title,node('div',`${r.names[0]} · ${r.names[1]}`,'players'),node('div',`${dateLabel(r)} · ${r.games?'Best of three':'Single game'}${r.deck?' · '+r.deck:''}`,'metadata'));card.append(details);
    card.append(node('div',r.scores.map(n=>n??'?').join(' – '),'score'));
    if (!r.deleted) {
      const label=node('label', 'Opponent experience', 'experience-choice'), select=node('select');
      select.setAttribute('aria-label', `Experience of ${r.names[1]}`);
      for (const [value,title] of Object.entries(experienceLevels)) {const option=node('option',title);option.value=value;select.append(option);}
      select.value=r.opponentExperience || 'unrated';
      select.onchange=async()=>{select.disabled=true;try{await send({type:'experience',id:r.id,value:select.value});await load();note('Opponent experience saved for this match.');}catch(error){select.value=r.opponentExperience||'unrated';note(error.message);select.disabled=false;}};
      label.append(select);details.append(label);
    }
    const buttons=node('div',null,'row-actions');
    if(r.deleted)buttons.append(action('Restore',async()=>{await send({type:'restore',id:r.id});await load();}));
    else {
      if(r.timing || r.games?.some(g=>g.timing))buttons.append(action('Timing',()=>showTiming(r)));
      if(r.reviewed)buttons.append(action('Send to phone',()=>share(r),'primary'));
      if(!r.games)buttons.append(action(r.reviewed?'Edit':'Review',()=>edit(r),r.reviewed?'':'primary'));
      buttons.append(action(r.games?'Ungroup':'Remove',async()=>{await send({type:'delete',id:r.id});selected.delete(r.id);await load();note(r.games?'Series ungrouped. Its individual games are available again.':'Moved to Removed. You can restore it there.');},'remove'));
    }
    card.append(buttons);$('#matches').append(card);
  }
  updateSelection();
}
function updateSelection(){
  $('#selection').textContent=selected.size?`${selected.size} selected`:'';
  $('#group').disabled=selected.size<2 || filter==='trash';
  $('#export').textContent=selected.size?'Export selected':'Export ready games';
  $('#select-all').checked=visible().length>0&&visible().every(r=>selected.has(r.id));
}
async function load(){state=await send({type:'read'});render();}
function edit(r) {
  editing=r.id; const form=$('#review-form');form.reset();
  fillReviewForm(form,r,undefined,state.records);
  $('#capture-note').textContent=r.partial?'Capture began after the game started. Check the date and result; duration covers only the observed portion.':'Check the final result, especially after a concession or a score correction. Unknown initiative stays out of first-player statistics.';
  $('.form-error').textContent='';$('#editor').showModal();
}
$('#review-form').onsubmit=async e=>{
  e.preventDefault();
  try { await send({type:'review',id:editing,values:reviewValues(e.currentTarget)});
    $('#editor').close();await load();note('Result confirmed. Ready to send to your phone.');
  } catch(error){$('.form-error').textContent=error.message;}
};
function showTiming(r) {
  const container = $('#timing-games'); container.replaceChildren();
  $('#timing-title').textContent = `${r.names[0]} vs ${r.names[1]}`;
  for (const [i, game] of (r.games || [r]).entries()) {
    if (r.games) container.append(node('h3', `Game ${i + 1}`));
    const panel = node('section', null, 'timing-panel');
    renderTiming(panel, {...game, names:r.names}, {timeline:true}); container.append(panel);
  }
  $('#timing-dialog').showModal();
}
async function share(r){
  const url=await send({type:'url',id:r.id});sharing={id:r.id,url};$('#copy-link').textContent='Copy result link';
  $('#share-summary').textContent=`${resultName(r)} · ${r.scores.join(' – ')} · ${r.legends[0]} vs ${r.legends[1]}`;
  $('#qr').hidden=url.length>2900;
  $('#qr-help').textContent=url.length>2900?'This result is too large for a QR. Copy the link or export the match.':'On your iPhone, open History → Scan result. Check your seat and save.';
  if(url.length<=2900){const qr=globalThis.qrcode(0,'L');qr.addData(url,'Byte');qr.make();$('#qr').src=qr.createDataURL(5,20);}
  $('#share').showModal();
}
async function download(ids){
  const data=await send({type:'export',ids});const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
  const a=node('a');a.href=url;a.download=`rift-ledger-games-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  note(`Exported ${data.results.length} reviewed match${data.results.length===1?'':'es'}. Unreviewed games were not included.`);
}
$('#copy-link').onclick=async()=>{try{await navigator.clipboard.writeText(sharing.url);$('#copy-link').textContent='Copied';}catch{note('Clipboard unavailable. Export the match instead.');}};
$('#export-one').onclick=()=>download([sharing.id]).catch(e=>note(e.message));
$('#export').onclick=()=>download([...selected]).catch(e=>note(e.message));
$('#group').onclick=async()=>{try{await send({type:'group',ids:[...selected]});selected.clear();await load();note('Saved as one best-of-three match. Individual games are included.');}catch(e){note(e.message);}};
$('#experience-filter').onchange=()=>{selected.clear();render();};
$('#search').oninput=()=>{selected.clear();render();};
$('#select-all').onchange=e=>{visible().forEach(r=>e.target.checked?selected.add(r.id):selected.delete(r.id));render();};
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;selected.clear();document.querySelectorAll('[data-filter]').forEach(e=>e.setAttribute('aria-pressed',e===b?'true':'false'));render();});
document.querySelectorAll('dialog .close').forEach(b=>b.onclick=()=>b.closest('dialog').close());
for(const name of legendNames){const option=node('option');option.value=name;$('#legends').append(option);}
if(!globalThis.ledgerDemo)chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.ledger)load().catch(e=>note(e.message));});
load().then(() => {
  const params = new URLSearchParams(location.hash.slice(1));
  const id = params.get('review') || params.get('share');
  const record = state.records.find(r => r.id === id && !r.deleted && !r.groupedBy);
  if (record) { if (params.has('share') && record.reviewed) return share(record); else if (!record.games) edit(record); }
}).catch(e=>note(`Could not read local history: ${e.message}`));
