import {legendArt} from './legend-art.js';
import {videoLocation} from './video-location.js';
import {videoTime} from './video-model.js';
const resultNames={win:'Victory',loss:'Defeat',draw:'Draw'};
const experienceNames={newby:'Newby',newish:'Newish',experienced:'Experienced',pro:'Pro'};
export function historyMatches(records,{query='',filter='all'}={}){
 const term=query.trim().toLowerCase();
 return records.filter(r=>!r.groupedBy&&(filter==='removed'?r.deleted&&!r.games:!r.deleted)&&
  (['all','removed'].includes(filter)||(filter==='ready'?r.reviewed:!r.reviewed))&&
  [...r.names,...r.legends,r.deck||''].join(' ').toLowerCase().includes(term)).sort((a,b)=>b.date-a.date);
}
export function historySummary(records){
 const confirmed=records.filter(r=>!r.deleted&&!r.groupedBy&&r.reviewed),wins=confirmed.filter(r=>r.outcome==='win').length;
 const losses=confirmed.filter(r=>r.outcome==='loss').length,draws=confirmed.filter(r=>r.outcome==='draw').length;
 const pending=records.filter(r=>!r.deleted&&!r.groupedBy&&!r.reviewed).length;
 return `${confirmed.length} confirmed · ${wins}W / ${losses}L${draws?` / ${draws}D`:''}${confirmed.length?` · ${Math.round(wins/confirmed.length*100)}% win rate`:''}${pending?` · ${pending} to review`:''}`;
}
export function matchHistoryRow({document,record:r,recordings=[],onReview,onRemove,onRestore}){
 const node=(tag,text,cls)=>{const e=document.createElement(tag);if(text!=null)e.textContent=text;if(cls)e.className=cls;return e;};
 const row=node('article',null,'match-entry');row.dataset.matchId=r.id;row.dataset.outcome=r.deleted?'removed':r.outcome;
 const open=node('button',null,'saved-game');open.type='button';open.dataset.id=r.id;open.disabled=!!r.deleted;
 open.setAttribute('aria-label',`${r.deleted?'Removed match':r.reviewed?'Review game':'Finalize match'}: ${r.names.join(' vs ')}, ${resultNames[r.outcome]||'Unconfirmed'}, ${r.scores.map(n=>n??'?').join(' to ')}`);
 open.onclick=()=>!r.deleted&&onReview(r.id);
 const result=node('div',null,'history-result');result.append(node('strong',resultNames[r.outcome]||'Unconfirmed'),node('small',r.games?'BEST OF THREE':'RIFTATLAS DUEL'),node('span',r.deleted?'Removed':r.reviewed?'Confirmed':'Needs review','history-state'));
 const player=i=>{
  const seat=node('div',null,'history-player'),portrait=node('span',null,'legend-portrait'),copy=node('div',null,'history-player-copy');
  const art=legendArt(r.legends[i]);portrait.setAttribute('aria-hidden','true');
  portrait.textContent=(r.legends[i]||'?').slice(0,1).toUpperCase();
  if(art){const img=node('img');img.src=art;img.alt='';img.loading='lazy';img.onerror=()=>img.remove();portrait.append(img);}
  copy.append(node('small',i===0?'YOU':'OPPONENT'),node('strong',r.names[i]),node('span',r.legends[i]||'Unknown legend'));
  seat.append(portrait,copy);return seat;
 };
 const score=node('div',null,'history-score');score.append(node('strong',r.scores.map(n=>n??'—').join(' : ')),node('small',r.games?'GAMES':'POINTS'));
 const facts=node('div',null,'history-facts');
 const seconds=r.games?r.games.reduce((sum,g)=>sum+(g.seconds||0),0):r.seconds;
 if(seconds>0){const s=Math.floor(seconds);facts.append(node('strong',`${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}${r.partial?' · partial':''}`));}
 facts.append(node('span',new Date(r.date).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})));
 if(experienceNames[r.opponentExperience])facts.append(node('span',`${experienceNames[r.opponentExperience]} opponent`,'history-experience'));
 open.append(result,player(0),score,player(1),facts);
 const actions=node('div',null,'history-actions');
 const review=node('button',r.reviewed?'Review':'Finalize','history-review');review.type='button';
 review.setAttribute('aria-label',`${r.reviewed?'Review':'Finalize'} match: ${r.names.join(' vs ')}`);
 review.onclick=()=>onReview(r.id);review.hidden=!!r.deleted;
 const action=node('button',r.deleted?'Restore':'','history-remove');action.type='button';
 if(!r.deleted)action.innerHTML='<svg width="14" height="16" viewBox="0 0 16 18" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M2 5h12M6 2h4l1 3H5l1-3ZM3 5l1 11h8l1-11M6 8v5M10 8v5"/></svg>';
 action.setAttribute('aria-label',`${r.deleted?'Restore':'Remove'} match: ${r.names.join(' vs ')}`);action.title=r.deleted?'Restore match':'Remove match';
 action.onclick=()=>r.deleted?onRestore(r.id,action):onRemove(r,action);
 const videos=node('div',null,'history-videos');videos.hidden=true;
 videos.setAttribute('aria-label',`Match videos: ${r.names.join(' vs ')}`);
 actions.append(videos,review,action);row.append(open,actions);
 updateHistoryVideoLinks(row,r.deleted?[]:recordings);return row;
}

const replayIcon='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m9 5 11 7-11 7V5Z" fill="currentColor"/></svg>';
export function updateHistoryVideoLinks(row,recordings){
 const root=row.querySelector('.history-videos'),stamp=JSON.stringify(recordings);
 if(root.dataset.recordings===stamp)return;
 root.dataset.recordings=stamp;root.replaceChildren();
 const links=[];
 for(const video of recordings){
  // Native links work even before Chrome restarts an updated service worker.
  let href;try{href='video-page.html'+videoLocation(video.id);}catch{continue;}
  const link=row.ownerDocument.createElement('a');link.className='history-video-link';
  link.href=href;link.target='_blank';link.rel='noopener';
  const part=[video.game?`Game ${video.game}`:'',video.part?`Part ${video.part}`:''].filter(Boolean).join(' · ');
  const detail=`${videoTime(video.duration)}${video.partial?' · Partial':''}`;
  link.setAttribute('aria-label',`Replay${part?` · ${part}`:''} · ${detail}`);
  link.title=link.getAttribute('aria-label');link.textContent=part||'Replay';
  const meta=row.ownerDocument.createElement('span');meta.textContent=detail;link.append(meta);
  links.push(link);
 }
 if(links.length===1){
  const link=links[0];link.classList.add('history-replay-control');link.innerHTML=replayIcon;root.append(link);
 }else if(links.length>1){
  const picker=row.ownerDocument.createElement('details');picker.className='history-replay-picker';picker.setAttribute('name','match-replays');
  const toggle=row.ownerDocument.createElement('summary');toggle.className='history-replay-control';toggle.innerHTML=replayIcon;
  toggle.title='Replay';toggle.setAttribute('aria-label',`Replay · ${links.length} recordings`);
  const menu=row.ownerDocument.createElement('div');menu.className='history-replay-menu';menu.setAttribute('aria-label','Match recordings');
  for(const link of links){link.onclick=()=>picker.removeAttribute('open');menu.append(link);}
  picker.onkeydown=event=>{if(event.key==='Escape'){picker.removeAttribute('open');toggle.focus();event.preventDefault();}};
  picker.append(toggle,menu);root.append(picker);
 }
 root.hidden=!links.length;
}
