import {VideoStore} from './video-store.js';
import {RecorderEngine} from './recorder-engine.js';
import {VideoSession} from './video-session.js';
import {captureConstraints,videoQuality,videoFrameRate} from './video-model.js';
import {prepareRecordingAudio} from './recording-audio.js';
import {startClip} from './video-clips.js';
const store=new VideoStore();
const ready=store.recover();
let recordingAudio, queue=Promise.resolve();
const engine=new RecorderEngine({store});
const session=new VideoSession({engine,store,onChange:status=>{
  if(!status){recordingAudio?.cleanup();recordingAudio=null;}
  chrome.runtime.sendMessage({type:'video-event',status}).catch(()=>{});
}});
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(m?.target!=='video-offscreen'||sender.id!==chrome.runtime.id||sender.tab||sender.url&&sender.url!==chrome.runtime.getURL('background.js'))return;
  queue=queue.then(async()=>{
    await ready;
    switch(m.action){
      case 'status':return {active:session.status(),notice:session.notice};
      case 'start':{
        if(session.status())throw Error('A recording is already running.');
        let stream;
        try {
          const mandatory={chromeMediaSource:'tab',chromeMediaSourceId:m.streamID};
          stream=await navigator.mediaDevices.getUserMedia({audio:m.audio?{mandatory}:false,video:{mandatory:{...mandatory,...captureConstraints(m.quality,m.requestedFrameRate)}}});
          recordingAudio=await prepareRecordingAudio(stream,{microphone:m.microphone,onMicrophoneEnded:reason=>{void session.end(reason);}});
          const options={cap:m.cap,tabId:m.tabId,documentToken:m.documentToken,audio:!!m.audio,microphone:recordingAudio.microphone,quality:videoQuality(m.quality).id,requestedFrameRate:videoFrameRate(m.requestedFrameRate)};
          return await (m.auto?session.enable(recordingAudio.stream,options):session.start(recordingAudio.stream,options));
        }catch(error){stream?.getTracks().forEach(t=>t.stop());recordingAudio?.cleanup();recordingAudio=null;throw error;}
      }
      case 'stop':return session.end(m.reason||'');
      case 'navigate':return session.navigate();
      case 'reconnect':return session.reconnect(m.documentToken);
      case 'highlight':return session.highlight();
      case 'observe':await session.observe(m.snapshot,m.matchID,m.tabId,m.context);return null;
      case 'clip':if(session.status())throw Error('End auto-recording or the current video before creating a clip.');return startClip({store,engine,id:m.id,start:m.start,end:m.end,cap:m.cap});
      default:throw Error('Unknown video operation.');
    }
  }).then(result=>respond({ok:true,result})).catch(error=>respond({ok:false,error:error.message}));
  return true;
});
