/* DOM adapter. Reads only public board labels/attributes, never app state or sockets. */
(() => {
  const number = value => value != null && /^\d+$/.test(String(value)) && Number(value) <= 999 ? Number(value) : null;
  const clockSeconds = value => {
    const parts = (value || '').trim().split(':');
    if (parts.length < 2 || parts.length > 3 || !parts.every(p => /^\d{1,3}$/.test(p)) ||
        !/^\d{2}$/.test(parts.at(-1)) || Number(parts.at(-1)) >= 60 ||
        parts.length === 3 && (!/^\d{2}$/.test(parts[1]) || Number(parts[1]) >= 60)) return null;
    const seconds = parts.reduce((n, p) => n * 60 + Number(p), 0);
    return seconds <= 604800 ? seconds : null;
  };
  function read(document) {
    const root = document.querySelector('[data-testid="game-state"]');
    if (!root) return null;
    const attr = key => root.getAttribute(`data-${key}`);
    const phase = attr('room-phase') || '';
    const roomNode = document.querySelector('[data-testid="room-code"]');
    const room = roomNode?.getAttribute('data-room-code') || roomNode?.textContent?.trim();
    const names = ['player', 'opponent'].map(side => {
      const badge = document.querySelector(`[data-player-identity-trigger="${side}"]`);
      const name = (badge?.querySelector('[data-identity-player-name]')?.textContent || badge?.getAttribute('aria-label')?.replace(/\s+(profile and actions|menu)$/i, '') || '').trim().slice(0, 60);
      return /^[.…\s]*$/.test(name) ? '' : name;
    });
    const mode = attr('room-mode') || '';
    const ownTrack = document.querySelector('[aria-label="Your score track"]');
    // RiftAtlas's constellation nodes are div[role=button], not native buttons.
    // Disabled controls during setup still establish that this is the owner's seat.
    const control = 'button, [role="button"][aria-pressed]';
    const hasControls = !!(ownTrack?.matches(control) || ownTrack?.querySelector(control));
    const playerID = key => { const value = attr(key); return value && value !== 'unknown' ? value : null; };
    const practice = /single_player|practice|solo|goldfish/i.test(mode);
    const spectator = /spectat/i.test(mode);
    const playable = hasControls && !!playerID('viewer-player-id') && !!playerID('opponent-player-id') &&
      playerID('viewer-player-id') !== playerID('opponent-player-id') && !practice && !spectator;
    const scores = ['viewer', 'opponent'].map((side, i) => {
      const direct = number(attr(`${side}-score`));
      if (direct !== null) return direct;
      const track = document.querySelector(`[aria-label="${i ? 'Opponent' : 'Your'} score track"]`);
      const current = track?.querySelector('[data-active="true"], [aria-pressed="true"]');
      return number(current?.getAttribute('aria-label')?.match(/(\d+)\s*$/)?.[1] ?? current?.textContent?.trim());
    });
    const legends = ['self', 'opponent'].map(side => {
      const img = document.querySelector(`[data-zone-owner="${side}"] [data-drop-zone="legend"] img[alt]`);
      const name = img?.getAttribute('alt') || '';
      return /hidden|card back/i.test(name) ? '' : name.slice(0, 160);
    });
    const turn = number(attr('turn-number'));
    const active = playerID('active-player-id');
    const activePlayer = active ? active === playerID('viewer-player-id') ? 0 : active === playerID('opponent-player-id') ? 1 : null : null;
    // Inspected on RiftAtlas's two-seat practice board, 2026-10-14. These are
    // cumulative action/priority clocks, not the turn owner or sidebar timer.
    const clocks = [...document.querySelectorAll('[data-identity-action-clock][data-layout="nameplate"]')];
    const clockIDs = ['viewer-player-id', 'opponent-player-id'].map(playerID);
    const prioritySeconds = clockIDs[0] && clockIDs[1] && clockIDs[0] !== clockIDs[1] ? clockIDs.map(id => {
      const values = clocks.filter(e => e.getAttribute('data-identity-action-clock') === id).map(e => clockSeconds(e.textContent));
      return values.length && values.every(n => n !== null && n === values[0]) ? values[0] : null;
    }) : null;
    const first = turn === 1 && active ? active === attr('viewer-player-id') ? 0 : active === attr('opponent-player-id') ? 1 : null : null;
    let outcome = 'unknown';
    // Only terminal headings. Chat, the action log and initiative-roll announcements are ignored.
    if (phase === 'in_game') {
      const headings = [...document.querySelectorAll('[data-testid="opponent-left-overlay"] h2, [role="dialog"] h2')].map(e => e.textContent.trim());
      if (headings.some(t => t === `${names[0]} won` || /^victory$/i.test(t))) outcome = 'win';
      else if (headings.some(t => t === `${names[1]} won` || /^defeat$/i.test(t))) outcome = 'loss';
      else if (headings.some(t => /^(draw|game drawn|match drawn)$/i.test(t))) outcome = 'draw';
      else if (scores[0] >= 8 && scores[1] !== null && scores[1] < 8) outcome = 'win';
      else if (scores[1] >= 8 && scores[0] !== null && scores[0] < 8) outcome = 'loss';
    }
    const reason = practice ? 'practice' : spectator ? 'spectator' : 'controls';
    return {room, phase, playable, names, legends, scores, turn, first, outcome, reason, activePlayer,
      prioritySeconds:prioritySeconds?.every(n => n !== null) ? prioritySeconds : null};
  }
  globalThis.RiftLedgerAtlas = {read};
})();
