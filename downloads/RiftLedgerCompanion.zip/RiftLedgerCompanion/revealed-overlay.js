(() => {
  globalThis.riftLedgerRevealStop?.();
  let stopped=false,enabled=false,state=null,layout={x:24,y:110,width:250,height:320,collapsed:false},last='',timer,queue=Promise.resolve(),moving=null;
  const host=document.createElement('div');host.id='rift-ledger-revealed-cards';host.hidden=true;
  host.style.cssText='position:fixed;z-index:2147483645;color-scheme:dark';
  const shadow=host.attachShadow({mode:'closed'});
  shadow.innerHTML=`<style>
  :host{all:initial}:host([hidden]),[hidden]{display:none!important}*{box-sizing:border-box}
  section{display:flex;flex-direction:column;overflow:hidden;color:#edf3ee;background:#102820f5;border:1px solid #496354;border-radius:10px;box-shadow:0 8px 28px #0006;font:12px/1.4 system-ui,sans-serif;backdrop-filter:blur(14px)}button,input{font:inherit;color:inherit}button{cursor:pointer;border:0}button:disabled{opacity:.45;cursor:wait}button:focus-visible,input:focus-visible{outline:2px solid #edca8c;outline-offset:-2px}button:hover{filter:brightness(1.2)}
  header{display:flex;align-items:center;gap:2px;padding:3px 5px;border-bottom:1px solid #aec6ad18;flex:none}#move{flex:1;min-width:0;display:flex;align-items:center;gap:7px;text-align:left;background:none;padding:4px;cursor:grab;touch-action:none;font-weight:650}#move:active{cursor:grabbing}.grip{color:#7b9886;font-size:16px}#count{color:#e4c38d;font-size:11px;font-variant-numeric:tabular-nums}#collapse,#add-toggle{background:none;width:26px;height:26px;color:#a7bcaf;font-size:18px;border-radius:5px}
  #body{min-height:0;display:flex;flex-direction:column}#list{overflow:auto;overscroll-behavior:contain;min-height:0;margin:0;padding:3px 5px;list-style:none}li{display:flex;gap:4px;align-items:center;min-height:32px;padding:1px 3px;border-bottom:1px solid #aec6ad0c}li:last-child{border:0}
  button.name{display:flex;align-items:center;gap:7px;min-width:0;flex:1;text-align:left;background:none;padding:5px 0;cursor:help;border-radius:3px}.card-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:550}.copies{color:#e5c58e;font-size:11px;white-space:nowrap;font-variant-numeric:tabular-nums}button.name:hover .card-name{color:#f2d39b;text-decoration:underline;text-underline-offset:3px}
  .played,.remove{flex:none;display:grid;place-items:center;width:25px;height:26px;border-radius:5px;background:none;color:#92b39e;font-size:16px}.played:hover{background:#9dc7ac20;color:#e5d1a3}.remove{color:#647e6e;font-size:15px}.remove:hover{color:#ffb4af}.moved{font-size:9px;color:#c4b38b}li[data-played=true] .card-name{color:#9eb3a4}
  #empty{margin:11px 12px;color:#aec0b3;font-size:11px}#add{display:flex;gap:5px;padding:6px 8px;border-top:1px solid #304a3d}#name{background:#0a1b16;border:1px solid #3b5846;border-radius:6px;padding:6px;width:100%;min-width:0}#add button{border-radius:6px;padding:5px 8px;background:#ddbe87;color:#13271f;font-weight:650}
  footer{display:flex;align-items:center;gap:8px;min-height:24px;padding:0 5px 3px 9px;font-size:10px}#played-toggle,#undo{background:none;color:#a9bfb0;padding:3px 0}#undo{color:#e9c991}#resize{margin-left:auto;background:none;color:#789481;width:22px;height:21px;cursor:nwse-resize;touch-action:none;font-size:15px}#error{color:#ffb8ab;font-size:11px;margin:5px 10px}
  section.collapsed header{border:0}.collapsed #body,.collapsed #add-toggle,.collapsed .heading{display:none}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}
  #preview{position:fixed;z-index:1;margin:0;padding:6px;background:#0b1714;border:1px solid #69826e;border-radius:12px;box-shadow:0 12px 40px #0009;color:#eaf1ea;font:12px/1.4 system-ui,sans-serif;overflow:hidden}
  #preview-image{display:block;width:100%;height:100%;object-fit:contain;border-radius:7px}#preview-face{position:relative;width:100%;aspect-ratio:744/1039;background:#12251c;border-radius:7px;overflow:hidden}
  #preview-message{position:absolute;inset:0;display:grid;place-content:center;margin:0;padding:26px;text-align:center;color:#b6c9bb}#preview-caption{padding:7px 26px 1px 3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #preview-close{position:absolute;right:7px;bottom:4px;width:25px;height:25px;border:0;border-radius:50%;background:#0b1714ed;color:#fff;font-size:19px}
  </style><section aria-label="Revealed cards"><header><button id="move" type="button" aria-label="Move revealed cards" title="Drag to move"><span class="grip" aria-hidden="true">⠿</span><span class="heading">Revealed</span><span id="count">0</span></button><button id="add-toggle" type="button" aria-label="Add a revealed card" aria-expanded="false" title="Add card">+</button><button id="collapse" type="button" aria-label="Collapse revealed cards" aria-expanded="true">−</button></header><div id="body"><p id="empty">No revealed cards yet.</p><ul id="list" aria-label="Remembered opponent cards"></ul><p id="error" role="status" hidden></p><form id="add" hidden><input id="name" maxlength="160" aria-label="Card name" placeholder="Card name…" autocomplete="off"><button type="submit">Add</button></form><footer><button id="played-toggle" type="button" aria-pressed="false" hidden></button><button id="undo" type="button" hidden>Undo</button><button id="resize" type="button" aria-label="Resize revealed cards" title="Resize list">◢</button></footer></div><span id="announcement" class="sr-only" role="status"></span></section><figure id="preview" role="tooltip" hidden><div id="preview-face"><img id="preview-image" referrerpolicy="no-referrer" alt="" hidden><p id="preview-message" role="status"></p></div><figcaption id="preview-caption"></figcaption><button id="preview-close" type="button" aria-label="Close card preview">×</button></figure>`;
  const $=s=>shadow.querySelector(s),rows=new Map();document.documentElement.append(host);
  let groups=new Map(),showPlayed=false,adding=false,busy=false,renderToken=null;
  const viewport=()=>({width:Math.min(innerWidth,document.documentElement.clientWidth||innerWidth),height:innerHeight});
  let previewID=null,previewToken=null,pinned=false,showTimer,hideTimer;
  function closePreview(){
    clearTimeout(showTimer);clearTimeout(hideTimer);
    for(const row of rows.values())row.querySelector('.name').removeAttribute('aria-describedby');
    previewID=null;previewToken=null;pinned=false;$('#preview').hidden=true;
    const img=$('#preview-image');img.onload=null;img.onerror=null;img.removeAttribute('src');img.hidden=true;
  }
  function placePreview(){
    if(!previewID)return;
    const row=rows.get(previewID),anchor=row?.getBoundingClientRect(),panel=host.getBoundingClientRect();
    if(!anchor)return closePreview();
    // Put the card beside the panel when possible; clamp it on small viewports.
    const view=viewport();
    const width=Math.max(1,Math.min(340,view.width-16,(view.height-60)*744/1039+12));
    const height=(width-12)*1039/744+40;
    const right=view.width-panel.right-16,left=panel.left-16;
    const x=right>=width?panel.right+8:left>=width?panel.left-width-8:
      right>=left?view.width-width-8:8;
    const y=Math.max(8,Math.min(anchor.top-7,view.height-height-8));
    Object.assign($('#preview').style,{left:Math.max(8,x)+'px',top:y+'px',width:width+'px'});
  }
  function showPreview(id,pin=false){
    clearTimeout(showTimer);clearTimeout(hideTimer);
    const group=groups.get(id),card=group?.cards.find(c=>c.artwork)||group?.cards[0];
    if(!card||host.hidden||layout.collapsed||moving)return;
    if(previewID!==id||previewToken!==state.token)closePreview();
    previewID=id;previewToken=state.token;pinned=pin;
    const image=$('#preview-image'),message=$('#preview-message');
    const artwork=globalThis.RiftLedgerRevealArt.cleanURL(card.artwork);
    $('#preview').hidden=false;$('#preview-caption').textContent=card.name;
    rows.get(id).querySelector('.name').setAttribute('aria-describedby','preview');
    if(artwork && image.getAttribute('src')!==artwork){
      image.hidden=true;message.hidden=false;message.textContent='Loading card…';
      image.alt=card.name+' card face with printed costs and rules';
      image.onload=()=>{image.hidden=false;message.hidden=true;};
      image.onerror=()=>{image.hidden=true;message.hidden=false;message.textContent='Card image unavailable.';};
      image.src=artwork;
    }else if(!artwork){
      image.removeAttribute('src');image.hidden=true;message.hidden=false;
      message.textContent=card.source==='manual'?'Added by name. No card image was captured.':'No image captured yet. Reveal this card again to add its image.';
    }
    placePreview();
  }
  const scheduleClose=()=>{clearTimeout(showTimer);clearTimeout(hideTimer);if(!pinned)hideTimer=setTimeout(()=>{
    // Keep a keyboard-opened preview available while its name has focus.
    if(shadow.activeElement!==rows.get(previewID)?.querySelector('.name'))closePreview();
  },160);};
  $('#preview').onpointerenter=()=>clearTimeout(hideTimer);
  $('#preview').onpointerleave=scheduleClose;
  $('#preview-close').onclick=closePreview;
  host.addEventListener('keydown',e=>{if(e.key==='Escape'){if(previewID){e.preventDefault();closePreview();}else if(adding){e.preventDefault();adding=false;render();$('#add-toggle').focus();}}});
  $('#list').addEventListener('scroll',()=>{if(!pinned)closePreview();else placePreview();});
  function fit(){
    const view=viewport(),maxW=Math.max(1,view.width-16),maxH=Math.max(1,view.height-16);
    const width=Math.min(layout.collapsed?96:layout.width,maxW);
    host.style.width=width+'px';host.style.height='auto';$('section').style.maxHeight=Math.min(layout.height,maxH)+'px';
    const height=$('section').getBoundingClientRect().height||Math.min(layout.collapsed?34:64+groups.size*33,layout.height,maxH);
    layout.x=Math.max(8,Math.min(layout.x,view.width-width-8));layout.y=Math.max(8,Math.min(layout.y,view.height-height-8));
    Object.assign(host.style,{left:layout.x+'px',top:layout.y+'px',width:width+'px'});
    placePreview();
  }
  function render(){
    host.hidden=!enabled||!state||state.phase!=='game';if(host.hidden){closePreview();return;}
    if(renderToken!==state.token){showPlayed=false;adding=false;closePreview();renderToken=state.token;}
    const all=globalThis.RiftLedgerRevealGroups.groups(state.cards),playedCount=state.cards.filter(c=>c.status==='played').length;
    if(!playedCount)showPlayed=false;
    groups=new Map(all.filter(g=>(g.status==='played')===showPlayed).map(g=>[g.key,g]));
    if(previewID&&(previewToken!==state.token||layout.collapsed||!groups.has(previewID)))closePreview();
    $('section').classList.toggle('collapsed',layout.collapsed);$('#collapse').textContent=layout.collapsed?'+':'−';
    $('#collapse').setAttribute('aria-label',(layout.collapsed?'Expand':'Collapse')+' revealed cards');$('#collapse').setAttribute('aria-expanded',String(!layout.collapsed));
    $('#count').textContent=String(state.cards.length-playedCount);$('#move').title=state.name+' · Drag to move';
    $('#empty').hidden=groups.size>0;$('#empty').textContent=state.cards.length?'No unplayed cards.':'No revealed cards yet.';
    $('#add').hidden=!adding;$('#add-toggle').setAttribute('aria-expanded',String(adding));
    $('#played-toggle').hidden=!playedCount;$('#played-toggle').textContent=showPlayed?'← Back to revealed':'Played '+playedCount;
    $('#played-toggle').setAttribute('aria-pressed',String(showPlayed));
    const undo=state.undo?.at(-1);$('#undo').hidden=!undo;$('#undo').disabled=busy;
    $('#undo').title=undo?'Undo last change to '+undo.name:'';
    for(const [key,row] of rows)if(!groups.has(key)){row.remove();rows.delete(key);}
    let rowIndex=0;
    for(const group of groups.values()){
      const key=group.key;let row=rows.get(key);
      if(!row){
        row=document.createElement('li');row.innerHTML='<button class="name" type="button"><span class="card-name"></span><span class="copies"></span></button><span class="moved" hidden>Trash</span><button class="played" type="button">✓</button><button class="remove" type="button">×</button>';
        const name=row.querySelector('.name');
        name.onpointerenter=()=>{if(pinned)return;const token=state?.token;clearTimeout(hideTimer);clearTimeout(showTimer);showTimer=setTimeout(()=>{if(token===state?.token)showPreview(key);},120);};
        name.onpointerleave=scheduleClose;name.onfocus=()=>showPreview(key);name.onblur=scheduleClose;
        name.onclick=()=>{if(previewID===key&&pinned)closePreview();else showPreview(key,true);};
        row.querySelector('.played').onclick=()=>groupEdit(key,showPlayed?'restore-one':'play-one');
        row.querySelector('.remove').onclick=()=>groupEdit(key,'remove-one');
        rows.set(key,row);
      }
      const at=$('#list').children[rowIndex++];if(at!==row)$('#list').insertBefore(row,at||null);
      row.querySelector('.card-name').textContent=group.name;row.dataset.played=String(showPlayed);
      const copies=row.querySelector('.copies');copies.textContent='×'+group.count;copies.hidden=group.count<2;
      row.querySelector('.name').setAttribute('aria-label',group.name+(group.count>1?' ×'+group.count:'')+' · Preview card');
      row.querySelector('.moved').hidden=group.status!=='moved';
      const turns=[...new Set(group.cards.map(c=>c.turn).filter(Boolean))].join(', ');
      row.title=(group.status==='moved'?'Moved to trash; not necessarily played. ':showPlayed?'Marked or seen played. ':'')+(turns?'Revealed on turn '+turns:'Added card');
      const action=row.querySelector('.played');action.textContent=showPlayed?'↶':'✓';
      action.setAttribute('aria-label',(showPlayed?'Restore':'Mark played')+' one '+group.name);action.title=showPlayed?'Restore one copy':'Mark one copy played';action.disabled=busy;
      const remove=row.querySelector('.remove');remove.setAttribute('aria-label','Remove one '+group.name+' from notes');remove.title='Remove one copy';remove.disabled=busy;
    }
    $('#add button').disabled=busy;
    if(previewID)showPreview(previewID,pinned);
    fit();
  }
  function groupEdit(key,action){const group=groups.get(key);if(group)edit({action,group:key,stamp:group.stamp});}
  const error=message=>{$('#error').textContent=message||'';$('#error').hidden=!message;if(!host.hidden)fit();};
  function request(message){
    const job=queue.then(async()=>{
      if(stopped)return null;
      const response=await chrome.runtime.sendMessage(message);
      if(!response?.ok)throw Error(response?.error||'Refresh RiftAtlas to reconnect the helper.');
      return response.result;
    });queue=job.catch(()=>{});return job;
  }
  async function settings(){
    try{const p=await request({type:'reveal-settings-get'});if(stopped||!p)return;
      enabled=p.enabled;layout=p.layout;last='';if(!enabled){state=null;rows.clear();$('#list').replaceChildren();}
      render();if(enabled)sample();
    }catch{host.hidden=true;enabled=false;}
  }
  async function sample(){
    if(!enabled||stopped||document.hidden||moving)return;
    const observation=globalThis.RiftLedgerReveals.read(document),signature=JSON.stringify(observation);
    if(signature===last)return;last=signature;
    try{const p=await request({type:'reveal-observe',observation});if(stopped||!p)return;enabled=p.enabled;state=p.state;render();}
    catch(e){last='';error(e.message);}
  }
  async function edit(change){
    const token=state?.token;if(!token||busy)return;const focused=shadow.activeElement;busy=true;render();
    try{const p=await request({type:'reveal-edit',token,...change});if(stopped||!p)return;
      enabled=p.enabled;state=p.state;error('');render();
      $('#announcement').textContent=change.action==='play-one'?'One copy marked played.':change.action==='undo'?'Last change undone.':change.action==='restore-one'?'One copy restored.':'Card notes updated.';
      return true;
    }catch(e){error(e.message);last='';sample();}
    finally{busy=false;if(!stopped){render();if(focused&&!focused.isConnected){if(!$('#undo').hidden)$('#undo').focus();else $('#move').focus();}}}
  }
  $('#add-toggle').onclick=()=>{adding=!adding;render();if(adding)$('#name').focus();};
  $('#played-toggle').onclick=()=>{showPlayed=!showPlayed;closePreview();render();};
  $('#undo').onclick=()=>{const actionID=state?.undo?.at(-1)?.actionID;if(actionID)edit({action:'undo',actionID});};
  $('#add').onsubmit=async e=>{e.preventDefault();const input=$('#name'),name=input.value.trim();if(!name||busy)return;
    if(await edit({action:'add',name})){if(input.value.trim()===name)input.value='';input.focus();}
  };
  const saveLayout=()=>request({type:'reveal-layout',layout:{...layout}}).catch(e=>error(e.message));
  $('#collapse').onclick=()=>{layout.collapsed=!layout.collapsed;render();saveLayout();};
  for(const [id,resize] of [['move',false],['resize',true]]){
    const handle=$('#'+id);
    handle.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();closePreview();moving={x:e.clientX,y:e.clientY,start:{...layout},resize};handle.setPointerCapture(e.pointerId);};
    handle.onpointermove=e=>{if(!moving)return;const dx=e.clientX-moving.x,dy=e.clientY-moving.y,s=moving.start;
      if(resize){layout.width=Math.min(600,Math.max(210,s.width+dx));layout.height=Math.min(900,Math.max(120,s.height+dy));}
      else {layout.x=s.x+dx;layout.y=s.y+dy;}fit();};
    const finish=()=>{if(!moving)return;moving=null;saveLayout();sample();};
    handle.onpointerup=finish;handle.onpointercancel=finish;handle.onlostpointercapture=finish;
    handle.onkeydown=e=>{const dirs={ArrowLeft:[-10,0],ArrowRight:[10,0],ArrowUp:[0,-10],ArrowDown:[0,10]};if(!dirs[e.key])return;e.preventDefault();
      const [x,y]=dirs[e.key];if(resize){layout.width=Math.min(600,Math.max(210,layout.width+x));layout.height=Math.min(900,Math.max(120,layout.height+y));}else{layout.x+=x;layout.y+=y;}fit();saveLayout();};
  }
  // Do not let typing notes trigger the board's draw/turn shortcuts.
  for(const type of ['keydown','keyup','keypress','pointerdown','pointerup','click','dblclick','wheel'])host.addEventListener(type,e=>e.stopPropagation());
  const schedule=()=>{if(enabled&&!timer)timer=setTimeout(()=>{timer=null;sample();},180);};
  const observer=new MutationObserver(schedule);
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['data-room-phase','data-turn-number','data-card-id','data-drop-zone','data-face-down','data-visual-hidden','data-zone-owner','aria-hidden','hidden','style','alt','src','srcset']});
  const onVisibility=()=>{if(document.hidden)closePreview();last='';sample();};
  const fullscreen=()=>{(document.fullscreenElement||document.documentElement).append(host);fit();};
  const listener=(m,sender)=>{if(sender.id===chrome.runtime.id&&m.type==='reveal-refresh')settings();};
  chrome.runtime.onMessage.addListener(listener);document.addEventListener('visibilitychange',onVisibility);
  document.addEventListener('fullscreenchange',fullscreen);window.addEventListener('resize',fit);
  const heartbeat=setInterval(()=>{if(enabled)sample();else settings();},15000);
  // Catch the end of card-flip animations after DOM mutation notifications.
  const faces=setInterval(()=>{if(enabled)sample();},1000);
  globalThis.riftLedgerRevealStop=()=>{stopped=true;closePreview();observer.disconnect();clearTimeout(timer);clearInterval(heartbeat);clearInterval(faces);host.remove();
    document.removeEventListener('visibilitychange',onVisibility);document.removeEventListener('fullscreenchange',fullscreen);window.removeEventListener('resize',fit);
    try{chrome.runtime.onMessage.removeListener(listener);}catch{}
  };
  settings();
})();
