// Absolute values from RiftAtlas's visible priority clocks. Never infer priority
// from the turn owner or add wall time while a clock is unavailable.
export const validPrioritySeconds = value => Array.isArray(value) && value.length === 2 &&
  value.every(n => Number.isInteger(n) && n >= 0 && n <= 604800);

export function observePriorityTiming(record, snapshot, now) {
  if (record.reviewed || record.deleted) return;
  if (validPrioritySeconds(snapshot.prioritySeconds)) {
    // A rewind may lower a clock. Copy the authoritative reading, not a max or delta.
    record.priorityTiming = {version:1, source:'riftatlas', seconds:[...snapshot.prioritySeconds],
      observedAt:now, atResult:snapshot.outcome !== 'unknown', available:true};
  } else if (record.priorityTiming) {
    record.priorityTiming.available = false;
    if (snapshot.outcome === 'unknown') record.priorityTiming.atResult = false;
  }
}

export function prioritySummary(record) {
  const clock = record?.priorityTiming;
  if (clock?.version !== 1 || clock.source !== 'riftatlas' || !validPrioritySeconds(clock.seconds)) return null;
  const total = clock.seconds[0] + clock.seconds[1];
  const ownShare = total ? Math.round(clock.seconds[0] / total * 100) : null;
  return {total, seconds:[...clock.seconds], shares:total ? [ownShare, 100 - ownShare] : [null, null],
    atResult:clock.atResult === true, available:clock.available !== false};
}

export function portablePriorityTiming(record) {
  const summary = prioritySummary(record);
  return summary ? {version:1, source:'riftatlas', seconds:summary.seconds, atResult:summary.atResult} : undefined;
}
