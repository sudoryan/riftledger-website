/* Only rendered faces on the opponent's board. No app internals, logs or hidden-card names. */
(() => {
  function visible(element) {
    if(!element || element.closest('[hidden],[aria-hidden="true"]'))return false;
    for(let e=element;e&&e.nodeType===1;e=e.parentElement){
      const s=getComputedStyle(e);
      if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||s.opacity==='0')return false;
    }
    const r=element.getBoundingClientRect();
    return r.width>0&&r.height>0&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;
  }
  function read(document) {
    const root=document.querySelector('[data-testid="game-state"]');
    if(!root)return null;
    const a=n=>root.getAttribute('data-'+n)||'';
    if(/spectat|solo|practice|goldfish|single_player/i.test(a('room-mode')))return null;
    const viewer=a('viewer-player-id'),opponent=a('opponent-player-id');
    const roomNode=document.querySelector('[data-testid="room-code"]');
    const room=roomNode?.getAttribute('data-room-code')||roomNode?.textContent?.trim();
    if(!room||!viewer||!opponent||viewer==='unknown'||opponent==='unknown'||viewer===opponent||
      !document.querySelector('[aria-label="Your score track"]'))return null;
    const phase=a('room-phase')==='in_game'?'game':/mulligan|battlefield|roll|initiative|setup|pregame|sideboard/i.test(a('room-phase'))?'setup':null;
    if(!phase)return null;
    const name=document.querySelector('[data-player-identity-trigger="opponent"] [data-identity-player-name]')?.textContent?.trim().slice(0,60)||'Opponent';
    const cards=[];
    if(phase==='game')for(const node of document.querySelectorAll('[data-zone-owner="opponent"] button[data-card-id][data-drop-zone]')) {
      const zone=node.getAttribute('data-drop-zone');
      if(!['hand','base','battlefieldA','battlefieldB','trash'].includes(zone)||node.getAttribute('data-face-down')==='true'||node.getAttribute('data-visual-hidden')==='true'||!visible(node))continue;
      // Check visibility BEFORE touching alt text: a flipped card may retain its front in the DOM.
      const images=[...node.querySelectorAll('img[data-rift-image-kind="card"]')].filter(visible);
      if(images.length!==1)continue;
      const name=images[0].getAttribute('alt')?.trim();
      if(!name||/^(hidden card|card back|unknown)$/i.test(name))continue;
      // src is the full-size face; currentSrc can be a tiny responsive thumbnail.
      // Never inspect image URLs until the same face has passed the visibility checks.
      const artwork=globalThis.RiftLedgerRevealArt.cleanURL(images[0].getAttribute('src')) ||
        globalThis.RiftLedgerRevealArt.cleanURL(images[0].currentSrc);
      cards.push({id:node.getAttribute('data-card-id'),name:name.slice(0,160),zone,...(artwork?{artwork}:{})});
      if(cards.length===200)break;
    }
    return {room:room.slice(0,80),viewer,opponent,name,phase,turn:/^\d{1,3}$/.test(a('turn-number'))?Number(a('turn-number')):0,cards};
  }
  globalThis.RiftLedgerReveals={read};
})();
