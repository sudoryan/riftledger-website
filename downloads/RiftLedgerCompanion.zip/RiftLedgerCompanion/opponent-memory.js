// Remembered opponents are derived from local match history, never exported as a directory.
export const experienceLevels = {unrated:'Unrated', newby:'Newby', newish:'Newish', experienced:'Experienced', pro:'Pro'};
export const opponentKey = name => typeof name === 'string' ? name.trim().normalize('NFC').toLowerCase() : '';
const validTime = value => Number.isFinite(value) && value > 0;

export function rememberedOpponents(records, excludeID) {
  const opponents = new Map();
  for (const record of records || []) {
    const name = typeof record.names?.[1] === 'string' ? record.names[1].trim() : '', key = opponentKey(name);
    if (record.id === excludeID || record.deleted || !key || name.length > 60 ||
        !Object.hasOwn(experienceLevels, record.opponentExperience) ||
        (record.games && !validTime(record.opponentExperienceUpdatedAt)) ||
        (!record.reviewed && !validTime(record.opponentExperienceUpdatedAt))) continue;
    const updatedAt = validTime(record.opponentExperienceUpdatedAt) ? record.opponentExperienceUpdatedAt : record.date;
    if (!validTime(updatedAt)) continue;
    if (!opponents.has(key) || updatedAt > opponents.get(key).updatedAt)
      opponents.set(key, {name, experience:record.opponentExperience, updatedAt});
  }
  return opponents;
}

// A score/deck edit must not make an older assessment the newest one.
export function rememberExperienceReview(record, previous, now = Date.now()) {
  if (!Object.hasOwn(experienceLevels, record.opponentExperience)) return;
  if (!previous.reviewed || opponentKey(previous.names?.[1]) !== opponentKey(record.names?.[1]) ||
      previous.opponentExperience !== record.opponentExperience) record.opponentExperienceUpdatedAt = now;
  else if (validTime(previous.opponentExperienceUpdatedAt) || validTime(previous.date))
    record.opponentExperienceUpdatedAt = validTime(previous.opponentExperienceUpdatedAt) ? previous.opponentExperienceUpdatedAt : previous.date;
  else delete record.opponentExperienceUpdatedAt;
}
