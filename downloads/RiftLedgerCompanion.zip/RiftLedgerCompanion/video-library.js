import {ACTIVE_VIDEO_STATES,videoSize,videoTime,videoResolution} from './video-model.js';

export function createVideoLibrary({root,store,onOpen,showError,onChange}) {
  const doc=root.ownerDocument,$=s=>root.querySelector(s);
  const node=(tag,text,cls)=>{const el=doc.createElement(tag);if(text!=null)el.textContent=text;if(cls)el.className=cls;return el;};
  const title=v=>v.names?.join(' vs ')||'RiftAtlas recording';
  const active=v=>ACTIVE_VIDEO_STATES.includes(v.status);
  const stamp=items=>JSON.stringify(items.map(v=>[v.id,v.status,v.bytes]));
  let records=[],selected=new Set(),confirmation=null,pending=false;
  $('h1').textContent='Video library';
  $('.video-note').textContent='Watch your recordings and clips, or select several to free up space.';
  const controls=node('section',null,'library-controls');controls.setAttribute('aria-label','Manage videos');
  controls.innerHTML=`<div class="library-search"><label>Search videos<input id="library-search" type="search" placeholder="Player or legend name"></label><label>Show<select id="library-kind"><option value="all">All footage</option><option value="match">Match videos</option><option value="clip">Clips</option></select></label></div><div class="library-selection"><label><input id="library-select-all" type="checkbox"> Select all shown</label><span id="library-count" role="status"></span><button id="library-clear">Clear selection</button><button id="library-delete" class="library-danger" disabled>Delete selected</button></div><p id="library-empty" class="video-note" hidden>No videos match this search.</p><p id="library-feedback" role="status"></p>`;
  root.insertBefore(controls,$('#video-list'));
  const dialog=node('dialog',null,'library-confirm');dialog.setAttribute('aria-labelledby','library-confirm-title');
  dialog.innerHTML=`<h2 id="library-confirm-title">Delete selected videos?</h2><p id="library-confirm-summary"></p><p>This permanently deletes the selected footage from this browser. Match history and unselected videos or clips stay.</p><ul id="library-confirm-list"></ul><p id="library-confirm-error" role="alert" hidden></p><div class="library-confirm-actions"><button id="library-cancel">Keep videos</button><button id="library-confirm-delete" class="library-danger">Delete permanently</button></div>`;
  root.append(dialog);
  function filtered(){
    const query=$('#library-search').value.trim().toLocaleLowerCase(),kind=$('#library-kind').value;
    return records.filter(v=>(kind==='all'||v.kind===kind)&&(!query||[title(v),...(v.legends||[])].join(' ').toLocaleLowerCase().includes(query)));
  }
  function chosen(){return records.filter(v=>selected.has(v.id));}
  function dismiss(){confirmation=null;if(dialog.open)dialog.close();}
  function selectionUI(){
    const available=filtered().filter(v=>!active(v)),items=chosen(),bytes=items.reduce((n,v)=>n+(v.bytes||0),0);
    $('#library-select-all').checked=available.length>0&&available.every(v=>selected.has(v.id));
    $('#library-select-all').indeterminate=available.some(v=>selected.has(v.id))&&!$('#library-select-all').checked;
    $('#library-select-all').disabled=pending||!available.length;
    $('#library-count').textContent=items.length?`${items.length} selected · ${videoSize(bytes)}`:`${filtered().length} of ${records.length} videos`;
    $('#library-delete').disabled=pending||!items.length;$('#library-clear').disabled=pending||!items.length;
    $('#library-delete').textContent=items.length?`Delete selected (${items.length})`:'Delete selected';
    for(const box of root.querySelectorAll('[data-select-video]')){
      box.checked=selected.has(box.dataset.selectVideo);box.disabled=pending||active(records.find(v=>v.id===box.dataset.selectVideo));
      box.closest('.library-card').dataset.selected=String(box.checked);
    }
    $('#library-search').disabled=pending;$('#library-kind').disabled=pending;
  }
  function render(){
    const list=$('#video-list'),shown=filtered();list.replaceChildren();
    $('#video-empty').hidden=records.length>0;$('#library-empty').hidden=!records.length||!!shown.length;
    for(const v of shown){
      const card=node('article',null,'library-card');card.dataset.id=v.id;
      const top=node('div',null,'library-card-top'),label=node('label',null,'library-check'),box=node('input');
      box.type='checkbox';box.dataset.selectVideo=v.id;box.setAttribute('aria-label',`Select ${v.kind==='clip'?'clip':'video'}: ${title(v)} · ${new Date(v.createdAt).toLocaleString()}`);
      label.append(box,node('span','Select'));top.append(label,node('span',v.kind==='clip'?'CLIP':'MATCH VIDEO','video-kicker'));
      box.onchange=()=>{if(pending)return;box.checked?selected.add(v.id):selected.delete(v.id);$('#library-feedback').textContent='';selectionUI();};
      const open=node('button',null,'library-open');open.type='button';open.setAttribute('aria-label',`Watch ${title(v)}`);
      open.append(node('span','▶','library-play'),node('strong',title(v)),node('span',new Date(v.createdAt).toLocaleString([],{month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'}),'library-date'));
      const facts=node('div',null,'library-facts');facts.append(node('span',videoTime(v.duration)),node('span',videoSize(v.bytes)));
      open.append(facts,node('span',videoResolution(v),'library-resolution'));
      if(active(v))open.append(node('em',v.status==='processing'?'Preparing clip…':'Recording…'));
      else if(v.status==='interrupted')open.append(node('em',v.bytes?'Partial recording':'No footage saved'));
      open.disabled=active(v);open.onclick=()=>onOpen(v.id);card.append(top,open);list.append(card);
    }
    selectionUI();
  }
  function resetFilter(){if(pending)return;selected.clear();dismiss();$('#library-feedback').textContent='';render();}
  $('#library-search').oninput=resetFilter;$('#library-kind').onchange=resetFilter;
  $('#library-select-all').onchange=()=>{if(pending)return;for(const v of filtered().filter(v=>!active(v)))$('#library-select-all').checked?selected.add(v.id):selected.delete(v.id);selectionUI();};
  $('#library-clear').onclick=()=>{if(!pending){selected.clear();selectionUI();}};
  $('#library-delete').onclick=()=>{
    if(pending||!selected.size)return;
    const items=chosen();confirmation={ids:items.map(v=>v.id),stamp:stamp(items)};
    $('#library-confirm-summary').textContent=`${items.length} video${items.length===1?'':'s'} · ${videoSize(items.reduce((n,v)=>n+(v.bytes||0),0))} will be removed.`;
    $('#library-confirm-list').replaceChildren(...items.map(v=>node('li',`${title(v)} · ${new Date(v.createdAt).toLocaleString()} · ${v.kind==='clip'?'Clip':'Match video'} · ${videoTime(v.duration)} · ${videoSize(v.bytes)}`)));
    $('#library-confirm-error').hidden=true;dialog.showModal();$('#library-cancel').focus();
  };
  $('#library-cancel').onclick=()=>{if(!pending)dismiss();};
  dialog.addEventListener('cancel',event=>{if(pending)event.preventDefault();else confirmation=null;});
  $('#library-confirm-delete').onclick=async()=>{
    if(pending||!confirmation)return;
    const ids=confirmation.ids.slice();pending=true;$('#library-confirm-delete').disabled=true;$('#library-cancel').disabled=true;selectionUI();
    try{
      const result=await store.removeMany(ids);selected.clear();dismiss();
      $('#library-feedback').textContent=result.count?`Deleted ${result.count} video${result.count===1?'':'s'} · Freed ${videoSize(result.bytes)}. Match history is unchanged.`:'These videos were already removed.';
      showError(null);try{await onChange();}catch(error){showError(error);}
    }catch(error){$('#library-confirm-error').textContent=error.message;$('#library-confirm-error').hidden=false;}
    finally{pending=false;$('#library-confirm-delete').disabled=false;$('#library-cancel').disabled=false;selectionUI();}
  };
  return {
    update(next){
      records=next;
      for(const id of selected)if(!records.some(v=>v.id===id&&!active(v)))selected.delete(id);
      if(confirmation&&!pending&&confirmation.stamp!==stamp(chosen())){dismiss();$('#library-feedback').textContent='The selected videos changed. Review your selection before deleting.';}
      render();
    },
    close(){if(!pending)dismiss();}
  };
}
