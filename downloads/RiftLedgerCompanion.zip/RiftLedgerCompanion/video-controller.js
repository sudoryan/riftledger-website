import {installToolbarRecording} from './toolbar-recording.js';
import {videoNoticeKind} from './video-notice.js';
import {VideoStore} from './video-store.js';
import {limitBytes,VIDEO_LIMITS,DEFAULT_VIDEO_LIMIT,VIDEO_QUALITIES,VIDEO_FRAME_RATES,videoFrameRate,videoQuality,matchRecordings} from './video-model.js';
import {microphonePreference,microphoneInputs} from './microphone.js';
import {videoLocation} from './video-location.js';
import {recordingReport} from './video-report.js';
export function installVideoController(api=chrome,{store=new VideoStore(),storageManager=globalThis.navigator?.storage}={}) {
  let queue=Promise.resolve(), session=null, sessionKey=null, notice='',recorderNotice='',activity=[];
  const navigationEpoch=new Map();
  const isAtlasURL=value=>{try{return new URL(value).origin==='https://play.riftatlas.com';}catch{return false;}};
  const validHandshake=answer=>!!(answer?.ok&&answer.version===2&&typeof answer.documentToken==='string'&&answer.documentToken.length>0&&answer.documentToken.length<=80);
  async function handshake(tabId){
    let deadline;try{return await Promise.race([api.tabs.sendMessage(tabId,{type:'capture-status'},{frameId:0}),
      new Promise((_,reject)=>{deadline=setTimeout(()=>reject(Error('No reply')),4000);})]);}finally{clearTimeout(deadline);}
  }
  let storageCheckedAt=-Infinity, storageEstimate=null;
  async function estimateStorage(){
    if(Date.now()-storageCheckedAt>=30000){
      storageCheckedAt=Date.now();storageEstimate=null;
      try{
        const value=await storageManager?.estimate();
        if(Number.isFinite(value?.quota)&&value.quota>0&&Number.isFinite(value.usage)&&value.usage>=0)
          storageEstimate={quota:value.quota,usage:value.usage};
      }catch{/* A quota estimate is advisory; failure must not block recording. */}
    }
    return storageEstimate;
  }
  const initial=Promise.all([api.storage.session.get(['videoSession','videoSessionKey','videoNotice','videoRecorderNotice']),api.storage.local.get(['videoLastNotice','videoActivity'])]).then(([v,local])=>{
    session=v.videoSession||null;sessionKey=v.videoSessionKey||null;recorderNotice=v.videoRecorderNotice||'';notice=local.videoLastNotice||v.videoNotice||'';activity=local.videoActivity||[];
  });
  const run=fn=>{const result=queue.then(()=>initial).then(fn);queue=result.catch(()=>{});return result;};
  const popup=sender=>sender.id===api.runtime.id&&!sender.tab&&sender.url?.split(/[?#]/)[0]===api.runtime.getURL('popup.html');
  const micSetup=sender=>sender.id===api.runtime.id&&sender.url?.split(/[?#]/)[0]===api.runtime.getURL('microphone-setup.html');
  const companion=sender=>sender.id===api.runtime.id&&sender.url?.split(/[?#]/)[0]===api.runtime.getURL('companion.html');
  const companionCommands=['video-status','video-report','video-quality','video-frame-rate','video-audio','video-limit','video-microphone','video-microphone-setup','video-toolbar-auto','video-shortcuts','video-dismiss-notice','video-match-recordings','video-open-page','video-stop'];
  const player=sender=>sender.id===api.runtime.id&&sender.url?.split(/[?#]/)[0]===api.runtime.getURL('video-page.html');
  const contexts=()=>api.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[api.runtime.getURL('offscreen.html')]});
  async function ensure(){if(!(await contexts()).length)await api.offscreen.createDocument({url:'offscreen.html',reasons:['USER_MEDIA','BLOBS'],justification:'Record the RiftAtlas tab selected by the user and prepare local video clips while the popup is closed.'});}
  async function call(action,data={}){const response=await api.runtime.sendMessage({target:'video-offscreen',action,...data});if(!response?.ok)throw Error(response?.error||'Video recorder is unavailable.');return response.result;}
  const badge=tabId=>!session||session.tabId!==tabId?null:session.kind==='auto'?{text:['waiting','reconnecting'].includes(session.phase)?'AUTO':'VID',color:['waiting','reconnecting'].includes(session.phase)?'#8C7144':'#BD5262',title:session.phase==='reconnecting'?'Auto-recording enabled · Reconnecting to RiftAtlas':session.phase==='waiting'?'Auto-recording enabled · Waiting for a game':'Auto-recording this game'}:session.kind==='match'?{text:'VID',color:'#BD5262',title:'Video recording in progress'}:null;
  async function update(status, nextNotice=notice) {
    const old=session,oldNotice=notice;
    if(!status)sessionKey=null;
    else if(!sessionKey||!old||old.tabId!==status.tabId||old.kind!==status.kind||status.kind!=='auto'&&old.id!==status.id)sessionKey=crypto.randomUUID();
    session=status;notice=nextNotice;
    toolbar.state(status);
    if(old?.id!==status?.id||old?.kind!==status?.kind||old?.phase!==status?.phase||oldNotice!==notice){
      activity.push({at:Date.now(),kind:status?'active':'ended',id:status?.id||old?.id,mode:status?.kind||old?.kind,phase:status?.phase,quality:status?.quality||old?.quality,requestedFrameRate:status?.requestedFrameRate||old?.requestedFrameRate,reason:notice});
      activity=activity.slice(-40);
      // Diagnostics must never prevent footage from being finalized.
      await api.storage.local.set({videoLastNotice:notice,videoActivity:activity,...(oldNotice!==notice?{videoDismissedNotice:null}:{})}).catch(()=>{});
    }
    await api.storage.session.set({videoSession:status,videoSessionKey:sessionKey,videoNotice:notice,videoRecorderNotice:recorderNotice});
    const tabId=status?.tabId??old?.tabId;
    const appearance=badge(tabId);
    if(tabId!=null)await Promise.all([
      api.action.setBadgeText({tabId,text:appearance?.text||''}),
      api.action.setBadgeBackgroundColor({tabId,color:appearance?.color||'#BD5262'}),
      api.action.setTitle({tabId,title:appearance?`Rift Ledger · ${appearance.title}`:'Rift Ledger · Video session ended'})
    ]).catch(()=>{});
  }
  async function status({tabContext=false}={}){
    let active=null;
    let nextNotice=notice;
    if((await contexts()).length){const state=await call('status');active=state.active;if((state.notice||'')!==recorderNotice){recorderNotice=state.notice||'';if(recorderNotice)nextNotice=recorderNotice;}}
    else if(session){nextNotice='Video session was interrupted. Enable recording again to continue.';}
    // A failed final metadata write can leave an orphan even while the offscreen
    // document survives. Never recover while its recorder is still active.
    if(!active)await store.recover();
    await update(active,nextNotice);
    const {videoLimitMB=DEFAULT_VIDEO_LIMIT,videoQuality:quality,videoFrameRate:frameRate}=await api.storage.local.get(['videoLimitMB','videoQuality','videoFrameRate']);
    const {videoMicrophone,videoMicrophones=[]}=await api.storage.local.get(['videoMicrophone','videoMicrophones']);
    const {videoToolbarAuto=false,videoAudio=true,videoDismissedNotice}=await api.storage.local.get(['videoToolbarAuto','videoAudio','videoDismissedNotice']);
    const commands=await api.commands.getAll?.()||[];
    // Permission, not the estimate, determines whether Chrome enforces its
    // normal quota. Disk exhaustion can still fail a write in either mode.
    let unlimitedStorage=false;
    try{unlimitedStorage=await api.permissions.contains({permissions:['unlimitedStorage']})===true;}catch{}

    return {active,sessionKey,tabContext:tabContext?await recordingTabContext(active):null,notice,noticeKind:videoNoticeKind(notice),noticeDismissed:videoDismissedNotice===notice,toolbarAuto:videoToolbarAuto,audio:videoAudio,unlimitedStorage,storageEstimate:await estimateStorage(),microphone:microphonePreference(videoMicrophone),microphones:videoMicrophones,quality:videoQuality(quality).id,requestedFrameRate:videoFrameRate(frameRate),limitMB:videoLimitMB,shortcut:commands.find(c=>c.name==='mark-highlight')?.shortcut||''};
  }
  async function stop(reason=''){
    let result;
    if((await contexts()).length){result=await call('stop',{reason});await status();}
    else await update(null,reason||notice);
    return result||null;
  }
  async function recordingTabContext(active){
    if(!['auto','match'].includes(active?.kind))return null;
    const [tab]=await api.tabs.query({active:true,currentWindow:true});
    if(!tab||tab.id===active.tabId)return null;
    let answer;try{answer=await handshake(tab.id);}catch{}
    // The reader only runs on RiftAtlas. No broad tabs/host permission or tab
    // inventory is needed, even when Chrome withholds the tab URL.
    if(!isAtlasURL(tab.url)&&!validHandshake(answer))return null;
    return {otherTab:true,currentTabId:tab.id,recordedTabId:active.tabId,
      canSwitch:!active.stopping&&validHandshake(answer)&&['waiting','recording','review','saved'].includes(answer.result?.kind),
      hint:validHandshake(answer)?String(answer.result?.title||''): 'Refresh this RiftAtlas tab to reconnect the extension.'};
  }
  async function prepareCapture(m,tabId){
    if(!(await api.permissions.contains({permissions:['tabCapture']})))throw Error('Allow tab recording when you press Start recording.');
    const [tab]=await api.tabs.query({active:true,currentWindow:true});
    if(tabId!=null&&tab?.id!==tabId)throw Error('Return to the RiftAtlas tab and click the icon again.');
    if(!tab)throw Error('Open your RiftAtlas tab first.');
    const epoch=navigationEpoch.get(tab.id);
    let answer;
    try{answer=await handshake(tab.id);}catch{throw Error('Open RiftAtlas and refresh it before starting video.');}
    if(!answer?.ok||answer.version!==2||!['waiting','recording','review','saved'].includes(answer.result?.kind))throw Error('Open a playable RiftAtlas game with capture enabled first.');
    if(m.type==='video-auto'&&!validHandshake(answer))throw Error('Refresh RiftAtlas to connect the updated auto-recorder.');
    const {videoLimitMB=DEFAULT_VIDEO_LIMIT,videoQuality:quality,videoFrameRate:frameRate}=await api.storage.local.get(['videoLimitMB','videoQuality','videoFrameRate']);
    if((await store.list()).reduce((sum,v)=>sum+v.bytes,0)>=limitBytes(videoLimitMB))throw Error('Video storage is full. Delete a video or raise the limit first.');
    if(epoch!==navigationEpoch.get(tab.id))throw Error('The tab changed while recording was starting. Click the icon again.');
    return {tab,epoch,answer,videoLimitMB,quality,frameRate};
  }
  async function launchCapture(m,{tab,epoch,answer,videoLimitMB,quality,frameRate}){
    const [current]=await api.tabs.query({active:true,currentWindow:true});
    if(current?.id!==tab.id)throw Error('The active tab changed. Open the extension on your game tab again.');
    await ensure();
    if(epoch!==navigationEpoch.get(tab.id))throw Error('The tab changed while recording was starting. Click the icon again.');
    const streamID=await api.tabCapture.getMediaStreamId({targetTabId:tab.id});
    const {videoMicrophone}=await api.storage.local.get('videoMicrophone');
    if(epoch!==navigationEpoch.get(tab.id))throw Error('The tab changed while recording was starting. Click the icon again.');
    const active=await call('start',{microphone:microphonePreference(videoMicrophone),streamID,tabId:tab.id,documentToken:answer.documentToken,audio:!!m.audio,cap:limitBytes(videoLimitMB),quality:videoQuality(quality).id,requestedFrameRate:videoFrameRate(frameRate),auto:m.type==='video-auto'});
    await update(active,'');
    // Request a fresh public snapshot after recording is active.
    api.tabs.sendMessage(tab.id,{type:'capture-refresh'}).catch(()=>{});
    return active;
  }
  async function startCapture(m,tabId){
    if((await status()).active)throw Error('A recording or clip is already running.');
    return launchCapture(m,await prepareCapture(m,tabId));
  }
  async function switchCapture(m){
    const current=await status(),source=current.active;
    if(!['auto','match'].includes(source?.kind)||source.stopping||current.sessionKey!==m.sessionKey||source.tabId!==m.fromTabId)
      throw Error('The recording changed. Check the current session and try again.');
    if(!Number.isInteger(m.targetTabId)||m.targetTabId===source.tabId)throw Error('Choose a different RiftAtlas tab.');
    const {videoAudio=true}=await api.storage.local.get('videoAudio');
    const request={type:source.kind==='auto'?'video-auto':'video-start',audio:videoAudio};
    // Validate before stopping; never interrupt a good recording for a paused,
    // excluded, unrelated or navigated target tab.
    const target=await prepareCapture(request,m.targetTabId);
    const [activeTab]=await api.tabs.query({active:true,currentWindow:true});
    if(activeTab?.id!==target.tab.id||target.epoch!==navigationEpoch.get(target.tab.id))throw Error('The destination tab changed. Try again on your game tab.');
    const saved=await stop('Recording switched to another RiftAtlas tab.');
    if(saved?.error)throw Error(`The previous recording could not finish cleanly: ${saved.error} Recording was not started on this tab.`);
    // Do not carry a short-lived capture token across finalization. Acquire it
    // only after the previous stream and its last chunk have been closed.
    try{return await startCapture(request,target.tab.id);}
    catch(error){throw Error(`The previous session has ended. Recording did not start on this tab: ${error.message}`);}
  }
  const toolbar=installToolbarRecording(api,{status:()=>run(status),start:tabId=>run(async()=>{
    const {videoAudio=true,videoToolbarAuto}=await api.storage.local.get(['videoAudio','videoToolbarAuto']);
    if(videoToolbarAuto!==true)throw Error('One-click auto-record is off.');
    return startCapture({type:'video-auto',audio:videoAudio},tabId);
  }),failed:error=>run(()=>update(session,`Video did not start: ${error.message}`))});
  api.runtime.onMessage.addListener((m,sender,respond)=>{
    if(m?.type==='video-event'&&sender.id===api.runtime.id&&!sender.tab&&sender.url===api.runtime.getURL('offscreen.html')){
      run(status).then(()=>respond({ok:true})).catch(e=>respond({ok:false,error:e.message}));return true;
    }
    if(!m?.type?.startsWith('video-'))return;
    // A playback tab can inspect jobs and create clips, but cannot begin capture.
    if(!popup(sender)&&!(companion(sender)&&companionCommands.includes(m.type))&&!(player(sender)&&['video-status','video-report','video-clip'].includes(m.type))&&!(micSetup(sender)&&['video-status','video-microphone-inputs','video-microphone'].includes(m.type)))return;
    run(async()=>{
      switch(m.type){
        case 'video-status':return status({tabContext:popup(sender)});
        case 'video-switch-tab':return switchCapture(m);
        case 'video-focus-tab':{
          const current=await status();
          if(!['auto','match'].includes(current.active?.kind)||current.sessionKey!==m.sessionKey||current.active.tabId!==m.fromTabId)throw Error('That recording session has ended.');
          const tab=await api.tabs.update(current.active.tabId,{active:true});
          if(tab.windowId!=null)await api.windows.update(tab.windowId,{focused:true});
          return null;
        }
        case 'video-toolbar-auto':
          if(typeof m.enabled!=='boolean')throw Error('Choose whether toolbar clicks start auto-recording.');
          if(m.enabled&&!await api.permissions.contains({permissions:['tabCapture']}))throw Error('Allow tab recording before enabling one-click auto-record.');
          await toolbar.configure(m.enabled);return null;
        case 'video-audio':
          if(typeof m.enabled!=='boolean')throw Error('Choose whether to include tab audio.');
          if((await status()).active)throw Error('End the current recording session before changing audio.');
          await api.storage.local.set({videoAudio:m.enabled});return null;
        case 'video-dismiss-notice':
          if(typeof m.notice==='string'&&m.notice===notice)await api.storage.local.set({videoDismissedNotice:notice});
          return null;
        case 'video-match-recordings':{
          const {ledger}=await api.storage.local.get('ledger');
          const record=typeof m.id==='string'?ledger?.records?.find(r=>r.id===m.id):null;
          return record?matchRecordings(await store.list(),record):[];
        }
        case 'video-report':{
          const current=await status(),videos=await store.list(),{ledger}=await api.storage.local.get('ledger');
          return recordingReport({version:api.runtime.getManifest().version,status:current,activity,videos,matches:ledger?.records||[]});
        }
        case 'video-microphone-setup':
          if((await status()).active)throw Error('End the current recording session before setting up a microphone.');
          await api.tabs.create({url:api.runtime.getURL('microphone-setup.html')});return null;
        case 'video-microphone-inputs':{
          if(!micSetup(sender))throw Error('Open microphone setup to refresh inputs.');
          if((await status()).active)throw Error('End the current recording session before changing microphone inputs.');
          const inputs=microphoneInputs(m.devices);await api.storage.local.set({videoMicrophones:inputs});return inputs;
        }
        case 'video-microphone':{
          if((await status()).active)throw Error('End the current recording session before changing microphone.');
          if(typeof m.enabled!=='boolean')throw Error('Choose whether to include your microphone.');
          const {videoMicrophone,videoMicrophones=[]}=await api.storage.local.get(['videoMicrophone','videoMicrophones']);
          let preference={...microphonePreference(videoMicrophone),enabled:m.enabled};
          if(m.enabled){
            const input=videoMicrophones.find(d=>d.deviceId===m.deviceId);
            if(!videoMicrophones.length||!input&&m.deviceId!=='default')throw Error('Set up your microphone first, then choose an available input.');
            preference={enabled:true,deviceId:m.deviceId,label:m.deviceId==='default'?'System default microphone':input.label};
          }
          await api.storage.local.set({videoMicrophone:preference});return preference;
        }
        case 'video-open-library':
          await api.tabs.create({url:api.runtime.getURL('video-page.html')});return null;
        case 'video-open-page':{
          const record=typeof m.id==='string'?await store.get(m.id):null;
          if(!record||!record.bytes||!['ready','interrupted'].includes(record.status))throw Error('Choose a saved video first.');
          await api.tabs.create({url:api.runtime.getURL('video-page.html')+videoLocation(record.id,Math.min(Number(m.at)||0,record.duration))});
          return null;
        }
        case 'video-shortcuts':await api.tabs.create({url:'chrome://extensions/shortcuts'});return null;
        case 'video-limit':
          if(!VIDEO_LIMITS.includes(Number(m.value)))throw Error('Choose a supported storage limit.');
          if((await status()).active)throw Error('End the current recording session before changing the storage limit.');
          await api.storage.local.set({videoLimitMB:Number(m.value)});return null;
        case 'video-frame-rate':
          if(!VIDEO_FRAME_RATES.includes(m.value))throw Error('Choose 30 or 60 fps.');
          if((await status()).active)throw Error('End the current recording session before changing frame rate.');
          await api.storage.local.set({videoFrameRate:m.value});return null;
        case 'video-quality':
          if(!VIDEO_QUALITIES.some(q=>q.id===m.value))throw Error('Choose a supported recording quality.');
          if((await status()).active)throw Error('End the current recording session before changing quality.');
          await api.storage.local.set({videoQuality:m.value});return null;
        case 'video-start':
        case 'video-auto':{
          return startCapture(m);
        }
        case 'video-stop':return stop();
        case 'video-highlight':if(!(await contexts()).length)throw Error('Start a video recording first.');return call('highlight');
        case 'video-clip':{
          await ensure();const {videoLimitMB=DEFAULT_VIDEO_LIMIT}=await api.storage.local.get('videoLimitMB');
          return call('clip',{id:m.id,start:m.start,end:m.end,cap:limitBytes(videoLimitMB)});
        }
        default:throw Error('Unknown video request.');
      }
    }).then(result=>respond({ok:true,result})).catch(async error=>{
      if(['video-start','video-auto','video-clip','video-switch-tab'].includes(m.type)&&!session)await update(null,`Video did not start: ${error.message}`).catch(()=>{});
      respond({ok:false,error:error.message});
    });return true;
  });
  api.tabs.onRemoved.addListener(tabId=>{void toolbar.forget(tabId,true).catch(()=>{});navigationEpoch.delete(tabId);run(async()=>{if(session?.tabId===tabId)await stop('Recorded tab closed.');}).catch(()=>{});});
  api.tabs.onUpdated.addListener((tabId,change)=>{
    if(!change.status&&!change.url)return;
    if(change.url&&!isAtlasURL(change.url))void toolbar.forget(tabId).catch(()=>{});
    if(change.status==='loading'||change.url)navigationEpoch.set(tabId,(navigationEpoch.get(tabId)||0)+1);
    const epoch=navigationEpoch.get(tabId);
    run(async()=>{
      if(session?.tabId!==tabId)return;
      // Chrome can keep a tab stream through navigation. Suspend encoding and
      // require the RiftAtlas content script from the arriving document before
      // using it again. No tabs or broad host permissions are needed.
      if(change.url&&!isAtlasURL(change.url)){await stop('Recorded tab left RiftAtlas. Auto-recording ended.');return;}
      if(change.status==='loading'){
        if(session.kind==='auto')await update(await call('navigate'));
        else await stop('Tab navigated or refreshed. Start a new video to continue.');
      }
      if(change.status==='complete'&&session?.kind==='auto'&&session.phase==='reconnecting'){
        let answer;try{answer=await handshake(tabId);}catch{}
        if(epoch!==navigationEpoch.get(tabId))return;
        if(!validHandshake(answer)){await stop('Could not reconnect to RiftAtlas. Enable auto-recording again on your game tab.');return;}
        await update(await call('reconnect',{documentToken:answer.documentToken}));
        api.tabs.sendMessage(tabId,{type:'capture-refresh'}).catch(()=>{});
      }
    }).catch(async error=>{if(session?.tabId===tabId)await stop(`Video navigation failed: ${error.message}`).catch(()=>{});});
  });
  api.commands.onCommand.addListener(command=>{if(command==='mark-highlight')run(async()=>{if(session?.kind==='match'||session?.kind==='auto'&&session.phase==='recording')await call('highlight');}).catch(()=>{});});
  return {
    badge,
    observe:(snapshot,matchID,tabId,context)=>run(async()=>{
      void toolbar.observe(tabId,context?.kind).catch(()=>{});
      if(!['match','auto'].includes(session?.kind)||session.tabId!==tabId)return;
      try{await call('observe',{snapshot,matchID,tabId,context});}
      catch(error){await status().catch(()=>{});await update(session,`Video recording problem: ${error.message}`);}
    }).catch(()=>{}),
    pause:()=>run(()=>stop('Game capture paused.')).catch(()=>{})
  };
}
