import {microphoneConstraints,microphoneError,microphonePreference} from './microphone.js';
// Mix to one encoded track. Only tab audio is monitored through the speakers.
// Raw microphone/tab tracks belong to this capture session, not to game clones.
export async function prepareRecordingAudio(tabStream,{microphone,onMicrophoneEnded=()=>{},mediaDevices=navigator.mediaDevices,permissions=navigator.permissions,Context=AudioContext,Stream=MediaStream}={}) {
  const mic=microphonePreference(microphone);let micStream,context,closed=false;
  const nodes=[];
  const cleanup=()=>{
    if(closed)return;closed=true;
    micStream?.getTracks().forEach(t=>t.stop());tabStream.getTracks().forEach(t=>t.stop());
    for(const n of nodes)n.disconnect();
    if(context)void context.close().catch(()=>{});
  };
  try {
    if(mic.enabled){
      try {
        // Prompts belong to the visible setup page, never an invisible document.
        const permission=await permissions.query({name:'microphone'});
        if(permission.state!=='granted')throw Object.assign(Error('Permission required'),{name:'NotAllowedError'});
        micStream=await mediaDevices.getUserMedia(microphoneConstraints(mic.deviceId));
        if(!micStream.getAudioTracks().length)throw Object.assign(Error('No audio input'),{name:'NotFoundError'});
      }catch(error){throw Error(microphoneError(error));}
    }
    const output=new Stream(tabStream.getVideoTracks());
    if(tabStream.getAudioTracks().length||micStream){
      context=new Context();const destination=context.createMediaStreamDestination();nodes.push(destination);
      if(tabStream.getAudioTracks().length){const source=context.createMediaStreamSource(tabStream);nodes.push(source);source.connect(destination);source.connect(context.destination);}
      if(micStream){const source=context.createMediaStreamSource(micStream);nodes.push(source);source.connect(destination);}
      await context.resume();destination.stream.getAudioTracks().forEach(t=>output.addTrack(t));
      nodes.push({disconnect:()=>destination.stream.getTracks().forEach(t=>t.stop())});
    }
    for(const track of micStream?.getAudioTracks()||[])track.addEventListener('ended',()=>{if(!closed)onMicrophoneEnded('The selected microphone disconnected. Saved footage was kept.');},{once:true});
    return {stream:output,cleanup,microphone:mic.enabled?{enabled:true,label:micStream.getAudioTracks()[0].label||mic.label}:{enabled:false}};
  }catch(error){cleanup();throw error;}
}
