// Durations are observed wall time on the active player's turn, not thinking time.
// No interval is assigned across a missed heartbeat, hidden tab, reload or pause.
const MAX_GAP = 45000, MAX_SECONDS = 604800, MAX_TURNS = 2000;
const round = n => Math.round(n * 1000) / 1000;
export const timingSeconds = timing => timing ? round(timing.unassignedSeconds + timing.turns.reduce((n, t) => n + t.seconds, 0)) : 0;
export function interruptTiming(records, session) {
  for (const r of records) {
    const c = r._timingCursor;
    if (!c || c.stopped || (session && c.session !== session)) continue;
    c.interrupted = true;
    if (c.index != null) r.timing.turns[c.index].complete = false;
    r.timing.partial = true;
  }
}
export function observeTiming(r, s, now, context = {}) {
  const player = [0, 1].includes(s.activePlayer) ? s.activePlayer : null;
  const number = Number.isInteger(s.turn) && s.turn > 0 ? s.turn : null;
  const visible = context.visible !== false;
  const known = player !== null && number !== null && visible;
  const stopped = s.outcome !== 'unknown';
  if (!r.timing) {
    r.timing = {version: 1, turns: [], unassignedSeconds: r.seconds || 0, partial: !!r.seconds || s.turn !== 1 || !known};
  }
  const t = r.timing, previous = r._timingCursor;
  if (previous?.stopped && stopped) return; // Do not count time spent looking at a result.
  const elapsed = previous ? Math.max(0, Math.min(MAX_SECONDS - timingSeconds(t), (now - previous.at) / 1000)) : 0;
  const continuous = previous && !previous.stopped && !previous.interrupted && visible && previous.visible &&
    context.session === previous.session && now >= previous.at && now - previous.at <= MAX_GAP;
  const same = previous && previous.player === player && previous.number === number;
  const next = previous && number === previous.number + 1 && player !== previous.player;
  const transition = known && next;
  const attributable = continuous && known && previous.index != null && (same || transition);
  if (attributable) {
    const turn = t.turns[previous.index]; turn.seconds = round(turn.seconds + elapsed);
  } else if (elapsed > 0) {
    t.unassignedSeconds = round(t.unassignedSeconds + elapsed); t.partial = true;
    if (previous?.index != null) t.turns[previous.index].complete = false;
  }
  let index = same && previous && !previous.stopped ? previous.index : null;
  const changed = previous && !same;
  if (changed && (!transition || !continuous)) {
    t.partial = true;
    if (previous.index != null) t.turns[previous.index].complete = false;
    // Keep wall time already spent on rewound turns, but exclude these from extrema.
    if (number !== null && previous.number !== null && number <= previous.number) {
      for (const turn of t.turns) if (turn.number >= number) turn.complete = false;
    }
  }
  if (known && index == null && !stopped && t.turns.length < MAX_TURNS) {
    index = t.turns.length;
    const complete = previous ? !!(continuous && transition) : number === 1 && !r.seconds;
    t.turns.push({number, player, seconds: 0, complete});
  }
  if (!known || (!same && stopped) || (known && index == null && !stopped)) t.partial = true;
  r._timingCursor = {at: Math.max(now, previous?.at || now), player, number, index, session: context.session, visible, stopped};
  r.seconds = Math.round(timingSeconds(t));
}
export function timingSummary(r, now) {
  if (!r?.timing) return null;
  const t = r.timing, c = r._timingCursor;
  const activeIndex = c && !c.stopped && !r.reviewed ? c.index : null;
  // UI-only interpolation. Durable intervals are added exclusively by observeTiming.
  const extra = now && c && !c.stopped && !c.interrupted && c.visible && !r.reviewed
    ? Math.max(0, Math.min(15000, now - c.at)) / 1000 : 0;
  const players = [0, 1].map(player => {
    const all = t.turns.filter(turn => turn.player === player);
    const completed = t.turns.filter((turn, i) => turn.player === player && turn.complete && i !== activeIndex);
    const seconds = completed.map(turn => turn.seconds);
    return {total: all.reduce((n, turn) => n + turn.seconds, 0) + (c?.player === player ? extra : 0),
      count: completed.length, average: seconds.length ? seconds.reduce((a,b) => a+b, 0) / seconds.length : null,
      shortest: seconds.length ? Math.min(...seconds) : null, longest: seconds.length ? Math.max(...seconds) : null};
  });
  return {total: timingSeconds(t) + extra, unassigned: t.unassignedSeconds, partial: t.partial, players,
    current: activeIndex != null ? {...t.turns[activeIndex], seconds: t.turns[activeIndex].seconds + extra, running: !c.interrupted && c.visible} : null};
}
export function portableTiming(r) {
  if (!r.timing) return undefined;
  const timing = structuredClone(r.timing);
  // Manually finishing a game does not prove that its last turn was fully observed.
  const c = r._timingCursor;
  if (c && !c.stopped && c.index != null) { timing.turns[c.index].complete = false; timing.partial = true; }
  return timing;
}
export function duration(value) {
  if (value == null) return '—';
  const seconds = Math.max(0, Math.floor(value));
  return seconds >= 3600 ? `${Math.floor(seconds / 3600)}:${String(Math.floor(seconds / 60) % 60).padStart(2,'0')}:${String(seconds % 60).padStart(2,'0')}`
    : `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2,'0')}`;
}
