import {createClipEditor} from './clip-editor.js';
import {createVideoLibrary} from './video-library.js';
import {microphonePreference} from './microphone.js';
import {VideoStore} from './video-store.js';
import {createVideoTimeline} from './video-timeline.js';
import {renderVideoLayout} from './video-layout.js';
import {videoTime,videoSize,videoExtension,videoLimitLabel,limitBytes,videoQuality,videoResolution,ACTIVE_VIDEO_STATES} from './video-model.js';
export function createVideos({root,send,showError,isVisible,store=new VideoStore(),permissions=globalThis.chrome?.permissions,fullPage=false,settingsOnly=false,onSelect=()=>{},onBack=()=>{},onStatus=()=>{}}) {
  if(!root.querySelector('#video-player'))renderVideoLayout(root);
  const $=s=>root.querySelector(s), node=(tag,text,cls)=>{const e=root.ownerDocument.createElement(tag);if(text!=null)e.textContent=text;if(cls)e.className=cls;return e;};
  if(settingsOnly){
    root.classList.add('recording-settings');
    const heading=node('div',null,'settings-heading');heading.append(node('span','MAKE IT YOURS','recap-eyebrow'),node('h1','Recording settings'),node('p','Start recording from the extension button on your RiftAtlas tab.','section-help'));root.prepend(heading);
    $('#video-toolbar-help').textContent='One click on RiftAtlas arms recording. Click again to open the popup.';
    $('#video-library h1').textContent='Storage & shortcuts';
  }
  $('#video-manage').hidden=fullPage||settingsOnly;
  $('#video-open-page').hidden=fullPage;$('#video-transport').hidden=!fullPage;
  $('#video-clip-moment').setAttribute('aria-expanded','false');
  let selected=null, sourceURL=null, sourceBlob=null, active=null, pending=false, generation=0, request=0, records=[], rangeEnd=null, libraryStamp='',microphoneStamp='';
  const safely=async fn=>{try{showError(null);await fn();}catch(error){showError(error);}};
  const action=fn=>safely(async()=>{if(pending)return;pending=true;try{await fn();}finally{pending=false;await refresh();}});
  const trimmer=createClipEditor({root:$('.video-range'),player:$('#video-player'),onChange:()=>{rangeEnd=null;},onSeek:at=>{rangeEnd=null;$('#video-player').onloadedmetadata=null;$('#video-player').pause();$('#video-player').currentTime=at;timeline.update(at);trimmer.updatePlayhead(at);}});
  const library=fullPage?createVideoLibrary({root:$('#video-library'),store,onOpen:id=>safely(()=>openRecord(id)),showError,onChange:()=>refresh()}):null;
  const timeline=createVideoTimeline({root:$('#video-marker-section'),onChoose:range=>safely(async()=>{
    trimmer.setRange(range);
    await playRange();
  })});
  async function refresh(){
    if(!isVisible())return;
    const epoch=++request;
    const [status,list]=await Promise.all([send({type:'video-status'}),store.list()]);
    if(epoch!==request||!isVisible())return;
    $('#video-toolbar-auto').checked=status.toolbarAuto===true;$('#video-toolbar-auto').disabled=pending;
    if(!pending)$('#video-audio').checked=status.audio!==false;
    $('#video-shortcut').textContent=status.shortcut?`Highlight shortcut: ${status.shortcut}`:'No highlight shortcut assigned.';
    if(status.active?.id&&status.active.id!==active?.id)$('#video-feedback').textContent='';
    records=list;active=status.active;trimmer.setBusy(active);root.dataset.active=String(!!active);
    onStatus(status);
    $('#video-start').hidden=!!active;$('#video-auto').hidden=!!active;$('#video-stop').hidden=!active;$('#video-highlight').hidden=!(active?.kind==='match'||active?.kind==='auto'&&active.phase==='recording');
    $('#video-session-summary').hidden=active?.kind!=='auto';
    $('#video-session-summary').textContent=active?.kind==='auto'?`${active.games} video${active.games===1?'':'s'} saved this session · Chrome’s capture indicator stays on while enabled.`:'';
    $('#video-ended').textContent=status.notice||'';$('#video-ended').hidden=!status.notice;
    $('#video-saved-progress').hidden=!active?.id;
    $('#video-saved-progress').textContent=active?.bytes?`${videoSize(active.bytes)} saved locally · Through ${videoTime(active.savedSeconds||0)}`:'Waiting for the first video data to save…';
    if(active?.id&&(active.elapsed||0)-(active.savedSeconds||0)>30)$('#video-saved-progress').textContent+=' · No recent video data received. Check the recording before continuing.';
    $('#video-quality').disabled=!!active||pending;
    $('#video-frame-rate').disabled=!!active||pending;
    const quality=videoQuality(active?.quality||status.quality,active?.requestedFrameRate??status.requestedFrameRate);
    if(root.ownerDocument.activeElement!==$('#video-frame-rate')||active)$('#video-frame-rate').value=String(quality.fps);
    if(root.ownerDocument.activeElement!==$('#video-quality')||active)$('#video-quality').value=quality.id;
    $('#video-quality-note').textContent=`Up to ${quality.id} at ${quality.fps} fps · About ${Math.round((quality.bitrate+128000)*60/8/1024/1024)} MB/min. Actual detail and frame rate depend on the tab size and your computer.${quality.fps===60?' If playback is choppy, choose 30 fps or a lower resolution.':quality.id==='2160p'?' If 4K is choppy, choose 1440p.':''}`;
    const mic=microphonePreference(status.microphone), inputs=status.microphones||[];
    const micStamp=JSON.stringify([mic,inputs]);
    if(micStamp!==microphoneStamp){microphoneStamp=micStamp;const select=$('#video-microphone');select.replaceChildren();
      const option=(value,label)=>{const o=node('option',label);o.value=value;select.append(o);};option('','Off');
      if(inputs.length)option('default','System default microphone');
      for(const input of inputs.filter(d=>d.deviceId!=='default'))option(input.deviceId,input.label);
      if(mic.enabled&&!inputs.some(d=>d.deviceId===mic.deviceId)&&!(mic.deviceId==='default'&&inputs.length))option(mic.deviceId,mic.label+' · Check setup');
      select.value=mic.enabled?mic.deviceId:'';
    }
    $('#video-microphone').disabled=!!active||pending;$('#video-microphone-setup').disabled=!!active||pending;
    const liveMic=active?.microphone;
    $('#video-mic-status').textContent=active?.kind==='clip'?'Clips use the audio already in their source video.':liveMic?.enabled?`Mic connected: ${liveMic.label}${active.kind==='auto'?' · Stays active while auto-record is on.':''}`:mic.enabled?`Include ${mic.label}. Auto-record keeps the microphone connected between games.`:'Microphone off · RiftAtlas tab only';
    $('#video-audio').disabled=!!active||pending;$('#video-limit').disabled=!!active||pending;
    if(root.ownerDocument.activeElement!==$('#video-limit'))$('#video-limit').value=String(status.limitMB);
    const used=list.reduce((s,v)=>s+v.bytes,0), estimate=status.storageEstimate;
    $('#video-used').textContent=`${videoSize(used)} / ${videoLimitLabel(status.limitMB)} used`;
    const available=estimate?Math.max(0,estimate.quota-estimate.usage):null;
    $('#video-quota-note').hidden=status.unlimitedStorage===true||available==null||available>=Math.max(0,limitBytes(status.limitMB)-used);
    $('#video-quota-note').textContent=available==null?'':`Chrome currently estimates ${videoSize(available)} remaining under its storage quota. Recording may stop before your chosen limit. This is not a measurement of free disk space.`;
    $('#video-storage-note').textContent=(status.unlimitedStorage===true?'Chrome’s storage quota is removed. ':'')+`Your ${videoLimitLabel(status.limitMB)} limit covers recordings and clips together. Recording stops at that limit or if disk space runs out. The extension never automatically deletes videos.`;
    $('#video-status').textContent=active?.kind==='auto'?(active.phase==='reconnecting'?'Auto-record on · Reconnecting to RiftAtlas':active.phase==='waiting'?'Auto-record on · Waiting for a game':active.stopping?'Saving game…':`Auto-recording · ${videoTime(active.elapsed)} · ${active.highlights} highlights`):active?.kind==='match'?(active.stopping?'Saving video…':`Recording · ${videoTime(active.elapsed)} · ${active.highlights} highlights`):active?.kind==='clip'?`Preparing clip · ${Math.round((active.progress||0)*100)}%`:'Video recording is off';
    if(status.tabContext?.otherTab)$('#video-status').textContent+=' · Another tab';
    $('#video-status').dataset.active=String(!!active);$('#video-status').dataset.waiting=String(active?.kind==='auto'&&['waiting','reconnecting'].includes(active.phase));
    $('#video-stop').textContent=active?.stopping?'Saving…':active?.kind==='clip'?'Stop clip':active?.kind==='auto'?'End auto-recording':'Stop & save';
    $('#video-stop').disabled=!!active?.stopping||pending;
    $('#video-start').disabled=pending;$('#video-auto').disabled=pending;$('#video-highlight').disabled=pending||!!active?.stopping;
    $('#video-empty').hidden=!!list.length;
    const stamp=JSON.stringify(list);
    if(stamp!==libraryStamp){libraryStamp=stamp;
    if(library)library.update(list);else {
    $('#video-list').replaceChildren();
    for(const record of list){
      const b=node('button',null,'video-row');b.dataset.id=record.id;
      b.append(node('span',record.kind==='clip'?'CLIP':'MATCH VIDEO','video-kicker'),node('strong',record.names?.join(' vs ')||'RiftAtlas recording'),node('span',`${new Date(record.createdAt).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})} · ${videoTime(record.duration)} · ${videoSize(record.bytes)}${videoResolution(record)?` · ${videoResolution(record)}`:""}`));
      if(ACTIVE_VIDEO_STATES.includes(record.status))b.append(node('em',record.status==='processing'?'Preparing clip…':'Recording…'));
      else if(record.status==='interrupted')b.append(node('em','Partial recording'));
      b.disabled=ACTIVE_VIDEO_STATES.includes(record.status);b.onclick=()=>safely(()=>openRecord(record.id));$('#video-list').append(b);
    }
    }
    }
    if(selected){
      const current=list.find(v=>v.id===selected.id);if(!current){closePlayer();onBack();showError(Error('This video was deleted. Choose another recording.'));return;}
      $('#video-make-clip').disabled=!!active||pending||!selected.bytes;
    }
  }
  function closePlayer(){
    ++generation;selected=null;sourceBlob=null;rangeEnd=null;timeline.clear();trimmer.clear();
    $('#video-player').onloadedmetadata=null;
    $('#video-player').pause();$('#video-player').removeAttribute('src');$('#video-player').load();
    if(sourceURL)URL.revokeObjectURL(sourceURL);sourceURL=null;
    root.dataset.detail='false';root.dataset.trimming='false';$('#video-detail').hidden=true;$('#video-library').hidden=false;$('#video-delete-confirm').hidden=true;
    $('#video-clip-moment').setAttribute('aria-expanded','false');
  }
  async function openRecord(id,{at=0}={}){
    closePlayer();const epoch=generation;
    const record=await store.get(id);
    if(!record)throw Error('This video is no longer available. Choose another recording.');
    if(ACTIVE_VIDEO_STATES.includes(record.status))throw Error('Save this recording before playing it.');
    $('#video-loading').hidden=false;
    try {
      const blob=record.bytes?await store.blob(id):null;if(epoch!==generation||!isVisible())return;
      selected=record;sourceBlob=blob;sourceURL=blob?URL.createObjectURL(blob):null;
      const position=Number.isFinite(Number(at))?Math.max(0,Math.min(Number(at),record.duration||0)):0;
      $('#video-player').onloadedmetadata=()=>{
        if(epoch!==generation)return;
        const duration=$('#video-player').duration;
        $('#video-player').currentTime=Math.min(position,Number.isFinite(duration)?duration:position);
        timeline.update($('#video-player').currentTime);trimmer.updatePlayhead($('#video-player').currentTime);
        $('#video-player').onloadedmetadata=null;
      };
      $('#video-player').hidden=!blob;$('#video-player').src=sourceURL||'';$('#video-player').load();
      $('#video-speed').value='1';$('#video-player').playbackRate=1;
      for(const key of ['#video-clip-moment','#video-download','#video-play-full','#video-play-range','#video-make-clip','#video-open-page','#video-rewind','#video-forward','#video-speed'])$(key).disabled=!blob;
      $('#video-name').textContent=record.names?.join(' vs ')||'RiftAtlas recording';
      $('#video-info').textContent=`${record.kind==='clip'?'Clip':'Match video'} · ${videoTime(record.duration)} · ${videoSize(record.bytes)}${videoResolution(record)?` · ${videoResolution(record)}`:""}`;
      if(record.microphone?.enabled)$('#video-info').textContent+=` · Mic: ${record.microphone.label}`;
      $('#video-reason').textContent=record.reason||'';$('#video-reason').hidden=!record.reason;
      root.dataset.detail='true';$('#video-detail').hidden=false;$('#video-library').hidden=true;
      trimmer.setSource({duration:record.duration,src:sourceURL,at:position});
      timeline.set(record,position);
      $('#video-marker-section').hidden=record.kind==='clip';
      $('#video-make-clip').disabled=!!active||!blob;
      onSelect(record,position);
      root.ownerDocument.querySelector('main').scrollTop=0;
    } finally {if(epoch===generation)$('#video-loading').hidden=true;}
  }
  async function playRange(){
    const range=trimmer.range();
    rangeEnd=range.end;$('#video-player').currentTime=range.start;timeline.update(range.start);await $('#video-player').play();root.ownerDocument.querySelector('main').scrollTop=0;
  }
  $('#video-player').addEventListener('timeupdate',()=>{timeline.update($('#video-player').currentTime);trimmer.updatePlayhead($('#video-player').currentTime);if(rangeEnd!=null&&$('#video-player').currentTime>=rangeEnd){$('#video-player').pause();$('#video-player').currentTime=rangeEnd;trimmer.updatePlayhead(rangeEnd);rangeEnd=null;}});
  $('#video-player').addEventListener('seeking',()=>{timeline.update($('#video-player').currentTime);trimmer.updatePlayhead($('#video-player').currentTime);});
  $('#video-player').addEventListener('error',()=>{if(selected)showError(Error('This recording could not be played. Try downloading its saved footage.'));});
  const start=type=>action(async()=>{
    // Optional permission request remains directly inside the user's click handler.
    if(!await permissions.request({permissions:['tabCapture']}))throw Error('Tab recording was not allowed. Match results are still captured normally.');
    await send({type:'video-audio',enabled:$('#video-audio').checked});
    await send({type,audio:$('#video-audio').checked});$('#video-feedback').textContent='';
  });
  $('#video-toolbar-auto').onchange=()=>action(async()=>{
    const enabled=$('#video-toolbar-auto').checked;
    if(enabled&&!await permissions.request({permissions:['tabCapture']}))throw Error('Tab recording was not allowed. One-click auto-record stays off.');
    await send({type:'video-toolbar-auto',enabled});
  });
  $('#video-audio').onchange=()=>action(()=>send({type:'video-audio',enabled:$('#video-audio').checked}));
  $('#video-start').onclick=()=>start('video-start');
  $('#video-auto').onclick=()=>start('video-auto');
  $('#video-stop').onclick=()=>action(async()=>{await send({type:'video-stop'});$('#video-feedback').textContent='';});
  $('#video-shortcuts').onclick=()=>safely(()=>send({type:'video-shortcuts'}));
  $('#video-report').onclick=()=>safely(async()=>{
    const report=await send({type:'video-report'}),url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));
    const a=node('a');a.href=url;a.download='rift-ledger-recording-report.json';root.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),60000);
    $('#video-feedback').textContent='Recording report downloaded. It includes save status and errors, without footage, player names or microphone device IDs.';
  });
  $('#video-highlight').onclick=()=>action(async()=>{await send({type:'video-highlight'});$('#video-feedback').textContent='Highlight marked · 20 seconds before, 10 seconds after.';});
  $('#video-microphone-setup').onclick=()=>action(()=>send({type:'video-microphone-setup'}));
  $('#video-microphone').onchange=()=>action(async()=>{const value=$('#video-microphone').value;try{await send({type:'video-microphone',enabled:!!value,deviceId:value});}finally{microphoneStamp='';}});
  $('#video-frame-rate').onchange=()=>action(()=>send({type:'video-frame-rate',value:Number($('#video-frame-rate').value)}));
  $('#video-quality').onchange=()=>action(()=>send({type:'video-quality',value:$('#video-quality').value}));
  $('#video-limit').onchange=()=>action(()=>send({type:'video-limit',value:Number($('#video-limit').value)}));
  $('#video-back').onclick=()=>{closePlayer();onBack();};
  $('#video-open-page').onclick=()=>safely(async()=>{
    if(!selected||!sourceBlob)return;
    await send({type:'video-open-page',id:selected.id,at:$('#video-player').currentTime||0});
    $('#video-player').pause();
  });
  for(const [id,delta] of [['#video-rewind',-10],['#video-forward',10]])$(id).onclick=()=>{
    if(!selected)return;rangeEnd=null;$('#video-player').currentTime=Math.max(0,Math.min(selected.duration,($('#video-player').currentTime||0)+delta));
  };
  $('#video-speed').onchange=()=>{
    const value=Number($('#video-speed').value);
    if([.5,.75,1,1.25,1.5,2].includes(value))$('#video-player').playbackRate=value;
  };
  $('#video-clip-moment').onclick=()=>{trimmer.around(30);root.dataset.trimming='true';$('#video-clip-moment').setAttribute('aria-expanded','true');$('#video-detail').scrollIntoView?.({block:'start',behavior:'smooth'});};
  $('#clip-exit').onclick=()=>{root.dataset.trimming='false';$('#video-clip-moment').setAttribute('aria-expanded','false');$('#video-clip-moment').focus();};
  $('#video-play-range').onclick=()=>safely(playRange);
  $('#video-play-full').onclick=()=>safely(async()=>{rangeEnd=null;$('#video-player').currentTime=0;await $('#video-player').play();});
  $('#video-download').onclick=()=>safely(async()=>{
    if(!sourceBlob)return;
    const a=node('a');a.href=sourceURL;a.download=`rift-ledger-${selected.kind}-${new Date(selected.createdAt).toISOString().replaceAll(':','-')}.${videoExtension(sourceBlob.type)}`;root.append(a);a.click();a.remove();
    $('#video-feedback').textContent='Video downloaded. Videos are not included in match QR codes or JSON exports.';
  });
  $('#video-make-clip').onclick=()=>action(async()=>{
    const range=trimmer.range();
    $('#video-player').pause();await send({type:'video-clip',id:selected.id,...range});closePlayer();onBack();$('#video-feedback').textContent='Preparing the clip locally. This takes about as long as the clip; you can close this view.';
  });
  $('#video-delete').onclick=()=>{$('#video-delete-confirm').hidden=false;};
  $('#video-keep').onclick=()=>{$('#video-delete-confirm').hidden=true;};
  $('#video-delete-final').onclick=()=>action(async()=>{await store.remove(selected.id);closePlayer();onBack();$('#video-feedback').textContent='Video deleted. Your match history is unchanged.';});
  return {open:()=>refresh(),select:openRecord,poll:()=>refresh().catch(showError),close:()=>{++request;library?.close();closePlayer();$('#video-loading').hidden=true;}};
}
