import {createRevealController} from './revealed-controller.js';
import {installVideoController} from './video-controller.js';
import {validSessionDay, cleanSessionNote} from './session-recap.js';
import {emptyState, observe, review, group, exportRecords, resultURL, setExperience} from './core.js';
import {captureStatus, popupSummary} from './capture-status.js';
import {fieldNames, reviewStamp, validReviewDraft} from './review-form.js';
const video = chrome.offscreen ? installVideoController() : null;
const reveals = createRevealController(chrome);
let queue = Promise.resolve();
chrome.storage.local.setAccessLevel({accessLevel: 'TRUSTED_CONTEXTS'});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type?.startsWith('reveal-')) {
    queue = queue.then(() => reveals(message, sender)).then(result => respond({ok:true,result})).catch(error => respond({ok:false,error:error.message}));
    return true;
  }
  if (message?.target === 'video-offscreen' || message?.type?.startsWith('video-')) return;
  const fromPage = sender.tab && (sender.frameId == null || sender.frameId === 0) &&
    (!sender.documentLifecycle || sender.documentLifecycle === 'active') && sender.url?.startsWith('https://play.riftatlas.com/');
  const fromDashboard = ['dashboard.html', 'popup.html', 'companion.html'].some(page => sender.url?.split(/[?#]/)[0] === chrome.runtime.getURL(page));
  if ((!fromPage || !['observe', 'open-history', 'dismiss-notice'].includes(message.type)) && !fromDashboard) return;
  queue = queue.then(async () => {
    if (['session-note-read','session-note-save'].includes(message.type)) {
      if (!validSessionDay(message.day)) throw Error('Choose a valid session date.');
      const key = `sessionNote:${message.day}`;
      if (message.type === 'session-note-read') return (await chrome.storage.local.get(key))[key] || null;
      const note = {...cleanSessionNote(message.note), updatedAt:Date.now()};
      await chrome.storage.local.set({[key]:note});
      return note;
    }
    if (message.type === 'review-draft-read') return (await chrome.storage.local.get('popupReviewDraft')).popupReviewDraft || null;
    if (message.type === 'review-draft') {
      if (!validReviewDraft(message.draft)) throw Error('This review draft could not be saved.');
      const {id, stamp, values} = message.draft;
      await chrome.storage.local.set({popupReviewDraft:{id,stamp,values:Object.fromEntries(fieldNames.map(name=>[name,values[name]]))}}); return null;
    }
    if (message.type === 'review-draft-clear') {
      const {popupReviewDraft} = await chrome.storage.local.get('popupReviewDraft');
      if (popupReviewDraft?.id === message.id) await chrome.storage.local.remove('popupReviewDraft');
      return null;
    }
    const saved = (await chrome.storage.local.get('ledger')).ledger;
    if (saved && saved.version !== 1) throw new Error('This history needs a newer extension.');
    const state = saved || emptyState();
    // Capture is automatic. Remove the former pause preference without changing
    // history, display preferences or any video/microphone settings.
    if (Object.hasOwn(state, 'enabled')) {
      delete state.enabled;
      await chrome.storage.local.set({ledger:state});
    }
    const record = state.records.find(r => r.id === message.id);
    let result;
    switch (message.type) {
      case 'observe': observe(state, message.snapshot, Date.now(), {session: typeof message.context?.session === 'string' ? message.context.session.slice(0,80) : undefined, visible: message.context?.visible !== false}); result = {...captureStatus(state, message.snapshot), noticeEnabled:state.noticeEnabled !== false}; break;
      case 'read': return state;
      case 'open-history':
        await chrome.tabs.create({url: chrome.runtime.getURL('dashboard.html' + (record && !record.deleted ? `#review=${encodeURIComponent(record.id)}` : ''))});
        return null;
      case 'popup': return popupSummary(state, message.id);
      case 'dismiss-notice': state.noticeEnabled = false; break;
      case 'notice': state.noticeEnabled = !!message.enabled; break;
      case 'experience': setExperience(record, message.value); break;
      case 'review':
        if (!record || record.deleted || record.groupedBy) throw new Error('This game is no longer available.');
        if (message.expectedReview !== undefined && message.expectedReview !== reviewStamp(record))
          throw new Error('This game changed while you were reviewing it. Reload the saved game before confirming.');
        if (message.expectedReview !== undefined && !record.reviewed && record.outcome === 'unknown' && !message.finished)
          throw new Error('Confirm that this game has finished before saving a result.');
        review(record, message.values); break;
      case 'group': result = group(state, message.ids); break;
      case 'delete':
        if (!record) throw new Error('Game not found.');
        if (message.expectedReview !== undefined && (record.groupedBy || message.expectedReview !== reviewStamp(record)))
          throw new Error('This game changed. Reload the saved game before removing it.');
        record.deleted = true;
        if (record.children) state.records.forEach(r => { if (r.groupedBy === record.id) delete r.groupedBy; });
        break;
      case 'restore':
        if (!record || record.games || record.groupedBy) throw new Error('Regroup the individual games to recreate a series.');
        record.deleted = false; break;
      case 'url': return resultURL(record);
      case 'export': return exportRecords(message.ids?.length ? state.records.filter(r => message.ids.includes(r.id)) : state.records);
      default: throw new Error('Unknown request.');
    }
    const update = {ledger:state};
    if (['review','delete'].includes(message.type)) {
      const {popupReviewDraft} = await chrome.storage.local.get('popupReviewDraft');
      if (popupReviewDraft?.id === message.id) update.popupReviewDraft = null;
    }
    await chrome.storage.local.set(update);
    // Badge UI must not change whether a successful save is acknowledged.
    if (message.type === 'observe') {
      video?.observe(message.snapshot, result.match?.id, sender.tab.id, {visible:message.context?.visible!==false,
        documentToken:typeof message.context?.session==='string'?message.context.session.slice(0,80):undefined,kind:result.kind});
      const videoBadge=video?.badge(sender.tab.id);
      const badges = {recording: 'REC', review: '1', blocked: '!'};
      await Promise.all([
        chrome.action.setBadgeText({tabId: sender.tab.id, text: videoBadge ? videoBadge.text : badges[result.kind] || ''}),
        chrome.action.setBadgeBackgroundColor({tabId: sender.tab.id, color: videoBadge ? videoBadge.color : result.kind === 'blocked' ? '#B64355' : '#236957'}),
        chrome.action.setTitle({tabId: sender.tab.id, title: videoBadge ? `Rift Ledger · ${videoBadge.title}` : `Rift Ledger · ${result.title}`})
      ]).catch(() => {});
    }
    if (['notice', 'dismiss-notice'].includes(message.type)) {
      // No tabs permission needed: only message IDs, never inspect unrelated URLs.
      const tabs = await chrome.tabs.query({}).catch(() => []);
      for (const tab of tabs) chrome.tabs.sendMessage(tab.id, {type: 'capture-refresh'}).catch(() => {});
    }
    return result || state;
  }).then(result => respond({ok: true, result})).catch(async error => {
    if (message.type === 'observe') {
      // A background save failure must be visible without opening the developer console.
      await Promise.all([
        chrome.action.setBadgeBackgroundColor({tabId: sender.tab.id, color: '#B64355'}),
        chrome.action.setBadgeText({tabId: sender.tab.id, text: '!'}),
        chrome.action.setTitle({tabId: sender.tab.id, title: 'Rift Ledger could not save. Export your history and check available browser storage.'})
      ]).catch(() => {});
    }
    respond({ok: false, error: error.message});
  });
  return true;
});
