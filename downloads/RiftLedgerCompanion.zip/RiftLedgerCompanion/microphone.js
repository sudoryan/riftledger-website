export const DEFAULT_MICROPHONE = {enabled:false,deviceId:'default',label:'System default microphone'};
export function microphoneInputs(devices) {
  if(!Array.isArray(devices))return [];
  const unique=new Map();
  for(const d of devices.slice(0,100))if(d?.kind==='audioinput'&&typeof d.deviceId==='string'&&d.deviceId.length>0&&d.deviceId.length<=512&&typeof d.label==='string'&&d.label.trim()) {
    unique.set(d.deviceId,{deviceId:d.deviceId,label:d.label.trim().slice(0,200)});
  }
  return [...unique.values()];
}
export function microphonePreference(value) {
  const deviceId=typeof value?.deviceId==='string'&&value.deviceId.length>0&&value.deviceId.length<=512?value.deviceId:'default';
  return {enabled:value?.enabled===true,deviceId,label:typeof value?.label==='string'?value.label.slice(0,200):DEFAULT_MICROPHONE.label};
}
export function microphoneConstraints(deviceId) {
  return {video:false,audio:{...(deviceId&&deviceId!=='default'?{deviceId:{exact:deviceId}}:{}),echoCancellation:true,noiseSuppression:true,autoGainControl:true}};
}
export function microphoneError(error) {
  if(['NotAllowedError','SecurityError'].includes(error?.name))return 'Microphone access is blocked. Open Set up microphone and allow access in Chrome, or turn the microphone off.';
  if(['NotFoundError','OverconstrainedError'].includes(error?.name))return 'The selected microphone is unavailable. Reconnect it or choose another microphone in setup.';
  if(error?.name==='NotReadableError')return 'Chrome could not open this microphone. Check system microphone access and whether another app is using it.';
  return `Microphone could not start. ${error?.message||'Try microphone setup again.'}`;
}
