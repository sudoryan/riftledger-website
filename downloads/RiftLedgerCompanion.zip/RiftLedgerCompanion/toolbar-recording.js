// Only toolbar invocations start capture. Content observations prepare the next
// click; a remembered preference is never itself permission to record a new tab.
export function installToolbarRecording(api,{status,start,failed}) {
  let enabled=false,active=false,known={},queue=Promise.resolve(),clickPending=false;
  const applied=new Map();
  const ready=Promise.all([api.storage.local.get('videoToolbarAuto'),api.storage.session.get('videoToolbarTabs')]).then(([local,saved])=>{
    enabled=local.videoToolbarAuto===true;known=saved.videoToolbarTabs||{};
  });
  const run=fn=>{const task=queue.then(()=>ready).then(fn);queue=task.catch(()=>{});return task;};
  const save=()=>api.storage.session.set({videoToolbarTabs:known});
  async function route(tabId){
    const value=enabled&&!active&&known[tabId]?.eligible&&!known[tabId]?.failed?'':'popup.html';
    if(applied.get(tabId)===value)return;
    await api.action.setPopup({tabId:Number(tabId),popup:value});applied.set(tabId,value);
  }
  const sync=()=>Promise.all(Object.keys(known).map(id=>route(id).catch(()=>{})));
  async function open(tab){
    await api.action.setPopup({tabId:tab.id,popup:'popup.html'});applied.set(String(tab.id),'popup.html');
    await api.action.openPopup(tab.windowId==null?{}:{windowId:tab.windowId});
  }
  api.action.onClicked.addListener(tab=>{
    if(clickPending)return;clickPending=true;
    void (async()=>{
      await ready;
      // Set the next click to open controls before any slow recorder work.
      await api.action.setPopup({tabId:tab.id,popup:'popup.html'});applied.set(String(tab.id),'popup.html');
      try{
        const current=await status();active=!!current.active;
        if(!enabled||active||!known[tab.id]?.eligible||known[tab.id]?.failed){await open(tab);return;}
        await start(tab.id);active=true;await sync();
      }catch(error){
        known[tab.id]={...known[tab.id],failed:true};await save().catch(()=>{});await failed(error).catch(()=>{});
        await open(tab);
      }
    })().catch(()=>{}).finally(()=>{clickPending=false;});
  });
  return {
    configure:value=>run(async()=>{
      await api.storage.local.set({videoToolbarAuto:value});enabled=value;
      for(const entry of Object.values(known))entry.failed=false;
      await save();await sync();
    }),
    observe:(tabId,kind)=>run(async()=>{
      const eligible=['waiting','recording','review','saved'].includes(kind);
      if(known[tabId]?.eligible!==eligible){known[tabId]={...known[tabId],eligible};await save();}
      await route(String(tabId));
    }),
    state:value=>{active=!!value;void run(async()=>{
      if(value?.tabId!=null&&known[value.tabId]?.failed){known[value.tabId].failed=false;await save();}
      await sync();
    });},
    forget:(tabId,closed=false)=>run(async()=>{
      delete known[tabId];applied.delete(String(tabId));await save();
      if(!closed)await api.action.setPopup({tabId,popup:'popup.html'});
    }),
    // No start on worker wake, browser startup, preference changes or page load.
    refresh:()=>run(sync)
  };
}
