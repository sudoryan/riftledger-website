import {MAX_RECORD_SECONDS, observationMarkers, videoQuality} from './video-model.js';
export class RecorderEngine {
  constructor({store, Recorder=globalThis.MediaRecorder, clock=()=>performance.now(), onChange=()=>{}}) {
    Object.assign(this,{store,Recorder,clock,onChange}); this.active=null;this.lastResult=null;
  }
  status() {
    const s=this.active;
    return s ? {id:s.id,microphone:s.microphone,quality:s.quality,requestedFrameRate:s.requestedFrameRate,kind:s.kind,tabId:s.tabId,bytes:s.bytes,savedSeconds:s.lastSaved,elapsed:Math.min(s.maxSeconds,(this.clock()-s.started)/1000),highlights:s.markers.filter(m=>m.kind==='highlight').length,stopping:s.stopping,progress:s.progress||null} : null;
  }
  async start(stream, {cap,tabId=null,kind='match',maxSeconds=MAX_RECORD_SECONDS,quality,requestedFrameRate,...info}) {
    if(this.active)throw Error('A recording or clip is already running.');
    const profile=videoQuality(quality,requestedFrameRate);
    // AVC level 5.2 supports 4K60 (5.1 only supports 4K30). Prefer AVC for
    // high frame rates too; retain WebM where AVC is unavailable.
    const avc=profile.id==='2160p'&&profile.fps===60?'avc1.640034':'avc1.640033';
    const formats=[...(profile.id==='2160p'||profile.fps===60?[`video/mp4;codecs=${avc},mp4a.40.2`,`video/mp4;codecs=${avc},opus`]:[]),'video/webm;codecs=vp8,opus','video/webm;codecs=vp8','video/webm'];
    const mimeType=formats.find(m=>this.Recorder.isTypeSupported(m));
    if(!mimeType)throw Error('This browser cannot record video.');
    const settings=stream.getVideoTracks()[0]?.getSettings?.()||{};
    const videoInfo={quality:profile.id,requestedFrameRate:profile.fps,videoBitsPerSecond:profile.bitrate};
    for(const key of ['width','height','frameRate'])if(Number.isFinite(settings[key])&&settings[key]>0)videoInfo[key]=settings[key];
    const recorder=new this.Recorder(stream,{mimeType,videoBitsPerSecond:profile.bitrate,audioBitsPerSecond:128_000});
    const id=crypto.randomUUID(), started=this.clock();
    const state={...info,...videoInfo,id,kind,tabId,cap,stream,recorder,started,maxSeconds,markers:[],queue:Promise.resolve(),stopping:false,bytes:0,lastSaved:0,lastObservation:null};
    this.active=state;
    try { await this.store.create({...info,...videoInfo,id,kind,tabId,mimeType,status:kind==='clip'?'processing':'recording',createdAt:Date.now(),duration:0,markers:[]}); }
    catch(error){this.active=null;stream.getTracks().forEach(t=>t.stop());throw error;}
    state.done=new Promise(resolve=>state.resolve=resolve);
    recorder.addEventListener('dataavailable',event=>{
      const duration=Math.min(maxSeconds,(this.clock()-started)/1000);
      if(!event.data.size || state.storageFailure || state.finishing)return;
      state.queue=state.queue.then(async()=>{
        if(state.storageFailure)return;
        await this.store.append(id,event.data,cap,duration); state.lastSaved=duration;state.bytes+=event.data.size;
      }).catch(error=>{state.storageFailure=state.failure=error.message;void this.stop(error.message);});
    });
    // MediaRecorder becomes inactive BEFORE error -> final dataavailable -> stop.
    // Waiting for stop preserves the final chunk, including recordings whose
    // encoder delivered no earlier chunks. Storage failures still reject writes.
    recorder.addEventListener('error',event=>{
      state.failure=event.error?.message||'Video encoding stopped unexpectedly.';
      state.stopping=true;clearTimeout(state.timeout);clearTimeout(state.endTimer);this.notify();
    });
    recorder.addEventListener('stop',()=>{void this.finish(state);},{once:true});
    stream.getVideoTracks().forEach(t=>t.addEventListener('ended',()=>{void this.stop('Tab capture ended.');},{once:true}));
    try { recorder.start(2000); }
    catch(error){state.failure=error.message;await this.finish(state);throw error;}
    state.timeout=setTimeout(()=>{void this.stop(kind==='clip'?'':'Two-hour recording limit reached.');},maxSeconds*1000);
    this.notify(); return this.status();
  }
  notify() { try { this.onChange(this.status()); } catch {} }
  async finish(s) {
    if(s.finishing)return; s.finishing=true;
    clearTimeout(s.timeout);clearTimeout(s.endTimer);
    s.stream.getTracks().forEach(t=>t.stop());
    await s.queue;
    const duration=s.lastSaved;
    if(!s.bytes&&!s.failure)s.failure='The encoder stopped without producing video. No footage was saved.';
    try { if(!await this.store.patch(s.id,{duration,markers:s.markers.filter(m=>m.at<=duration),status:s.failure||s.reason?'interrupted':'ready',reason:s.failure||s.reason||'',finishedAt:Date.now()}))throw Error('Recording entry is missing.'); }
    catch(error){s.failure=`${s.bytes?'Footage saved, but its index':'Recording'} could not be finalized: ${error.message}`;}
    if(this.active===s)this.active=null;
    this.lastResult={id:s.id,kind:s.kind,bytes:s.bytes,duration,error:s.failure||null,reason:s.reason||''};
    s.resolve(this.lastResult);this.notify();
  }
  async stop(reason='') {
    const s=this.active;if(!s)return null;
    if(!s.stopping){s.stopping=true;s.reason=reason;clearTimeout(s.timeout);clearTimeout(s.endTimer);if(s.recorder.state!=='inactive')s.recorder.stop();else void this.finish(s);this.notify();}
    return s.done;
  }
  async highlight() {
    const s=this.active;if(!s||s.kind!=='match'||s.stopping)throw Error('Start a video recording first.');
    const marker={kind:'highlight',at:(this.clock()-s.started)/1000,label:`Highlight ${s.markers.filter(m=>m.kind==='highlight').length+1}`};
    s.markers.push(marker);await this.store.patch(s.id,{markers:s.markers});this.notify();return marker;
  }
  async observe(snapshot, matchID, tabId, context={}) {
    const s=this.active;if(!s||s.kind!=='match'||s.tabId!==tabId||s.stopping)return;
    if(!snapshot||snapshot.phase!=='in_game') { if(s.matchID)void this.stop('Game board closed.'); return; }
    if(s.matchID&&matchID&&s.matchID!==matchID){void this.stop('A new game started. Start a new video to record it.');return;}
    if(!matchID)return;
    const at=(this.clock()-s.started)/1000;
    if(s.lastObserved!=null&&at-s.lastObserved>45)s.markers.push({kind:'gap',at,label:'Turn markers may be missing before this point'});
    s.lastObserved=at;s.matchID=matchID;
    s.markers.push(...observationMarkers(s.lastObservation,snapshot,at));
    s.lastObservation={turn:snapshot.turn,activePlayer:snapshot.activePlayer,scores:snapshot.scores?.slice(),outcome:snapshot.outcome};
    // Keep the video running through the result screen, then finalize automatically.
    if(['win','loss','draw'].includes(snapshot.outcome)&&!s.endTimer)s.endTimer=setTimeout(()=>{void this.stop();},3000);
    if(snapshot.outcome==='unknown'){clearTimeout(s.endTimer);s.endTimer=null;}
    await this.store.patch(s.id,{matchID,names:snapshot.names?.map(n=>String(n).slice(0,60)),legends:snapshot.legends?.map(n=>String(n).slice(0,160)),markers:s.markers});
  }
}
