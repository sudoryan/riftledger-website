// Shared by the dashboard and compact popup review forms.
import {experienceLevels, opponentKey, rememberedOpponents} from './opponent-memory.js';
export const fieldNames = ['self-name','opponent-name','self-legend','opponent-legend','self-score','opponent-score','outcome','first','opponentExperience','deck','date'];
export const rawReviewFields = form => Object.fromEntries(fieldNames.map(name => [name, form.querySelector(`[name="${name}"]`).value]));
export function fillReviewForm(form, record, draft, records) {
  const values = draft || {'self-name':record.names[0],'opponent-name':record.names[1],
    'self-legend':record.legends[0],'opponent-legend':record.legends[1],
    'self-score':record.scores[0]??'','opponent-score':record.scores[1]??'',
    outcome:record.outcome==='unknown'?'':record.outcome,first:record.first??'',
    opponentExperience:record.opponentExperience||'unrated',deck:record.deck||'',
    date:new Date(record.date-new Date(record.date).getTimezoneOffset()*60000).toISOString().slice(0,16)};
  for (const name of fieldNames) form.querySelector(`[name="${name}"]`).value = values[name];
  if (records) configureOpponentPrefill(form, record, draft, records);
}

const opponentForms = new WeakMap();
function configureOpponentPrefill(form, record, draft, records) {
  let context = opponentForms.get(form);
  if (!context) {
    const document = form.ownerDocument;
    const name = form.querySelector('[name="opponent-name"]'), experience = form.querySelector('[name="opponentExperience"]');
    const list = document.createElement('datalist'), hint = document.createElement('small');
    list.id = `${form.id}-opponents`; name.setAttribute('list', list.id); form.append(list);
    hint.id = `${form.id}-remembered-opponent`; hint.className = 'opponent-memory-hint'; hint.hidden = true;
    experience.setAttribute('aria-describedby', hint.id); experience.parentElement.append(hint);
    context = {name, experience, list, hint, opponents:new Map(), key:''};
    const apply = () => {
      const remembered = context.opponents.get(context.key);
      experience.value = remembered?.experience || 'unrated';
      hint.hidden = !remembered;
      hint.textContent = remembered ? `Remembered for ${remembered.name}. You can change it.` : '';
    };
    for (const type of ['input','change']) {
      name.addEventListener(type, () => {
        const key = opponentKey(name.value);
        if (key === context.key) return;
        context.key = key; apply();
      });
      experience.addEventListener(type, () => {hint.hidden = true;});
    }
    context.apply = apply; opponentForms.set(form, context);
  }
  context.opponents = rememberedOpponents(records, record.id);
  context.key = opponentKey(context.name.value);
  context.hint.hidden = true;
  context.list.replaceChildren(...[...context.opponents.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(opponent => {
    const option = form.ownerDocument.createElement('option'); option.value = opponent.name;
    option.textContent = experienceLevels[opponent.experience]; return option;
  }));
  // Drafts and explicit per-match choices (including Unrated) always win.
  if (!draft && !Object.hasOwn(record, 'opponentExperience')) context.apply();
}
export function reviewValues(form) {
  const f = rawReviewFields(form);
  return {names:[f['self-name'],f['opponent-name']],legends:[f['self-legend'],f['opponent-legend']],
    scores:[f['self-score'],f['opponent-score']].map(v=>v.trim()===''?null:Number(v)),
    outcome:f.outcome,first:f.first===''?null:Number(f.first),opponentExperience:f.opponentExperience,
    deck:f.deck,date:new Date(f.date).getTime()};
}
// Heartbeats and timing ticks should not invalidate an unchanged result.
export function reviewStamp(r) {
  return JSON.stringify([r.id,r.names,r.legends,r.scores,r.outcome,r.first,r.deck,r.date,r.opponentExperience||'unrated',r.reviewed]);
}
export function validReviewDraft(draft) {
  return draft && typeof draft.id==='string' && draft.id.length<=80 &&
    typeof draft.stamp==='string' && draft.stamp.length<=4000 && draft.values &&
    fieldNames.every(name=>typeof draft.values[name]==='string' && draft.values[name].length<=200);
}
