import {experienceLevels} from './core.js';
import {timingSummary, duration} from './turn-timing.js';
import {renderPriorityTiming} from './priority-view.js';

// Match IDs are the only join key. Names, room IDs and timestamps can repeat.
export function matchForVideo(video, records) {
  const record = video?.matchID && records.find(r => r.id === video.matchID);
  if (!record || record.deleted || record.games) return null;
  const series = record.groupedBy && records.find(r => r.id === record.groupedBy && !r.deleted && r.children?.includes(record.id));
  return {record, game: series ? series.children.indexOf(record.id) + 1 : null};
}

export function createVideoMatchStats({root, loadRecords, loadVideo}) {
  const document = root.ownerDocument;
  const node = (tag, text, cls) => {
    const el = document.createElement(tag);
    if (text != null) el.textContent = text;
    if (cls) el.className = cls;
    return el;
  };
  let selected = null, generation = 0, stamp = '';
  const message = text => root.replaceChildren(node('p', text, 'replay-stats-note'));
  function clear() { ++generation; selected = null; stamp = ''; root.replaceChildren(); }
  function render(video, match) {
    root.replaceChildren();
    if (!match) {
      message('No saved match stats are linked to this video. You can still watch the footage and use its captured markers.');
      return;
    }
    const {record, game} = match;
    const names = [0, 1].map(i => record.names?.[i] || (i ? 'Opponent' : 'You'));
    const result = ({win:'Victory', loss:'Defeat', draw:'Draw'})[record.outcome] || 'Result unknown';
    const header = node('div', null, 'replay-result-row');
    const badge = node('strong', result, 'replay-result');
    badge.dataset.outcome = record.outcome;
    header.append(badge, node('span', record.reviewed ? 'Reviewed' : 'Needs review', 'replay-review-state'));
    root.append(header);
    const date = new Date(record.date);
    root.append(node('p', `${game ? `Game ${game} of best of three · ` : ''}${Number.isFinite(date.getTime()) ? date.toLocaleString([], {month:'short', day:'numeric', hour:'numeric', minute:'2-digit'}) : 'Date unknown'}`, 'replay-stats-note'));
    root.append(node('p', record.reviewed || ['win','loss','draw'].includes(record.outcome) ? 'FINAL SCORE' : 'LAST CAPTURED SCORE', 'replay-label'));
    const players = node('div', null, 'replay-players');
    for (const i of [0, 1]) {
      const side = node('div', null, 'replay-player');
      side.append(node('span', i ? 'OPPONENT' : 'YOU', 'replay-seat'), node('strong', names[i], 'replay-name'),
        node('span', record.legends?.[i] || 'Legend unknown', 'replay-legend'),
        node('b', Number.isFinite(record.scores?.[i]) ? record.scores[i] : '—', 'replay-score'));
      players.append(side);
    }
    root.append(players);
    const facts = node('dl', null, 'replay-facts');
    const fact = (label, value) => { facts.append(node('dt', label), node('dd', value)); };
    fact('First player', [0, 1].includes(record.first) ? names[record.first] : 'Unknown');
    if (record.deck?.trim()) fact('Your deck', record.deck);
    fact('Opponent experience', experienceLevels[record.opponentExperience] || 'Unrated');
    root.append(facts);
    const priority = node('section'); renderPriorityTiming(priority, record); root.append(priority);
    const summary = timingSummary(record);
    const time = node('div', null, 'replay-captured-time');
    time.append(node('span', 'Captured match time'), node('strong', duration(summary?.total ?? (record.seconds > 0 ? record.seconds : null))));
    root.append(time);
    if (video.kind === 'clip' || video.status === 'interrupted') root.append(node('p', 'Stats cover the saved game, not just this clip or recording segment.', 'replay-stats-note'));
    if (!summary) {
      root.append(node('p', 'Turn timing was not recorded for this game.', 'replay-stats-note'));
      return;
    }
    if (summary.partial || summary.unassigned > 0) root.append(node('p', `Partial timing${summary.unassigned > 0 ? ` · ${duration(summary.unassigned)} unassigned` : ''}`, 'replay-coverage'));
    const details = node('details', null, 'replay-turn-details');
    details.append(node('summary', 'Whole-turn duration'));
    const table = node('table', null, 'replay-timing');
    table.append(node('caption', 'Whole-turn duration'));
    const head = node('thead'), titles = node('tr');
    for (const label of ['On each turn', 'You', 'Opponent']) { const th = node('th', label); th.scope = 'col'; titles.append(th); }
    head.append(titles); table.append(head);
    const body = node('tbody');
    for (const [label, key] of [['Total time','total'], ['Complete turns','count'], ['Average','average'], ['Shortest','shortest'], ['Longest','longest']]) {
      const row = node('tr'), title = node('th', label); title.scope = 'row'; row.append(title);
      summary.players.forEach(p => row.append(node('td', key === 'count' ? p[key] : duration(p[key]))));
      body.append(row);
    }
    table.append(body); details.append(table);
    details.append(node('p', 'Whole-turn duration includes both players\' priority time during that turn. Average, shortest and longest use only fully observed turns.', 'replay-stats-note'));
    root.append(details);
  }
  async function refresh() {
    if (!selected) return;
    const video = selected, epoch = ++generation;
    try {
      let linked = video;
      const visited = new Set();
      // Old clips only stored a parent ID. Follow it without guessing a match.
      while (!linked.matchID && linked.parentID && !visited.has(linked.parentID) && visited.size < 32) {
        visited.add(linked.parentID);
        const parent = await loadVideo(linked.parentID);
        if (!parent) break;
        linked = parent;
      }
      const records = await loadRecords();
      if (epoch !== generation) return;
      const match = matchForVideo(linked, records);
      const next = JSON.stringify([video.id, video.kind, video.status, match]);
      if (next === stamp) return;
      stamp = next; render(video, match);
    } catch {
      if (epoch === generation) { stamp = ''; message('Match stats could not be loaded. Reopen this page to try again. Your video is still available.'); }
    }
  }
  async function select(video) {
    clear(); selected = video; message('Loading match stats…'); await refresh();
  }
  return {select, refresh, clear};
}
