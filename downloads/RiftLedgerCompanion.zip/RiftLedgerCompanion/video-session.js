import {videoQuality,videoFrameRate} from './video-model.js';
// One user-authorized tab stream can serve several independent game recordings.
// The master stream remains live while armed; only cloned tracks are encoded.
export const MAX_SESSION_SECONDS = 8 * 60 * 60;
export class VideoSession {
  constructor({engine, store, clock=()=>performance.now(), onChange=()=>{}}) {
    Object.assign(this,{engine,store,clock,onChange});
    this.auto=null;this.notice='';this.queue=Promise.resolve();
    engine.onChange=()=>{
      const id=this.auto?.recordingID;
      if(id&&!engine.status())void this.run(()=>this.settle(id)).catch(()=>{});
      if(!this.auto&&!engine.status()&&engine.lastResult)this.notice=this.resultNotice(engine.lastResult);
      this.notify();
    };
  }
  run(fn){const next=this.queue.then(fn);this.queue=next.catch(()=>{});return next;}
  status(){
    const current=this.engine.status(),s=this.auto;
    if(!s)return current;
    return {kind:'auto',quality:s.quality,requestedFrameRate:s.requestedFrameRate,microphone:s.microphone,tabId:s.tabId,phase:s.closing?'saving':s.reconnecting?'reconnecting':current?'recording':'waiting',
      elapsed:current?.elapsed||0,highlights:current?.highlights||0,stopping:s.closing||!!current?.stopping,
      id:current?.id||null,bytes:current?.bytes||0,savedSeconds:current?.savedSeconds||0,games:s.games,sessionElapsed:(this.clock()-s.started)/1000};
  }
  resultNotice(result){
    if(result.error)return `${result.error} ${result.bytes?'Saved footage is available in Your footage.':'No video data was saved.'}`;
    return result.reason?`${result.reason} Saved footage is available in Your footage.`:'Video saved in Your footage.';
  }
  notify(){try{this.onChange(this.status());}catch{}}
  start(stream,options){return this.run(async()=>{
    if(this.auto||this.engine.status())throw Error('End the current recording session or clip first.');
    this.notice='';try{return await this.engine.start(stream,options);}catch(error){this.notice=`Video did not start: ${error.message}`;this.notify();throw error;}
  });}
  enable(stream,{tabId,cap,audio,quality,requestedFrameRate,microphone,documentToken}){return this.run(async()=>{
    if(this.auto||this.engine.status())throw Error('End the current recording session or clip first.');
    this.notice='';
    const s={stream,tabId,cap,audio,microphone,documentToken,quality:videoQuality(quality).id,requestedFrameRate:videoFrameRate(requestedFrameRate),started:this.clock(),games:0,handled:new Set(),recordingID:null,matchID:null,closing:false};
    this.auto=s;
    s.timeout=setTimeout(()=>{void this.end('Auto-recording ended after eight hours. Enable it again to continue.');},MAX_SESSION_SECONDS*1000);
    stream.getVideoTracks().forEach(t=>t.addEventListener('ended',()=>{if(this.auto===s)void this.end('Tab capture ended. Enable auto-recording again to continue.');},{once:true}));
    this.notify();return this.status();
  });}
  async settle(id,{allowedReason=null}={}){
    const s=this.auto;if(!s||s.recordingID!==id)return;
    let record;
    try{record=await this.store.get(id);}catch(error){await this.endNow(`Auto-recording stopped: ${error.message}`);return;}
    s.recordingID=null;s.matchID=null;
    if(record?.bytes)s.games++;
    if(!s.closing&&(!record||!['ready','interrupted'].includes(record.status)||record.status==='interrupted'&&record.reason!==allowedReason)){
      await this.endNow(record?.reason||'Auto-recording stopped because the video could not be saved.');return;
    }
    this.notify();
  }
  async finishGame(reason=''){
    const id=this.auto?.recordingID;
    if(id){await this.engine.stop(reason);await this.settle(id,{allowedReason:reason});}
  }
  navigate(){return this.run(async()=>{
    const s=this.auto;if(!s||s.closing||s.reconnecting)return this.status();
    s.reconnecting=true;clearTimeout(s.departure);s.departure=null;this.notify();
    const unfinished=s.outcome==='unknown'?s.matchID:null;
    await this.finishGame(unfinished?'Page changed before the game ended. Further footage is saved as a separate segment.':'');
    if(this.auto!==s)return this.status();
    // A refresh may return to the same unfinished game. Its saved first segment
    // remains intact; finished games stay handled and cannot restart on reload.
    if(unfinished)s.handled.delete(unfinished);
    s.navigationTimeout=setTimeout(()=>{void this.end('Could not reconnect to RiftAtlas. Enable auto-recording again on your game tab.');},30000);
    this.notify();return this.status();
  });}
  connectDocument(documentToken){
    const s=this.auto;if(!s||typeof documentToken!=='string'||!documentToken||documentToken.length>80)return;
    clearTimeout(s.navigationTimeout);s.navigationTimeout=null;s.reconnecting=false;s.documentToken=documentToken;this.notify();
  }
  reconnect(documentToken){return this.run(()=>{this.connectDocument(documentToken);return this.status();});}
  observe(snapshot,matchID,tabId,context={}){return this.run(async()=>{
    const s=this.auto;
    if(!s)return this.engine.observe(snapshot,matchID,tabId,context);
    if(s.tabId!==tabId||s.closing)return;
    if(s.reconnecting){
      if(!context.documentToken||context.documentToken===s.documentToken)return;
      this.connectDocument(context.documentToken);
      if(s.reconnecting)return;
    }else if(s.documentToken&&s.documentToken!==context.documentToken)return;
    else if(!s.documentToken&&context.documentToken)this.connectDocument(context.documentToken);
    if(context.kind==='paused'){await this.endNow('Game capture paused. Auto-recording ended.');return;}
    // A transient missing board during a UI render must not split a video.
    if(!snapshot||snapshot.phase!=='in_game'){
      if(s.recordingID&&!s.departure)s.departure=setTimeout(()=>{void this.run(async()=>{
        if(this.auto!==s)return;s.departure=null;
        await this.finishGame(s.outcome==='unknown'?'Game board closed before a result was observed.':'');
      }).catch(error=>this.end(error.message));},2000);
      return;
    }
    clearTimeout(s.departure);s.departure=null;
    if(!matchID||!snapshot.playable||!['recording','review','saved'].includes(context.kind))return;
    if(s.recordingID&&s.matchID!==matchID){
      await this.finishGame(s.outcome==='unknown'?'A new game started before a result was observed.':'');
      if(this.auto!==s)return;
    }
    if(!s.recordingID){
      // Never begin on a finished/reviewed game, or restart a result on a heartbeat.
      if(s.handled.has(matchID)||context.kind!=='recording'||snapshot.outcome!=='unknown'||context.visible===false)return;
      const used=(await this.store.list()).reduce((sum,v)=>sum+v.bytes,0);
      if(used>=s.cap){await this.endNow('Video storage is full. Delete footage or raise the limit before enabling auto-recording.');return;}
      s.handled.add(matchID);s.matchID=matchID;
      const clone=s.stream.clone();
      try {
        const active=await this.engine.start(clone,{cap:s.cap,tabId,audio:s.audio,quality:s.quality,requestedFrameRate:s.requestedFrameRate,microphone:s.microphone,matchID,autoRecorded:true});
        s.recordingID=active.id;
      }catch(error){clone.getTracks().forEach(t=>t.stop());await this.endNow(error.message);throw error;}
    }
    s.outcome=snapshot.outcome;
    await this.engine.observe(snapshot,matchID,tabId,context);
    this.notify();
  });}
  highlight(){return this.run(()=>this.engine.highlight());}
  end(reason=''){return this.run(()=>this.endNow(reason));}
  async endNow(reason=''){
    const s=this.auto;
    if(s){s.closing=true;clearTimeout(s.timeout);clearTimeout(s.departure);clearTimeout(s.navigationTimeout);this.notify();}
    const result=await this.engine.stop(reason);
    if(s){this.auto=null;s.stream.getTracks().forEach(t=>t.stop());}
    this.notice=result?.error?this.resultNotice(result):reason||(s?`Auto-recording ended. ${s.games+(result?.bytes?1:0)} game videos saved this session.`:result?this.resultNotice(result):this.notice);
    this.notify();return result;
  }
}
