import {microphoneConstraints,microphoneError,microphoneInputs,microphonePreference} from './microphone.js';
export function createMicrophoneSetup({root=document,send,mediaDevices=navigator.mediaDevices,permissions=navigator.permissions,Context=AudioContext}) {
  const $=s=>root.querySelector(s);let current=microphonePreference(),devices=[],busy=false,stream=null,context=null,timer=null,frame=null,generation=0,active=false;
  const error=e=>{$('#mic-error').hidden=!e;$('#mic-error').textContent=e?.message||'';};
  const controls=()=>{for(const id of ['mic-allow','mic-input','mic-test','mic-save','mic-off'])$('#'+id).disabled=busy||active;$('#mic-save').disabled=busy||active||!$('#mic-input').value;};
  const stop=()=>{++generation;clearTimeout(timer);clearInterval(frame);stream?.getTracks().forEach(t=>t.stop());stream=null;context?.close().catch(()=>{});context=null;$('#mic-level').value=0;};
  const guard=async()=>{const status=await send({type:'video-status'});if(status.active)throw Error('End the current recording session before setting up a microphone.');return status;};
  async function list(){
    devices=microphoneInputs(await mediaDevices.enumerateDevices());
    const selected=$('#mic-input').value||current.deviceId;
    $('#mic-input').replaceChildren();
    if(devices.length){const o=root.createElement('option');o.value='default';o.textContent='System default microphone';$('#mic-input').append(o);}
    for(const d of devices.filter(d=>d.deviceId!=='default')){const o=root.createElement('option');o.value=d.deviceId;o.textContent=d.label;$('#mic-input').append(o);}
    if(selected!=='default'&&!devices.some(d=>d.deviceId===selected)){const o=root.createElement('option');o.value=selected;o.textContent=current.label+' · Unavailable';o.disabled=true;$('#mic-input').append(o);}
    $('#mic-input').value=selected;
    $('#mic-settings').hidden=!devices.length;$('#mic-allow').hidden=!!devices.length;
    await send({type:'video-microphone-inputs',devices:devices.map(d=>({...d,kind:'audioinput'}))});
    if(!devices.length)$('#mic-status').textContent='No microphones found. Connect a microphone and try again.';
  }
  const action=fn=>async()=>{if(busy||active)return;busy=true;controls();error(null);const epoch=++generation;try{await guard();await fn(epoch);}catch(e){error(e);}finally{stop();testDone?.();testDone=null;busy=false;controls();}};
  async function acquire(id,epoch){
    let next;try{next=await mediaDevices.getUserMedia(microphoneConstraints(id));}catch(e){throw Error(microphoneError(e));}
    if(epoch!==generation){next.getTracks().forEach(t=>t.stop());throw Error('Microphone setup cancelled. Return to this page and try again.');}
    stream=next;return next;
  }
  $('#mic-allow').onclick=action(async epoch=>{await acquire('default',epoch);await list();stop();$('#mic-status').textContent=devices.length?'Access allowed. Choose an input below.':'No microphones found.';});
  $('#mic-save').onclick=action(async epoch=>{
    const id=$('#mic-input').value;if(!id)throw Error('Choose a microphone first.');
    await acquire(id,epoch);stop();
    current=await send({type:'video-microphone',enabled:true,deviceId:id});
    $('#mic-status').textContent=`Selected: ${current.label}. Return to RiftAtlas to start recording.`;$('#mic-off').textContent='Turn microphone off';
  });
  $('#mic-off').onclick=action(async()=>{stop();current=await send({type:'video-microphone',enabled:false});$('#mic-status').textContent='Microphone is off. You can close this page.';$('#mic-off').textContent='Keep microphone off';});
  $('#mic-test').onclick=action(async epoch=>{
    const input=await acquire($('#mic-input').value,epoch);context=new Context();
    const analyser=context.createAnalyser();analyser.fftSize=256;context.createMediaStreamSource(input).connect(analyser);await context.resume();
    const values=new Uint8Array(analyser.fftSize);$('#mic-status').textContent='Listening for five seconds…';
    frame=setInterval(()=>{analyser.getByteTimeDomainData(values);$('#mic-level').value=Math.min(1,Math.sqrt(values.reduce((s,n)=>s+((n-128)/128)**2,0)/values.length)*4);},50);
    await new Promise(resolve=>{timer=setTimeout(resolve,5000);testDone=resolve;});stop();testDone=null;$('#mic-status').textContent='Test finished. No audio was saved.';
  });
  let testDone=null;
  const cancel=()=>{stop();testDone?.();testDone=null;};
  const hidden=()=>{if(root.visibilityState==='hidden')cancel();};
  root.addEventListener('visibilitychange',hidden);
  const changed=async()=>{if(busy||active)return;try{if((await permissions.query({name:'microphone'})).state==='granted')await list();controls();}catch(e){error(e);}};
  mediaDevices.addEventListener('devicechange',changed);
  return {async open(){try{const status=await send({type:'video-status'});active=!!status.active;current=microphonePreference(status.microphone);$('#mic-off').textContent=current.enabled?'Turn microphone off':'Keep microphone off';
    if(active){$('#mic-status').textContent='End the current recording session before setting up a microphone.';controls();return;}
    const permission=await permissions.query({name:'microphone'});
    $('#mic-status').textContent=permission.state==='granted'?'Choose the microphone to include in recordings.':'Allow microphone access to see your available inputs.';
    if(permission.state==='granted')await list();controls();
  }catch(e){error(e);controls();}},close(){cancel();root.removeEventListener('visibilitychange',hidden);mediaDevices.removeEventListener('devicechange',changed);}};
}
if(globalThis.location?.protocol==='chrome-extension:'){
  const setup=createMicrophoneSetup({send:async m=>{const r=await chrome.runtime.sendMessage(m);if(!r?.ok)throw Error(r?.error||'Reopen microphone setup after updating the extension.');return r.result;}});
  await setup.open();window.addEventListener('pagehide',()=>setup.close());
}
