// Routine endings should not look like failed saves. Unknown reasons retain a
// warning, so a new encoder/storage error cannot silently become a success.
export function videoNoticeKind(notice='') {
  if(!notice)return 'none';
  if(/^(Recorded tab closed\.|Recorded tab left RiftAtlas\.|Game capture paused\.|Auto-recording ended\.|Auto-recording ended after eight hours\.|Video saved in Your footage\.|Tab navigated or refreshed\.|Recording switched to another RiftAtlas tab\.)/.test(notice))return 'info';
  return 'error';
}
export function videoBanner(status={}) {
  const s=status.active;
  if(status.tabContext?.otherTab&&['auto','match'].includes(s?.kind))return {kind:'waiting',text:'Recording belongs to another RiftAtlas tab',stop:true,hidden:true};
  if(s)return {kind:s.kind==='auto'&&['waiting','reconnecting'].includes(s.phase)?'waiting':'active',
    text:s.kind==='clip'?'Preparing video clip':s.kind==='auto'&&s.phase==='reconnecting'?'Auto-record on · Reconnecting to RiftAtlas':s.kind==='auto'&&s.phase==='waiting'?'Auto-record on · Waiting for a game':'Video recording',stop:true};
  const kind=status.noticeKind||videoNoticeKind(status.notice);
  return {kind,text:status.notice||'',hidden:!status.notice||status.noticeDismissed,stop:false};
}
