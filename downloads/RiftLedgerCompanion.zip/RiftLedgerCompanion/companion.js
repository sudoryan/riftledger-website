import {createRecordingTabWarning} from './recording-tab-warning.js';
import {videoBanner} from './video-notice.js';
import {createVideos} from './video-view.js';
import {createMatchVideoLinks} from './match-video-links.js';
import {createRecap} from './recap-view.js';
import {renderTiming} from './timing-view.js';
import {historyMatches,historySummary,matchHistoryRow,updateHistoryVideoLinks} from './match-history.js';
import {VideoStore} from './video-store.js';
import {matchRecordings} from './video-model.js';
import {legendNames} from './legends.js';
import {fillReviewForm, rawReviewFields, reviewValues, reviewStamp, validReviewDraft} from './review-form.js';
const $ = s => document.querySelector(s);
let timingLive = false, savingExperience = false;
let currentMatch, busy = false, epoch = 0;
let view = 'home', records = [], allRecords = [], editingRecord, editingStamp, sharing, reviewSaving = false;
let restoredDraft = false, reviewReturn = 'home', visibleLimit = 30;
const send = async message => {
  const response = await chrome.runtime.sendMessage(message);
  if (!response?.ok) throw Error(response?.error || 'The extension is unavailable.');
  return response.result;
};
const showError = error => { $('#error').hidden = !error; $('#error').textContent = error?.message || ''; };
const homeVideoLinks=createMatchVideoLinks({root:$('#match-videos'),send,showError});
const reviewVideoLinks=createMatchVideoLinks({root:$('#review-videos'),send,showError});
const historyVideoStore=new VideoStore();
let historyVideos=[],historyVideoEpoch=0;
const labels = {recording:'LIVE MATCH STATS', review:'SAVED LOCALLY', saved:'SAVED LOCALLY', waiting:'STANDING BY', excluded:'NOT RECORDING', blocked:'NOT RECORDING', paused:'PAUSED', error:'CONNECTION NEEDED'};
function render(status, summary) {
  $('#status').dataset.kind = status.kind;
  $('#status-label').textContent = labels[status.kind] || 'STANDING BY';
  $('#title').textContent = status.kind === 'recording' ? 'Tracking match stats' : status.title; $('#detail').textContent = status.detail;
  $('#notice-enabled').checked = summary.noticeEnabled !== false;
  $('#pending').textContent = summary.pending; $('#ready').textContent = summary.ready;
  currentMatch = status.match || summary.recent;
  void homeVideoLinks.load(currentMatch?.id);
  $('#match').hidden = !currentMatch;
  $('#atlas').hidden = status.kind !== 'error';
  if (!currentMatch) return;
  const r = currentMatch;
  $('#experience').disabled = !r.id || savingExperience;
  if (!savingExperience && document.activeElement !== $('#experience')) $('#experience').value = r.opponentExperience || 'unrated';
  timingLive = status.kind === 'recording';
  renderTiming($('#timing'), r, {live:timingLive});
  $('#match-label').textContent = status.match ? 'CURRENT GAME' : 'LAST SAVED GAME';
  $('#turn').textContent = status.match && r.lastTurn != null ? `TURN ${r.lastTurn}` : '';
  for (const [i, side] of ['self','opponent'].entries()) {
    $(`#${side}-name`).textContent = r.names[i]; $(`#${side}-legend`).textContent = r.legends[i] || 'Legend not visible';
    $(`#${side}-score`).textContent = r.scores[i] ?? '–';
  }
  $('#outcome').textContent = status.kind === 'recording' ? 'In progress' : ({win:'Victory',loss:'Defeat',draw:'Draw',unknown:'Result to confirm'})[r.outcome] || 'Setting up';
  $('#saved').textContent = r.seenAt ? `Saved ${new Date(r.seenAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}` : '';
  $('#review').hidden = !r.id;
  $('#review').textContent = r.reviewed ? 'Review game' : 'Review result';
  $('#send-result').hidden = !r.id || !r.reviewed;
}
async function load() {
  if (busy || savingExperience || view !== 'home') return;
  busy = true; const request = ++epoch;
  try {
    const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
    let response;
    try {
      let timeout;
      try { response = await Promise.race([
        chrome.tabs.sendMessage(tab.id, {type:'capture-status'}),
        new Promise((_, reject) => { timeout = setTimeout(() => reject(Error('No reply')), 2500); })
      ]); } finally { clearTimeout(timeout); }
    } catch {}
    const summary = await send({type:'popup'});
    if (request !== epoch) return;
    const fallback = {kind:'error', title:'No connected game tab', detail:'Open RiftAtlas to check capture. If it’s already open, refresh that tab once after installing or updating.'};
    render(response?.ok && response.version === 2 && response.result ? response.result : fallback, summary);
    showError(null);
    if (!restoredDraft) {
      restoredDraft = true;
      const draft = await send({type:'review-draft-read'});
      if (validReviewDraft(draft) && request === epoch && view === 'home') {
        try { await openReview(draft.id, draft); }
        catch (error) { await send({type:'review-draft-clear',id:draft.id}); showError(error); }
      }
    }
  } catch (error) { showError(error); $('#title').textContent = 'Could not check capture'; }
  finally { busy = false; $('#refresh').disabled = false; }
}
$('#refresh').onclick = () => safely(() => view === 'recap' ? recap.open() : view === 'games' ? loadGames() : view==='videos'?videos.poll():load());
$('#notice-enabled').onchange = async e => {
  e.target.disabled = true;
  try { await send({type:'notice', enabled:e.target.checked}); await load(); }
  catch (error) { showError(error); e.target.checked = !e.target.checked; }
  finally { e.target.disabled = false; }
};
$('#experience').onchange = async e => {
  const id = currentMatch?.id, value = e.target.value;
  if (!id) return;
  savingExperience = true; ++epoch; e.target.disabled = true;
  try { await send({type:'experience', id, value}); currentMatch.opponentExperience = value; $('#experience-saved').textContent = 'Saved for this match'; showError(null); }
  catch (error) { e.target.value = currentMatch.opponentExperience || 'unrated'; showError(error); }
  finally { savingExperience = false; e.target.disabled = false; }
};
const openHistory = hash => chrome.tabs.create({url:chrome.runtime.getURL(`dashboard.html${hash}`)}).then(() => window.close());
$('#history').onclick = () => openHistory('');
$('#review').onclick = () => safely(() => openReview(currentMatch.id));
$('#send-result').onclick = () => safely(() => openShare(currentMatch.id));
setInterval(() => { if (currentMatch?.timing && timingLive) renderTiming($('#timing'), currentMatch, {live:true}); }, 1000);


const node = (tag, text, cls) => { const e=document.createElement(tag);if(text!=null)e.textContent=text;if(cls)e.className=cls;return e; };
const safely = async action => { try { showError(null); await action(); } catch (error) { showError(error); } };
const dateLabel = r => new Date(r.date).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
const resultLabel = r => ({win:'Victory',loss:'Defeat',draw:'Draw',unknown:'Unconfirmed'})[r.outcome] || 'Unconfirmed';
function setView(next) {
  ++historyVideoEpoch;
  homeVideoLinks.cancel();reviewVideoLinks.cancel();
  recap.cancel(); if(next!=='videos')videos.close(); view = next; ++epoch;
  for (const name of ['home','games','recap','review','share','videos']) $(`#${name}-view`).hidden = next !== name;
  document.body.dataset.view = next;
  const hash={home:'#capture',games:'',recap:'#recap',videos:'#settings',review:'#review='+encodeURIComponent(editingRecord?.id||''),share:'#share='+encodeURIComponent(sharing?.id||'')}[next];
  window.history?.replaceState(null,'','companion.html'+hash);
  $('.notice-setting').hidden=next!=='videos';
  $('#helper-settings').hidden=next!=='videos';
  $('#videos-tab').setAttribute('aria-pressed',String(next==='videos'));
  $('#capture-tab').setAttribute('aria-pressed',String(next==='home'));
  $('#games-tab').setAttribute('aria-pressed',String(next==='games'||(['review','share'].includes(next)&&reviewReturn!=='recap')));
  $('#recap-tab').setAttribute('aria-pressed',String(next==='recap'||(['review','share'].includes(next)&&reviewReturn==='recap')));
  $('#refresh').hidden = ['review','share'].includes(next);
  $('main').scrollTop = 0;
  showError(null);
}
async function readRecords() {
  const state = await send({type:'read'});
  allRecords=state.records;
  records = state.records.filter(r=>!r.deleted&&!r.groupedBy);
  return records;
}
async function loadGames() {
  await readRecords(); setView('games'); historyVideos=[]; renderGames();
  await loadHistoryVideos();
}
async function loadHistoryVideos(){
  const request=++historyVideoEpoch;
  let videos;
  try{videos=await historyVideoStore.list();}catch{videos=[];}
  if(request!==historyVideoEpoch||view!=='games')return;
  historyVideos=videos;
  const matches=new Map(allRecords.map(r=>[r.id,r]));
  for(const row of $('#game-list').children)updateHistoryVideoLinks(row,matchRecordings(videos,matches.get(row.dataset.matchId)));
}
function renderGames() {
  const matches=historyMatches(allRecords,{query:$('#game-search').value,filter:$('#game-filter').value});
  $('#history-summary').textContent=historySummary(allRecords);
  $('#game-list').replaceChildren();$('#games-empty').hidden=matches.length>0;
  $('#games-empty').textContent=$('#game-filter').value==='removed'?'No removed matches.':'No matches in this view.';
  $('#more-games').hidden=matches.length<=visibleLimit;
  for(const r of matches.slice(0,visibleLimit))$('#game-list').append(matchHistoryRow({document,record:r,
    recordings:matchRecordings(historyVideos,r),
    onReview:id=>safely(()=>openReview(id)),onRemove:(record,button)=>removeMatch(record,button),onRestore:(id,button)=>restoreMatch(id,button)}));
}
let removedMatchID=null,removingMatch=false;
async function removeMatch(record,button){
  if(removingMatch||reviewSaving)return;
  removingMatch=true;button.disabled=true;
  try{
    await send({type:'delete',id:record.id,expectedReview:view==='review'?editingStamp:reviewStamp(record)});
    removedMatchID=record.id;editingRecord=null;
    await loadGames();$('#match-removal-notice').hidden=false;
  }catch(error){showError(error);}finally{removingMatch=false;button.disabled=false;}
}
async function restoreMatch(id,button){
  if(removingMatch||!id)return;
  removingMatch=true;button.disabled=true;
  try{await send({type:'restore',id});$('#match-removal-notice').hidden=true;removedMatchID=null;await loadGames();}
  catch(error){showError(error);}finally{removingMatch=false;button.disabled=false;}
}
$('#remove-match').onclick=()=>editingRecord&&removeMatch(editingRecord,$('#remove-match'));
$('#undo-match').onclick=()=>restoreMatch(removedMatchID,$('#undo-match'));
async function openReview(id, draft) {
  await readRecords(); const r=records.find(r=>r.id===id);
  if (!r) throw Error('This game is no longer available.');
  if(['home','games','recap'].includes(view))reviewReturn=view;
  editingRecord=r;editingStamp=draft?.stamp||reviewStamp(r);
  setView('review'); $('#review-title').textContent=r.games?'Best of three':'Review game';
  void reviewVideoLinks.load(r.id);
  $('#review-date').textContent=`${dateLabel(r)} · ${r.partial?'Partial capture':'Saved on this browser'}`;
  $('#review-form').hidden=!!r.games;$('#series-summary').hidden=!r.games;
  $('#share-reviewed').hidden=!r.games||!r.reviewed;
  $('#back-series').hidden=!r.games;
  $('#back-series').textContent=reviewReturn==='recap'?'← Back to recap':'← Saved games';
  $('#cancel-review').textContent=reviewReturn==='recap'?'Back to recap':'Cancel';
  $('.form-error').textContent='';$('#draft-status').textContent=draft?'Your unfinished review was restored.':'';
  $('#review-timing').open=false;$('#review-timing-games').replaceChildren();
  for (const [i,game] of (r.games||[r]).entries()) {
    if(r.games)$('#review-timing-games').append(node('h3',`Game ${i+1}`));
    const panel=node('div',null,'timing-panel');renderTiming(panel,{...game,names:r.names},{timeline:true});
    $('#review-timing-games').append(panel);
  }
  if(r.games) {
    $('#series-summary').replaceChildren(node('p',`${r.names.join(' vs ')} · ${resultLabel(r)} · ${r.scores.join(' – ')}`));
    r.games.forEach((g,i)=>{const item=node('div',null,'series-game');item.append(node('strong',`Game ${i+1} · ${g.scores.join(' – ')}`),node('p',g.draw?'Draw':`${r.names[g.winner]} won`));$('#series-summary').append(item);});
    $('#series-summary').append(node('p','To change a grouped result, ungroup its games in full history.'));
    return;
  }
  fillReviewForm($('#review-form'),r,draft?.values,allRecords);
  $('#game-finished').checked=false;
  $('#finish-confirmation').hidden=r.reviewed||r.outcome!=='unknown';
  $('#game-finished').required=!$('#finish-confirmation').hidden;
  $('#capture-note').textContent=draft&&draft.stamp!==reviewStamp(r)
    ? 'The saved game changed since this draft. Reload the saved game before confirming.'
    : r.partial?'Capture began partway through this game. Check the result; the turn timeline covers the observed portion.'
    : 'Check both players, scores and result. Missing initiative stays out of first-player stats.';
}
function rememberDraft() {
  if(!editingRecord||editingRecord.games||reviewSaving||removingMatch)return;
  const id=editingRecord.id;
  $('#draft-status').textContent='Saving draft…';
  send({type:'review-draft',draft:{id,stamp:editingStamp,values:rawReviewFields($('#review-form'))}})
    .then(()=>{if(editingRecord?.id===id&&view==='review')$('#draft-status').textContent='Draft saved. You can close and reopen this page.';})
    .catch(error=>{if(editingRecord?.id===id&&view==='review')$('.form-error').textContent=`Draft not saved: ${error.message}`;});
}
$('#review-form').addEventListener('input',rememberDraft);
$('#review-form').addEventListener('change',rememberDraft);
$('#review-form').onsubmit=async event=>{
  event.preventDefault(); if(reviewSaving||removingMatch)return;
  const form=$('#review-form'); if(form.reportValidity&&!form.reportValidity())return;
  reviewSaving=true;$('.form-error').textContent='';
  const controls=[...form.querySelectorAll('input,select,button')];
  const values=reviewValues(form),finished=$('#game-finished').checked;
  controls.forEach(e=>e.disabled=true);
  try {
    const saved=await send({type:'review',id:editingRecord.id,values,expectedReview:editingStamp,finished});
    editingRecord=saved.records.find(r=>r.id===editingRecord.id);editingStamp=reviewStamp(editingRecord);
    $('#draft-status').textContent='Result saved.';
    try { await openShare(editingRecord.id,true); }
    catch(error) { $('.form-error').textContent=`Result saved. Could not open sharing: ${error.message}`; }
  } catch(error) { $('.form-error').textContent=error.message; }
  finally { reviewSaving=false;controls.forEach(e=>e.disabled=false); }
};
$('#reload-review').onclick=()=>safely(async()=>{const id=editingRecord.id;await send({type:'review-draft-clear',id});await openReview(id);});
$('#cancel-review').onclick=()=>safely(async()=>{
  await send({type:'review-draft-clear',id:editingRecord.id});
  await returnFromReview();
});
async function returnFromReview() {
  if(reviewReturn==='recap')return loadRecap();
  if(reviewReturn==='home'){setView('home');return load();}
  return loadGames();
}
async function openShare(id, confirmed=false) {
  if(['home','games','recap'].includes(view))reviewReturn=view;
  await readRecords();const record=records.find(r=>r.id===id);
  if(!record)throw Error('This game is no longer available.');
  const url=await send({type:'url',id}); sharing={id,url}; setView('share');
  $('#share-title').textContent=confirmed?'Result confirmed':'Send to phone';
  $('#share-summary').textContent=`${resultLabel(record)} · ${record.scores.join(' – ')} · ${record.names.join(' vs ')} · ${record.legends.join(' / ')}`;
  $('#return-recap').hidden=reviewReturn!=='recap';
  $('#share-note').textContent='';$('#copy-link').textContent='Copy result link';
  $('#qr').hidden=url.length>2900;
  $('#qr-help').textContent='On your iPhone: History → Scan result. Check your seat and save.';
  if(!$('#qr').hidden) {
    try { const qr=globalThis.qrcode(0,'L');qr.addData(url,'Byte');qr.make();$('#qr').src=qr.createDataURL(5,20); }
    catch { $('#qr').hidden=true; }
  }
  if($('#qr').hidden)$('#qr-help').textContent='Use Copy result link or Export this match. This result cannot be displayed as a QR code here.';
}
$('#copy-link').onclick=()=>safely(async()=>{await navigator.clipboard.writeText(sharing.url);$('#copy-link').textContent='Copied';});
$('#export-one').onclick=()=>safely(async()=>{
  const data=await send({type:'export',ids:[sharing.id]});
  const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
  const a=node('a');a.href=url;a.download=`rift-ledger-game-${new Date().toISOString().slice(0,10)}.json`;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);$('#share-note').textContent='Exported with turn timing. AirDrop the file, then use History → Import games.';
});
$('#edit-shared').onclick=()=>safely(()=>openReview(sharing.id));
$('#share-reviewed').onclick=()=>safely(()=>openShare(editingRecord.id));
$('#back-series').onclick=()=>safely(returnFromReview);
$('#return-recap').onclick=()=>safely(loadRecap);
$('#next-review').onclick=()=>safely(loadGames);
$('#review-queue').onclick=()=>safely(loadGames);
$('#games-tab').onclick=()=>safely(loadGames);
$('#capture-tab').onclick=()=>{setView('home');load();pollVideo();};
$('#game-search').oninput=()=>{visibleLimit=30;renderGames();};
$('#game-filter').onchange=()=>{visibleLimit=30;renderGames();};
$('#more-games').onclick=()=>{visibleLimit+=30;renderGames();};
for(const name of legendNames){const option=node('option');option.value=name;$('#legends').append(option);}
const recap=createRecap({root:$('#recap-view'),send,openReview:id=>safely(()=>openReview(id)),showError,isVisible:()=>view==='recap'});
function loadRecap(){setView('recap');return recap.open();}
$('#recap-tab').onclick=()=>safely(loadRecap);
const recordingTabWarning=createRecordingTabWarning({root:$('#recording-tab-warning'),send,showError,refresh:pollVideo});
const videos=createVideos({root:$('#videos-view'),send,showError,isVisible:()=>view==='videos',settingsOnly:true,onStatus:renderVideoStatus});
const openVideos=()=>safely(async()=>{setView('videos');await videos.open();const p=await send({type:'reveal-settings-get'});$('#revealed-enabled').checked=p?.enabled===true;});
$('#videos-tab').onclick=openVideos;$('#video-banner-open').onclick=openVideos;
let videoBannerStatus=null,videoBannerBusy=false;
$('#video-banner-stop').onclick=()=>safely(async()=>{
  if(videoBannerBusy)return;videoBannerBusy=true;$('#video-banner-stop').disabled=true;
  try{await send({type:'video-stop'});}finally{videoBannerBusy=false;await pollVideo();}
});
$('#video-banner-dismiss').onclick=()=>safely(async()=>{
  await send({type:'video-dismiss-notice',notice:videoBannerStatus?.notice});await pollVideo();
});
async function pollVideo(){
  if(view==='videos'){await videos.poll();return;}
  if(view==='games')void loadHistoryVideos();
  if(view==='review')void reviewVideoLinks.load(editingRecord?.id);
  try{
    renderVideoStatus(await send({type:'video-status'}));
  }catch{}
}
function renderVideoStatus(status){
  const banner=videoBanner(status);videoBannerStatus=status;recordingTabWarning.render(status);
  $('#video-live-banner').hidden=!!banner.hidden;$('#video-live-banner').dataset.kind=banner.kind;
  $('#video-banner-open').textContent=banner.text+(banner.stop?' · Controls':' · View videos');
  $('#video-banner-stop').hidden=!banner.stop;$('#video-banner-stop').disabled=videoBannerBusy||!!status.active?.stopping;
  $('#video-banner-dismiss').hidden=banner.stop;
}

async function route() {
  const hash=window.location.hash.slice(1);
  if(hash==='capture'){setView('home');await load();return;}
  if(hash==='settings'){await openVideos();return;}
  if(hash==='recap'){await loadRecap();return;}
  reviewReturn='games';
  if(hash.startsWith('review=')){await openReview(decodeURIComponent(hash.slice(7)));return;}
  if(hash.startsWith('share=')){await openShare(decodeURIComponent(hash.slice(6)));return;}
  const draft=await send({type:'review-draft-read'});
  if(validReviewDraft(draft)){
    try{await openReview(draft.id,draft);return;}catch{await send({type:'review-draft-clear',id:draft.id});}
  }
  await loadGames();
}
window.addEventListener('hashchange',()=>safely(route));
safely(route);setInterval(load,5000);pollVideo();setInterval(pollVideo,2000);
send({type:'popup'}).then(summary=>$('#notice-enabled').checked=summary.noticeEnabled!==false).catch(showError);

$('#revealed-enabled').onchange=()=>safely(async()=>{const input=$('#revealed-enabled'),enabled=input.checked;input.disabled=true;try{await send({type:'reveal-settings-set',enabled});}catch(e){input.checked=!enabled;throw e;}finally{input.disabled=false;}});
