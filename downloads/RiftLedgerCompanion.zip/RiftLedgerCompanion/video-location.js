// Only a local record identifier and playback position travel in the page URL.
export function videoLocation(id, at=0) {
  if(typeof id!=='string'||!id||id.length>200)throw Error('Choose a saved video.');
  const seconds=Number(at);
  return '#'+new URLSearchParams({id,t:String(Number.isFinite(seconds)?Math.min(7200,Math.max(0,seconds)):0)});
}
export function readVideoLocation(hash) {
  const params=new URLSearchParams(hash.replace(/^#/,'')),id=params.get('id');
  if(!id)return null;
  if(id.length>200)throw Error('This video link is invalid. Choose a recording from Your footage.');
  const seconds=Number(params.get('t'));
  return {id,at:Number.isFinite(seconds)?Math.min(7200,Math.max(0,seconds)):0};
}
