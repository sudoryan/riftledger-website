(() => {
  // Re-injection must not leave two observers or two notices running.
  globalThis.riftLedgerStop?.();
  const captureSession = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  let timer, last = '', lastBoard = '', lastSavedAt = 0, status, inFlight, rerun = false, stopped = false, collapseTimer;
  const host = document.createElement('div');
  host.id = 'rift-ledger-capture';
  host.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483646;color-scheme:dark';
  host.hidden = true;
  const shadow = host.attachShadow({mode: 'closed'});
  shadow.innerHTML = `<style>
    :host{all:initial}:host([hidden]){display:none!important}*{box-sizing:border-box}details{position:relative;width:280px;max-width:calc(100vw - 24px);font:13px/1.45 system-ui,sans-serif;color:#eef3f1;background:#101e26;border:1px solid #344b50;border-radius:13px;box-shadow:0 8px 30px #0006;overflow:hidden}
    details:not([open]){width:auto}summary{display:flex;align-items:center;gap:9px;list-style:none;cursor:pointer;padding:11px 45px 11px 14px;font-weight:650;user-select:none}summary::-webkit-details-marker{display:none}summary::after{content:'⌄';color:#95aaa9;margin-left:14px}.dot{width:7px;height:7px;border-radius:50%;background:#afbdc0;flex-shrink:0}details[data-kind=recording] .dot{background:#73dfb9;box-shadow:0 0 0 4px #73dfb917}details[data-kind=review] .dot{background:#e9c882}details[data-kind=blocked] .dot,details[data-kind=error] .dot{background:#ff9b9e}.body{padding:0 14px 14px;border-top:1px solid #25383e}p{margin:10px 0;color:#b9c8cc}.match{font-weight:650;color:#eef3f1}.legends{font-size:12px}button{font:inherit;color:#f1d695;background:#233238;border:1px solid #6e6040;border-radius:7px;padding:7px 12px;cursor:pointer}.dismiss{position:absolute;right:4px;top:4px;width:34px;height:34px;padding:0;background:transparent;border:0;color:#b9c8cc;font-size:22px}.dismiss:hover{background:#344b50}summary:focus-visible,button:focus-visible{outline:2px solid #e9c882;outline-offset:-3px}[hidden]{display:none!important}
    </style><details><summary aria-label="Rift Ledger capture status"><span class="dot"></span><span class="label">Connecting Rift Ledger…</span></summary><div class="body"><p class="match" hidden></p><p class="legends" hidden></p><p class="detail" role="status"></p><button class="review" type="button" hidden>Review game</button></div></details><button class="dismiss" type="button" aria-label="Hide recording notice" title="Hide notice. Recording continues; reopen from the extension popup.">×</button>`;
  const $ = q => shadow.querySelector(q), details = $('details');
  document.documentElement.append(host);
  let announced = '', noticeEnabled = true, dismissed = false;
  function render(next) {
    const wasEnabled = noticeEnabled;
    noticeEnabled = next.noticeEnabled ?? noticeEnabled;
    if (!wasEnabled && noticeEnabled) { announced = ''; dismissed = false; }
    status = next;
    if (!noticeEnabled || dismissed) host.hidden = true;
    details.dataset.kind = next.kind;
    $('.label').textContent = next.title;
    $('.detail').textContent = next.detail;
    const match = next.match;
    $('.match').hidden = !match; $('.legends').hidden = !match;
    if (match) {
      $('.match').textContent = `${match.names[0]} ${match.scores.map(n => n ?? '–').join(' : ')} ${match.names[1]}`;
      $('.legends').textContent = match.legends.map(n => n || 'Legend not visible').join(' · ');
    }
    $('.review').hidden = !match?.id || next.kind === 'recording';
    const key = `${match?.id || ''}:${next.kind}`;
    if (noticeEnabled && !dismissed && key !== announced && ['recording', 'review', 'blocked', 'error'].includes(next.kind)) {
      announced = key; host.hidden = false; details.open = false; clearTimeout(collapseTimer);
      collapseTimer = setTimeout(() => { host.hidden = true; }, 7000);
    }
  }
  details.querySelector('summary').addEventListener('click', () => clearTimeout(collapseTimer));
  $('.dismiss').onclick = () => {
    dismissed = true; noticeEnabled = false; host.hidden = true; clearTimeout(collapseTimer);
    chrome.runtime.sendMessage({type:'dismiss-notice'}).catch(() => {});
  };
  $('.review').onclick = () => chrome.runtime.sendMessage({type:'open-history', id:status?.match?.id}).catch(() => {});
  async function sample(force = false) {
    if (stopped) return status;
    if (inFlight) { rerun = true; await inFlight; return sample(force); }
    inFlight = (async () => {
      try {
        const snapshot = globalThis.RiftLedgerAtlas.read(document);
        const value = JSON.stringify(snapshot);
        if (!force && value === last) return;
        const {prioritySeconds, ...board} = snapshot || {};
        const boardValue = JSON.stringify(board);
        // Clock-only ticks do not rewrite the whole local history every second.
        // Scores, turns, results, visibility changes and explicit refreshes save immediately.
        if (!force && boardValue === lastBoard && Date.now() - lastSavedAt < 5000) return;
        const response = await chrome.runtime.sendMessage({type:'observe', snapshot, context:{session:captureSession, visible:!document.hidden}});
        if (!response?.ok) throw new Error(response?.error || 'The extension did not acknowledge this game.');
        last = value; lastBoard = boardValue; lastSavedAt = Date.now();
        render(response.result);
      } catch (error) {
        const invalidated = /context invalidated|receiving end does not exist/i.test(error.message);
        render({kind:'error', title:invalidated ? 'Refresh RiftAtlas to reconnect' : 'Game is not saving',
          detail:invalidated ? 'Rift Ledger was updated. Refresh this tab to resume recording.' : `${error.message} Capture will retry. Your earlier saves are kept.`});
      }
    })();
    await inFlight; inFlight = null;
    if (rerun) { rerun = false; schedule(); }
    return status;
  }
  function schedule() { if (!timer && !stopped) timer = setTimeout(() => { timer = null; sample(); }, 150); }
  const observer = new MutationObserver(schedule);
  // Identity/phase/score changes can happen without child mutations. Ignore the
  // many per-frame style changes from card animations.
  observer.observe(document.documentElement, {subtree:true, childList:true, attributes:true, characterData:true,
    attributeFilter:['data-room-phase','data-room-mode','data-room-code','data-viewer-player-id','data-opponent-player-id',
      'data-turn-number','data-active-player-id','data-viewer-score','data-opponent-score','data-identity-action-clock','data-layout','data-active','aria-pressed','role','aria-label','alt']});
  const onVisibility = () => sample(true);
  const listener = (message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !['capture-status','capture-refresh'].includes(message.type)) return;
    sample(true).then(result => respond({ok:true, version:2, documentToken:captureSession, result}));
    return true;
  };
  chrome.runtime.onMessage.addListener(listener);
  document.addEventListener('visibilitychange', onVisibility);
  // Also retries storage failures and catches updates after an extension reload.
  const heartbeat = setInterval(() => { if (!document.hidden) sample(true); }, 15000);
  globalThis.riftLedgerStop = () => {
    stopped = true; observer.disconnect(); clearTimeout(timer); clearTimeout(collapseTimer); clearInterval(heartbeat);
    document.removeEventListener('visibilitychange', onVisibility);
    try { chrome.runtime.onMessage.removeListener(listener); } catch {}
    host.remove();
  };
  sample(true);
})();
