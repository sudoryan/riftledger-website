// Locate the first Cluster at a Segment child boundary. MediaRecorder chunks may
// end inside a Cluster; parsing that partial Cluster would rewrite its size and
// corrupt the next chunk. Only the complete, small metadata prefix is editable.
export function webmHeader(bytes) {
  function element(at) {
    if(at>=bytes.length||bytes[at]===0)return null;
    let idLength=1;while(idLength<=4&&!(bytes[at]&(1<<(8-idLength))))idLength++;
    if(idLength>4||at+idLength>=bytes.length)return null;
    let id=0;for(let i=0;i<idLength;i++)id=id*256+bytes[at+i];
    const sizeAt=at+idLength;let length=1;while(length<=8&&!(bytes[sizeAt]&(1<<(8-length))))length++;
    if(length>8||sizeAt+length>bytes.length)return null;
    let size=bytes[sizeAt]&((1<<(8-length))-1),unknown=size===(1<<(8-length))-1;
    for(let i=1;i<length;i++){size=size*256+bytes[sizeAt+i];unknown=unknown&&bytes[sizeAt+i]===255;}
    return {id,size:unknown?Infinity:size,sizeAt,length,dataAt:sizeAt+length};
  }
  let at=0,segment;
  while(at<bytes.length){const e=element(at);if(!e)return null;if(e.id===0x18538067){segment=e;break;}if(!Number.isSafeInteger(e.size))return null;at=e.dataAt+e.size;}
  if(!segment)return null;
  at=segment.dataAt;
  while(at<bytes.length){
    const e=element(at);if(!e)return null;
    if(e.id===0x1f43b675){
      const prefix=bytes.slice(0,at);
      // An unknown Segment length remains valid after adding a duration field.
      prefix[segment.sizeAt]=(1<<(9-segment.length))-1;
      for(let i=1;i<segment.length;i++)prefix[segment.sizeAt+i]=255;
      return {prefix,offset:at};
    }
    if(!Number.isSafeInteger(e.size)||e.dataAt+e.size>bytes.length)return null;
    at=e.dataAt+e.size;
  }
  return null;
}
